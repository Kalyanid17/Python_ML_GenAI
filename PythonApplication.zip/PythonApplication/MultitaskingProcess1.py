import multiprocessing
import time
import os
    
def SumEven(No):
    print("PPID of SumEven : ", os.getppid()) #21
    print("PID of SumEven : ", os.getpid()) #51
    sum = 0
    for i in range(2,No+1,2):
        sum = sum + i
    print("Sum of Even nos is : ", sum)

def SumOdd(No):
    print("PPID of SumOdd : ", os.getppid()) #21
    print("PID of SumOdd : ", os.getpid())   #101
    sum = 0
    for i in range(1,No+1,2):
        sum = sum + i
    print("Sum of Odd nos is : ", sum)

def main():

    print("PPID of main : ", os.getppid()) #CMD 11
    print("PID of main : ", os.getpid()) #21
    start_time = time.time()
    t1 = multiprocessing.Process(target = SumEven, args=(100000000,))
    t2 = multiprocessing.Process(target = SumOdd, args=(100000000,))

    
    t1.start()
    t2.start()

    t1.join()
    t2.join()

    end_time = time.time()
    print("Time required : ", end_time-start_time) #Time required :  2.4158380031585693

if(__name__ == "__main__"):
    main()

# Multiprocesing is used for mathematical operarrtions cpu bound, here time is reduced to 1/2