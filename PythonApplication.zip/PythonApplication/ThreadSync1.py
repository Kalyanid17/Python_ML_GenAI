import threading

iCnt = 0 #global

def Update():
    global iCnt

    for _ in range(200000): #i don't want to waste memory, _ it just created a variable but memory is allocated
        iCnt = iCnt + 1


def main():
    
    Update()
    Update()

    print("Values of iCnt : ",iCnt)

if(__name__ == "__main__"):
    main()