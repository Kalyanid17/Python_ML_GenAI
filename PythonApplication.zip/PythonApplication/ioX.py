print("Enter your name : ")
Name = input()


print("Hello, ",Name)


print ("Age :")
Age=input()
print("Age is : ", Age)