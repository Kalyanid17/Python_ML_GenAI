

def main():
    Ans = 0

    try: #not  good way as whole code is putted inside try
        print("Inside try")
        print("Enter first no : ")
        No1 = int(input())

        print("Enter Second no : ")
        No2 = int(input())

    
       
        Ans = No1 / No2

    except ZeroDivisionError as zobj:
        print("Inside Except", zobj)
    
    except ValueError as vobj:
        print("Inside Except", vobj)

    except Exception as eobj:   #Generic Except block
        print("Inside Except", eobj)

    except:
        print("Inside Except")
        
    finally:
        print("Inside finally") #irrespective of exception it goes inside finally, finally is optional

    print("Division is : ", Ans)


if(__name__ == "__main__"):
    main()