
def Addition(*No):
    print(No)
    print(type(No)) #tuple
    print(len(No))

def main():
   Addition(10,20)
   Addition(11,21,31,41,11)
   
if __name__ == "__main__":
    main()