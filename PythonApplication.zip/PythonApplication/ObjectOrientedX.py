class Arithmetic:

    def Addition(self,A,B):      #instance method
        return A+B

    def Substraction(self,A,B):      
        return A-B

No1  = 0
No2 = 0
Ans = 0

obj = Arithmetic()

No1 = (int(input("Enter First no :")))
No2 = (int(input("Enter Second no :")))

Ans = obj.Addition(No1,No2)
print("Addition is : ", Ans)

Ans = obj.Substraction(No1,No2)
print("Substration is : ", Ans)