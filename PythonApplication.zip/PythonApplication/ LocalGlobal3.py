
no = 11 #Global, data definition statement
def Fun():
    no = 21
    print("Value of no from Fun is ", no) #21
    no = no + 1 
    print("Value of no from Fun is : ", no)  #22
    
print("Value of no is : ", no)  #11
Fun()
print("Value of no is : ", no)  #11