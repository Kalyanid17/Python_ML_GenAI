
Name = input("Enter your name : ")


print("Hello, ",Name)



Age=input("Age :")
print("Age is : ", Age)