#DuckTyping : Its a concept where type of an object is determined by its behaviour,
#not by its class

class InkjetPrinter:    #machine h/w
    def printdocument(self,document):
        print("InkjetPrinter printing : ",document)

class LaserPrinter:     #machine h/w
    def printdocument(self,document):
        print("LaserPrinter printing : ",document)

class PDFWriter:        #pdf writer s/w 
    def printdocument(self,document):
        print(f"PDFWriter saving {document} as PDF")

def StartPrinting(Device):
    Device.printdocument("MarvellousNotes")

def main():
    StartPrinting(InkjetPrinter())
    StartPrinting(LaserPrinter())
    StartPrinting(PDFWriter())

main()