No1 = 31
No2 = 21

print(No1 > No2) 

