#test myProgram for test
import threading

SumCube = 0 #global

def getCubeSummation(No):
    global SumCube

    for i in range(No+1): #i don't want to waste memory, _ it just created a variable but memory is allocated
        SumCube = SumCube + (i**3)#critical, 



if(__name__ == "__main__"):
    
    T1 = threading.Thread(target = getCubeSummation,args = (100000,))
    #T2 = threading.Thread(target = getCubeSummation,args=(100000,))

    T1.start()
    #T2.start()

    T1.join()
    #T2.join()

    print("Values of iCnt : ",SumCube) # o/p = 4000000, this output may get reduced in case assignment is pending by t1 thread, in this case since operation is small, o/p is same

    print(SumCube+SumCube)