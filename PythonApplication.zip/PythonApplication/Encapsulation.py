class Arithmatic:
    def __init__(self,A,B): #initialize the obj
        self.No1 = A
        self.No2 = B
        print("Object gets created Successfully.")

    def Addition(self):
        Ans = 0
        Ans = self.No1 + self.No2
        return Ans
    
    def Substraction(self):
        Ans = 0
        Ans = self.No1 - self.No2
        return Ans
    
obj1 = Arithmatic(11,10) #Arithmatic(id(Obj1),11,10) -> __init__(id(Obj1),11,10)
obj2 = Arithmatic(21,20)

Ret = obj1.Addition()   #Addition(id(obj1)->Addition(1000)) -> 1000 ->imaginary address
print(Ret)

Ret = obj2.Substraction()   #Substraction(id(obj1)->Substraction(2000)) -> 2000 ->imaginary address
print(Ret)


