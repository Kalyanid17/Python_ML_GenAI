import threading

iCnt = 0 #global

def Update():
    global iCnt

    for _ in range(2000000): #i don't want to waste memory, _ it just created a variable but memory is allocated
        iCnt +=  1 #critical, 



if(__name__ == "__main__"):

    T1 = threading.Thread(target = Update)
    T2 = threading.Thread(target = Update)

    T1.start()
    T2.start()

    T1.join()
    T2.join()

    print("Values of iCnt : ",iCnt) # o/p = 4000000, this output may get reduced in case assignment is pending by t1 thread, in this case since operation is small, o/p is same

    