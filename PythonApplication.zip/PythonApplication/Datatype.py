#Numeric
Age=35
Marks = 89.60
Data=4+7j

print("Age : ",Age)
print("Marks : ", Marks)
print("Data : ", Data)