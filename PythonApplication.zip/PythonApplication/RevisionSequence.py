# Sequence datatype
arr=[10,20,30,40,10,'python']
print(arr)
print(type(arr))
print("-"*15)

brr = (10,20,30,40,10)
print(brr)
print(type(brr))
print("-"*15)
