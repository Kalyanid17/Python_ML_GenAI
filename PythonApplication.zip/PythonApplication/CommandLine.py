import sys

print("Number of Command Line arguments are : ", len(sys.argv)) # argv is a list inside sys
#python3 CommandLine.py 11 Pune 21 o/p = 4