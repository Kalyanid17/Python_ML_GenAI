class Demo:
    No = 10

    def __init__(self,A,B):
        self.Value1 = A
        self.Value2 = B

print("Class Variable: ", Demo.No)

obj1 = Demo(11,21)
obj2 = Demo(51,101)

#print(obj1.No) # Allowed, Can be accessed, but not good programming practice

print("Instance variable of obj1 : ", obj1.Value1, obj1.Value2) #11 21
print("Instance variable of obj2 : ", obj2.Value1, obj2.Value2) #51 101

obj1.Value1 = 15

Demo.No = 0
#obj1.No = 0 # Allowed, this will create specific copy of NO for obj1, not good prog practice instead we ca use instance var using self keyword

print("Instance variable of obj1 : ", obj1.Value1, obj1.Value2) # 15 21
print("Instance variable of obj2 : ", obj2.Value1, obj2.Value2) # 51 101

print(obj1.No)  #0
print(obj2.No)  #0