Information={"Name":"Rahul","Age":35,"City":"Pune","Marks":89.90}
print(type(Information))
print(Information)
      
print(Information["City"])   #Pune     
