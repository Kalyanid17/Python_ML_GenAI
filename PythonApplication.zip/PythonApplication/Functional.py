#lambda keyword 

Addition = lambda A,B : A + B    
  
Substraction = lambda A,B : A - B

No1  = 0
No2 = 0
Ans = 0

No1 = (int(input("Enter First no :")))  #11
No2 = (int(input("Enter Second no :"))) #10

Ans = Addition(No1,No2) # Ans = No1+No2 , for lambda it happens on the same line , it replaces with body e.g home service
print("Addition is : ", Ans)

Ans = Substraction(No1,No2)
print("Substration is : ", Ans) #Ans = No1 - No2    ANS = 1