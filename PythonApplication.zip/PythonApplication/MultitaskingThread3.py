import threading
    
def Display():
    print("Inside Display function : ", threading.get_ident()) #id of thread
    for i in range(100):
        print("Inside Display")

def main():
    print("Inside main : ", threading.get_ident())

    t = threading.Thread(target=Display)
    t.start()

    print("End of main")

if(__name__ == "__main__"):
    main()

#