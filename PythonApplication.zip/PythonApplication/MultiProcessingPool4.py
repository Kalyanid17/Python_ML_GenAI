import time
import multiprocessing

def SumCube(No):
    Sum = 0
    
    for i in range(1,No+1):
        Sum = Sum + (i**3)

    return Sum

def main():
    Data = [1000000, 2000000, 3000000, 4000000,5000000,6000000,7000000,8000000,9000000,10000000]
    Result = []

    start_time = time.time()

    pObj = multiprocessing.Pool()
    Result = pObj.map(SumCube,Data)
    
    pObj.close()
    pObj.join()

    end_time = time.time()
    
    print (Result)
    print("Total execution time in seconds is : ", end_time - start_time) #It will show time in seconds
    

if(__name__ == "__main__"):
    main()