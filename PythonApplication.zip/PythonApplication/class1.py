class Demo:
    def __init__(self): #instance methods
        print("Inside constructor")

    def __del__(self): #implicit garbage collection, it happens when gc is available
        print("Inside destructor")

obj = Demo()

print("End of application")