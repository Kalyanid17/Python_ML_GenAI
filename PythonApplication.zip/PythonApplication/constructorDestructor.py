import gc
class Demo:
    def __init__(self): #instance methods
        print("Inside constructor")

    def __del__(self):
        print("Inside destructor")

#Allocate
obj = Demo()
    
#Use

#Deallocate
del obj

gc.collect()        #Explicitly mentioning to collect the garbage, to free memory

print("End of application")