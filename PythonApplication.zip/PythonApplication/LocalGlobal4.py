
no = 11 #Global, data definition statement
def Fun():
    global no 
    print("Value of no from Fun is ", no) #11
    no = no + 1     #12
    print("Value of no from Fun is : ", no)  #12
    
print("Value of no is : ", no)  #11
Fun()
print("Value of no is : ", no)  #12