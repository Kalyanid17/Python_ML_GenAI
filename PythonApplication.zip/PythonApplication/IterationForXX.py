#Sequence

print("Jay Ganesh")
print("Jay Ganesh")
print("Jay Ganesh")
print("Jay Ganesh")

print("_"*14)

#Iteration
for i in range(4):  #range(1,5)
    print("Jay Ganesh")