class Parent():
    
    def __init__(self):
        print("Inside Parent Constructor")
        
    def Fun(self):
        print("Inside Fun method of parent")

class Child(Parent):
    def __init__(self):
        super().__init__()
        print("Inside Child Constructor")
       

    def Fun(self):
        super().Fun()
        print("Inside Fun method of child") #super is needed for ininit method, if parent has instance vars

cObj = Child()

cObj.Fun()

