def Addition(No1, No2):
    Ans = None
    Ans = No1 + No2
    return Ans

Res = Addition(10,11)
print("Result : ", Res)
     