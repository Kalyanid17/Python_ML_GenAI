import sys

No=10 #int
Marks=90.90 #Float
Name = "Rahul Vasantrao Deshpande" #str

print(f"int = {sys.getsizeof(No)}")
print(f"float = {sys.getsizeof(Marks)}")
print(f"str = {sys.getsizeof(Name)}")