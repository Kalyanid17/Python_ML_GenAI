#def keyword 

def Addition(A,B):      #Procedure
    return A+B

def Substraction(A,B):      #Procedure
    return A-B

No1  = 0
No2 = 0
Ans = 0

No1 = (int(input("Enter First no :")))
No2 = (int(input("Enter Second no :")))

Ans = Addition(No1,No2)
print("Addition is : ", Ans)

Ans = Substraction(No1,No2)
print("Substration is : ", Ans)