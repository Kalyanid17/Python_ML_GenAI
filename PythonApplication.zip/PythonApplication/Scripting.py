#level 0 , not reusable, sequential execution

No1  = 0
No2 = 0
Ans = 0

No1 = (int(input("Enter First no :")))
No2 = (int(input("Enter Second no :")))

Ans = No1 + No2
print("Addition is : ", Ans)

Ans = No1 - No2
print("Substration is : ", Ans)