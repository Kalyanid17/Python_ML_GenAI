from math import *

result = sqrt(16)
print("Squareroot is : ", result)