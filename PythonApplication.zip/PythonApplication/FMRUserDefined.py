from functools import reduce

CheckEven = lambda No : (No%2 == 0)
Increament = lambda No : (No + 1)
Add = lambda A,B : (A+B)

def filterX(Task, Elements):
    Result = list()

    for no in Elements:
        Ret = Task(no)
        
        if (Ret == True) :
            Result.append(no)

    return Result

def main():
    Data = [11,10,15,20,22,27,30]
    print("Actual Data is : ",Data)

    FData = list(filterX(CheckEven,Data)) #Should pass value of such function which accepts only 1 i/p and returns bool
    print("Data after filter is : ", FData)

    MData = list(map(Increament,FData))
    print("Data after Map is : ", MData)

    RData = reduce(Add, MData)
    print("Data after Reduce is : ", RData)
    
if(__name__ == "__main__"):
    main()

    