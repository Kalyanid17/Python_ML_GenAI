import os
    
def main():
    print(os.cpu_count()) #8

if(__name__ == "__main__"):
    main()

# No of processes in parallel can run as 8, no of cores = 8
# Logical parts of microprocessor