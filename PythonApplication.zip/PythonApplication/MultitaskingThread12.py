import threading
import time
    
def SumEven(No):
    sum = 0
    for i in range(2,No+1,2):
        sum = sum + i
    print("Sum of Even nos is : ", sum)

def SumOdd(No):
    sum = 0
    for i in range(1,No+1,2):
        sum = sum + i
    print("Sum of Odd nos is : ", sum)

def main():

    start_time = time.time()
    t1 = threading.Thread(target = SumEven, args=(100000000,))
    t2 = threading.Thread(target = SumOdd, args=(100000000,))

    
    t1.start()
    t2.start()

    t1.join()
    t2.join()

    end_time = time.time()
    print("Time required : ", end_time-start_time) #Time required :  2.4158380031585693

if(__name__ == "__main__"):
    main()

#