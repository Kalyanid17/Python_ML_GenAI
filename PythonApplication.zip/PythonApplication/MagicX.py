#Dunder method/ Magic method / Specisl Method

class Demo:
    def __init__(self,A):
        self.No = A

    def __add__(self,other):    #other can be replaced, __add__ can not be changed, this is special name by Python
        return self.No + other.No

obj1 = Demo(11)
obj2 = Demo(21)

print(11+21)
print(obj1 + obj2)