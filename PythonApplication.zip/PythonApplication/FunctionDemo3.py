# Not a good programming practice, empty function should conain pass
def main():
    print("Inside main")
    pass

if __name__ == "__main__":
    main()