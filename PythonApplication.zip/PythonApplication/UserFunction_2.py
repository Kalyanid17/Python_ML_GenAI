def Multiplication(Value1, Value2) :
    Ans = 0
    Ans = Value1 * Value2
    return Ans

print("Demo App")

No1 = 10 # Global or naked variable
No2 = 11
Result = 0

Result = Multiplication(No1, No2)
print("Result : ", Result)