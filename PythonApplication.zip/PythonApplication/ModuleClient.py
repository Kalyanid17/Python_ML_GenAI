import Marvellous

print("Inside Client: ", __name__)
print("Value of PI = ", Marvellous.PI)

Result = 0
Result = Marvellous.Add(11,10)
print("Addition is : ", Result)

Result = Marvellous.Sub(11,10)
print("Substraction is : ", Result)