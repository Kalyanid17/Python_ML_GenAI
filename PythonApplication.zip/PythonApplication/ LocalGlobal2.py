
no = 11 #Global, data definition statement
def Fun():
    print("Value of no from Fun is ", no) #11
    
print("Value of no is : ", no)  #11
Fun()
