import os

def main():
    print("PID of running process is : ", os.getpid())
    print("PID of Parent process is : ", os.getppid()) #pp - parent process

if(__name__ == "__main__"):
    main()

#
#command prompt i.e parent  process - i.e 809 
#multiple times when prog is run everytime PID gets changed.
#PID of running process is :  1012
#PID of Parent process is :  809
#PratikMuluks-MacBook-Air:KalyaniPython pratik.muluk$  python3 ProcessID.py 
#PID of running process is :  1022
#PID of Parent process is :  809
#