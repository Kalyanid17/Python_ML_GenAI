
print("Enter firt no : ")
No1=input()

print("Enter second no : ")
No2=input()

print(type(No1))
print(type(No2))
Ans= int (No1) + int(No2)

print(type(No1))
print(type(No2))
print("Addition : " ,Ans)