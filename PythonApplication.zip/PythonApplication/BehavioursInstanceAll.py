class Demo:
    No = 10

    def __init__(self,A,B):
        self.Value1 = A
        self.Value2 = B

    def Fun(self):
        print("Inside Instance method Fun", self.Value1, self.Value2)

    @classmethod
    def Sun(cls):
        print("Inside class method Sun", cls.No)

    @staticmethod   #optional, but good practice it tells that its sstatic method
    def gun():
        print("Inside static method gun", Demo.No)


Demo.Sun()
print("Class Variable No: ", Demo.No)

obj = Demo(11,21)
obj.Fun()

print("Instance variable : ", obj.Value1, obj.Value2)

Demo.gun()