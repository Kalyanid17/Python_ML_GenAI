def Multiplication(Value1, Value2) :
    Ans = 0
    Ans = Value1 * Value2
    return Ans

No1 = 0
No2 = 0 
Result = 0

No1 = int(input("Enter First No : "))
No2 = int(input("Enter SEcond No : "))

Result = Multiplication(No1, No2)
print("Multiplication : ", Result)
################################
No1 = int(input("Enter First No : "))
No2 = int(input("Enter SEcond No : "))

Result = Multiplication(No1, No2)
print("Multiplication : ", Result)