Age = 35    #int
Marks = 90.86   # float
City="Pune"     #str
Food = False    #bool
Complex = 7+9j  #complex

print("Age:", type(Age))
print(type(Marks))
print(type(City))
print(type(Food))
print(type(Complex))