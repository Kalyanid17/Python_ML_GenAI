Information={"Name":"Rahul","Age":35,"City":"Pune","Marks":89.90,"City":"Mumbai"}
print(type(Information))
print(Information)
      
print(Information["City"])   #Pune     
Information["Age"]=26
print(Information)
