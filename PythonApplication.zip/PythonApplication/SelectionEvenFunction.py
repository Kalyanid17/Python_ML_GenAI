#Functional Approach

def CheckEven(No):
    if(No%2 == 0):
        print('It is Even') #Generally dont print inside function, not good practice
    else:
        print('It is Odd')

def main():
    CheckEven(21)       #Positional
    CheckEven(No=22)    #Keyword

if(__name__ == "__main__"):
    main() 

