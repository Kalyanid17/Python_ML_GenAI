print("Jai Gurudev")
