
from functools import reduce

def main():
    Data = [11,10,15,20,22,27,30]
    print("Actual Data is : ",Data)

    FData = list(filter((lambda No : (No%2 == 0)),Data)) #Should pass value of such function which accepts only 1 i/p and returns bool
    print("Data after filter is : ", FData)

    MData = list(map((lambda No : (No + 1)),FData))
    print("Data after Map is : ", MData)

    RData = reduce((lambda A,B : (A+B)), MData)
    print("Data after Reduce is : ", RData)
    
if(__name__ == "__main__"):
    main()

    