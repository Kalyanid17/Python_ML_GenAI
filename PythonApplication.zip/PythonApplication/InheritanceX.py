class Parent():
    
    def __init__(self):
        print("Inside Parent Constructor")
        self.No1 = 10
        self.No2 = 20

    def Fun(self):
        print("Inside fun method of parent", self.No1, self.No2)

class Child(Parent):
    def __init__(self):
        super().__init__()
        print("Inside Child Constructor")
        self.A = 11
        self.B = 21

    def sun(self):
        print("Inside sun method of child", self.A,self.B,self.No1,self.No2) #super is needed for ininit method, if parent has instance vars

cObj = Child()

print(cObj.No1) #10
print(cObj.No2) #20

print(cObj.A)   #11
print(cObj.B)   #21

cObj.Fun()
cObj.sun()
