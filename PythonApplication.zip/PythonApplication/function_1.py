No1 = 10
No2 = 11
ans = No1*No2
print("Mult is :", ans)

