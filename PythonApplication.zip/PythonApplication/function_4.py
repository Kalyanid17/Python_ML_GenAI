print("Enter 1st no :")
No1 = int(input())
print("Enter 2nd no :")
No2 = int(input())

ans = No1 * No2
print("Mult is :", ans)

print("-"*10)

print("Enter 1st no :")
No1 = int(input())
print("Enter 2nd no :")
No2 = int(input())

ans = No1 * No2
print("Mult is :", ans)

