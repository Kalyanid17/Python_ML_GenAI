#Script.py TimeInterval Source
#This script creates a backup of given Source folder and store compressed version of it 
#Implement Logging functionality in DataScheild Application

#Please add below features in "Marvellous Data Scheild" system
# 1. Logging System
# . Creare a Logs/Folder
# . Store : Backup start time, Files copied,Zip file name, Errors(if any)
#********************************************************************************#
# 2. Email Notiffication
# . Send an email after backup completion
# . Attach :
# . Log 
# . Zip file name
#********************************************************************************#
# 3. Restore Feature
# . Add a command:
# python Script.py --restore ZipFileName Destination
# . Extract backup to given directory
#********************************************************************************#
# 4. Exclude Files/Folders
# .tmp,.log,.exe
# or user-defined extensions
#********************************************************************************#
# 5. Backup History Tracker
# . Maintain a file:
#   . Date
#   . Number of files
#   . Zip size
# Display history using:
# python Script.py --history
#********************************************************************************#

from email.message import EmailMessage
from DataScheildModule import isDirectory,BackupFiles,MakeZipFile
import schedule
import sys      
import time 
import zipfile
from email.mime.multipart import MIMEMultipart 
from email import encoders
from MailModule import send_mail

def prepare_mail(LogFileName, zipFName):
    sender_email = "kalyanid17python.test@gmail.com"

    app_password = "iqym toim nlyp fezw"

    receiver_email = "kalyanipratik1703@gmail.com"

    subject = "DataScheild Application Backup"

    themsg = EmailMessage()
    themsg['Subject'] = subject
    themsg['To'] = ', '.join(receiver_email) if ',' in receiver_email else receiver_email
    themsg['From'] = sender_email

    #Zip File Attachment

    with open(zipFName, "rb") as f:
        file_data = f.read()
        file_name = f.name

    themsg.add_attachment(
        file_data,
        maintype="application",
        subtype="zip",
        filename=file_name,
    )

    #LogFile Attachment
    with open(LogFileName, "rb") as f:
        file_data = f.read()
        file_name = f.name

    themsg.add_attachment(
        file_data,
        maintype="application",
        subtype="txt",
        filename=file_name,
    )

    #themsg.set_content("All Files from Source folder are backed up Succefully.\nRegards,\nMarvellous Infosystems")

    send_mail(sender_email,app_password,receiver_email,subject,themsg)

    print("Marvellous mail Sent Successfully")

def StartBackup(Source,  Destination="MarvellousBackup"):
    Border = "-"*70
    Timestamp = time.ctime()
    LogFileName = "Log.txt_%s"%Timestamp
    
    lObj = open(LogFileName, "w")
    lObj.write(Border+"\n")
    lObj.write("\n========================DataScheild Application=======================\n")
    lObj.write(Border+"\n")

    lObj.write(Border + "\n")
    lObj.write("Backup Activity Started \n")
    lObj.write(f"Backup  {sys.argv[2]} start time : "+ time.ctime() +"\n")
    lObj.write(Border + "\n")

    if(isDirectory(Source)):
       
        files =  BackupFiles(Source, lObj, Destination)
        
        #Zip Backup folder
        zipFName = MakeZipFile(Destination)
        prepare_mail(LogFileName,zipFName)
    else:
        lObj.write(f"{Source} Is NOT a Directory. Please provide DirectoryName to be backed up!")

    lObj.write(Border + "\n")
    lObj.write("Backed up file count :"+ str(len(files)) +"\n")
    lObj.write("Compressed file Name : " + zipFName +"\n")
    lObj.write(Border + "\n")

    lObj.write(Border+"\n")
    lObj.write("\n=============Thank you for using DataScheild Application===============\n")
    lObj.write(Border+"\n")

def main():

    if(len(sys.argv) == 2):
        if(sys.argv[1] == "--h" or sys.argv[1] == "--H"):
            print("This script is used to : \n")
            print("1. Take auto backup in given interval of time.\n")
            print("2. Takes backup for only updated and Newly created files.\n")
            print("3. Compress the backedd up folder.\n") 
        elif(sys.argv[1] == "--u" or sys.argv[1] == "--U"):
            print("Usage : ScriptName.py TimeInterval Source.\n")
            print("TimeInterval : Provide time in minutes/hours after which back up should run.\n")
            print("Source : Provide Source folder name which should get backed up.\n")
        else:
            print("No such option\n")
            print("Please use --h Or --u\n")

    elif(len(sys.argv) == 3):
    
        print("Press Cntrl + C to stop backup process.")
        schedule.every(int(sys.argv[1])).seconds.do(StartBackup, sys.argv[2])

        while(True):
            schedule.run_pending()
            time.sleep(1)

    else:
        print("Invalid Number of Arguments.\n")
        print("Please use --h Or --u\n")
           

if __name__ == "__main__":
    main()