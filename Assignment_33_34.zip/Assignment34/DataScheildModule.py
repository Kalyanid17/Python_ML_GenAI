
import os
import time
import shutil
import hashlib
import zipfile

def MakeZipFile(Folder):
    Timestamp = time.strftime("_%d-%m-%Y-%H-%M-%S")      
    zipName = Folder + "%s.zip" %Timestamp

    zObj = zipfile.ZipFile(zipName, "w", zipfile.ZIP_DEFLATED)

    for root, dirs, files in os.walk(Folder):

        for file in files:
            full_path = os.path.join(root, file)
            relative = os.path.relpath(full_path,Folder)
            zObj.write(full_path,relative)

    zObj.close()
    return zipName

def getChecksum(path):

    fObj = open(path, "rb")
    hObj = hashlib.md5()

    buffer = fObj.read(1024)

    while len(buffer) > 0:
        hObj.update(buffer)
        buffer = fObj.read(1024)

    return hObj.hexdigest()

def BackupFiles(Source,lObj,Destination,ExcludeExt=[]):
        
        os.makedirs(Destination,exist_ok=True)
        #Traverse Directory, subDir and Files using os.walk

        for root, dirs, files in os.walk(Source):
            
            for file in files:
                
                Ext = file.split(".")[1]
                
                if Ext not in (ExcludeExt):

                    src_path = os.path.join(root,file)
                    #print("Abs src_path : ", src_path)
                    relative_path = os.path.relpath(src_path,Source)
                    #print("Relative : ", relative_path)
                    dest_path = os.path.join(Destination, relative_path)
                    #print("Abs dest_path : ", dest_path)
                    os.makedirs(os.path.dirname(dest_path), exist_ok=True)

                    #Copy file if its new or modified
                    if((not os.path.exists(dest_path)) or (getChecksum(src_path) != getChecksum(dest_path))):
                        shutil.copy2(src_path, dest_path)
        return files

def isDirectory(Path):
    if(os.path.exists(Path)):
        if(os.path.isdir(Path)):
            return True
    else:
        return False