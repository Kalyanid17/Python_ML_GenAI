#Script.py TimeInterval Source
#This script creates a backup of given Source folder and store compressed version of it 
#Implement Logging functionality in DataScheild Application

#Please add below features in "Marvellous Data Scheild" system
# 1. Logging System
# . Creare a Logs/Folder
# . Store : Backup start time, Files copied,Zip file name, Errors(if any)
#********************************************************************************#
# 2. Email Notiffication
# . Send an email after backup completion
# . Attach :
# . Log 
# . Zip file name
#********************************************************************************#
# 3. Restore Feature
# . Add a command:
# python Script.py --restore ZipFileName Destination
# . Extract backup to given directory
#********************************************************************************#
# 4. Exclude Files/Folders
# .tmp,.log,.exe
# or user-defined extensions
#********************************************************************************#
# 5. Backup History Tracker
# . Maintain a file:
#   . Date
#   . Number of files
#   . Zip size
# Display history using:
# python Script.py --history
#********************************************************************************#

from email.message import EmailMessage
from DataScheildModule import isDirectory,BackupFiles,MakeZipFile
import schedule
import sys      
import time 
import zipfile
from email.mime.multipart import MIMEMultipart 
from email import encoders
from MailModule import send_mail
import os

def ExtractZip(zipFNm, folder):
    zip_path = os.path.abspath(zipFNm)
    if(os.path.exists(zip_path) and os.path.exists(folder)):
        if(zipfile.is_zipfile(zip_path)):
            zObj = zipfile.ZipFile(zip_path, "r")
            zObj.extractall(folder)
            print("Extraction Successful.")

def prepare_mail(LogFileName, zipFName):
    sender_email = "kalyanid17python.test@gmail.com"

    app_password = "iqym toim nlyp fezw"

    receiver_email = "kalyanipratik1703@gmail.com"

    subject = "DataScheild Application Backup"

    themsg = EmailMessage()
    themsg['Subject'] = subject
    themsg['To'] = ', '.join(receiver_email) if ',' in receiver_email else receiver_email
    themsg['From'] = sender_email

    #Zip File Attachment

    with open(zipFName, "rb") as f:
        file_data = f.read()
        file_name = f.name

    themsg.add_attachment(
        file_data,
        maintype="application",
        subtype="zip",
        filename=file_name,
    )

    #LogFile Attachment
    with open(LogFileName, "rb") as f:
        file_data = f.read()
        file_name = f.name

    themsg.add_attachment(
        file_data,
        maintype="application",
        subtype="txt",
        filename=file_name,
    )

    #themsg.set_content("All Files from Source folder are backed up Succefully.\nRegards,\nMarvellous Infosystems")

    send_mail(sender_email,app_password,receiver_email,subject,themsg)

    print("Marvellous mail Sent Successfully")

def StartBackup(Source,  Destination="MarvellousBackup", ExtExclude=[]):
    Border = "-"*70
    Timestamp = time.ctime()
    LogFileName = "Log.txt_%s"%Timestamp
    HistoryFileName = "History.txt"
    
    lObj = open(LogFileName, "w")
    lObj.write(Border+"\n")
    lObj.write("\n====================DataScheild Application===================\n")
    lObj.write(Border+"\n")

    hObj = open(HistoryFileName, "a")
    hObj.write(Border+"\n")
    hObj.write("\n====================DataScheild Application History===================\n")
    hObj.write(Border+"\n")

    lObj.write(Border + "\n")
    lObj.write("Backup Activity Started \n")
    lObj.write(f"Backup  {sys.argv[2]} start time : "+ time.ctime() +"\n")
    lObj.write(Border + "\n")

    if(isDirectory(Source)):
       
        files =  BackupFiles(Source, lObj, Destination, ExtExclude)
        
        #Zip Backup folder
        zipFName = MakeZipFile(Destination)
        prepare_mail(LogFileName,zipFName)
    else:
        lObj.write(f"{Source} Is NOT a Directory. Please provide DirectoryName to be backed up!")

    lObj.write(Border + "\n")
    lObj.write("Backed up file count :"+ str(len(files)) +"\n")
    lObj.write("Compressed file Name : " + zipFName +"\n")
    lObj.write(Border + "\n")

    hObj.write(Border + "\n")
    hObj.write("Backed up At :"+ (zipFName.split("_")[1]).split(".")[0] +"\n")
    hObj.write("Backed up file count :"+ str(len(files)) +"\n")
    hObj.write("Compressed file Name : " + zipFName +"\n")
    hObj.write("Compressed file Name Size: " + str(sys.getsizeof(zipFName)) +"\n")
    hObj.write(Border + "\n")

    lObj.write(Border+"\n")
    lObj.write("\n=============Thank you for using DataScheild Application===============\n")
    lObj.write(Border+"\n")

    lObj.close()
    hObj.close()

def main():

    if(len(sys.argv) == 2):
        if(sys.argv[1] == "--h" or sys.argv[1] == "--H"):
            print("This script is used to : \n")
            print("1. Take auto backup in given interval of time.\n")
            print("2. Takes backup for only updated and Newly created files.\n")
            print("3. Compress the backedd up folder.\n") 
            print("4. Restore the given Zip file to given folder.\n") 
            print("5. Exclude given Extension file while backup.\n") 
            print("6. Show history.\n") 
        elif(sys.argv[1] == "--u" or sys.argv[1] == "--U"):
            print("Usage : ScriptName.py TimeInterval Source.\n")
            print("TimeInterval : Provide time in minutes/hours after which back up should run.\n")
            print("Source : Provide Source folder name which should get backed up.\n")
        elif(sys.argv[1] == "--history" or sys.argv[1] == "--History"):
            print("Displaying History\n")
            hObj = open("History.txt", "r")
            print(hObj.read())
        else:
            print("No such option\n")
            print("Please use --h Or --u\n")

    #python3 Script.py 1 Data
    elif(len(sys.argv) == 3):

            print("Press Cntrl + C to stop backup process.")
            schedule.every(int(sys.argv[1])).seconds.do(StartBackup, sys.argv[2])

            while(True):
                schedule.run_pending()
                time.sleep(1)
    #python Script.py --restore ZipFileName Destination
    elif(len(sys.argv) == 4):
    
        #print("Press Cntrl + C to stop backup process.")
        #schedule.every(int(sys.argv[1])).seconds.do(StartBackup, sys.argv[2], sys.argv[3], sys.argv[5])
        if(sys.argv[1] == "--restore"):
            zipFileNm = sys.argv[2]
            folderNm = sys.argv[3]
            ExtractZip(zipFileNm,folderNm)
    #python3 Script.py 1 Data --exclude [.txt,.tmp]
    elif(len(sys.argv) == 5):
    
        if(sys.argv[3] == "--exclude"):
            print("Press Cntrl + C to stop backup process.")
            schedule.every(int(sys.argv[1])).seconds.do(StartBackup, Source=sys.argv[2], ExtExclude=sys.argv[4])
        
            while(True):
                schedule.run_pending()
                time.sleep(1)

    else:
        print("Invalid Number of Arguments.\n")
        print("Please use --h Or --u\n")
           

if __name__ == "__main__":
    main()