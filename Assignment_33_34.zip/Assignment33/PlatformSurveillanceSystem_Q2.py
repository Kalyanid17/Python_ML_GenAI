
# 2. Add Open Files Monitoring Feature
# For each running process Display :
# No of files opened by Process 
# Requirement :
# Count open file descriptors using sys/library calls
# Handle permission error properly
# Mention "Access DEnied" in logs if required

import psutil
import sys
import os
import time
import schedule

def CreateLog(FolderName):
    Ret = False
    Border = "-"*50

    Ret = os.path.exists(FolderName)

    if(Ret == True):
          Ret = os.path.isdir(FolderName)

          if(Ret == False):
               print("Unable to create folder as it might be Filename")
               return       
    else:
          os.mkdir(FolderName)
          print("Directory for logfiles gets created succesfully.")
    
    TimeStamp = time.strftime("%Y-%m-%d_%H-%M-%S")
    LogFileName = os.path.join(FolderName, "Marvellous_%s.log")%(TimeStamp)
    print(LogFileName)

    fObj = open(LogFileName,"w")
    fObj.write(Border + "\n")
    fObj.write("====Marvellous Platform Serveillance System =====\n")
    fObj.write("Log Created at " + time.ctime() + "\n")
    fObj.write(Border + "\n\n")

    fObj.write("==================System Report=======================\n")

    #print("CPU Usage: ", psutil.cpu_percent())
    fObj.write("CPU Usage: %s %%\n" %psutil.cpu_percent())
    fObj.write(Border + "\n\n")
    mem = psutil.virtual_memory()
    fObj.write("RAM Usage: %s %%\n" %mem.percent)
    #print("RAM Usage : ", mem.percent)
    fObj.write(Border + "\n\n")

    fObj.write("Disk Usage Report \n")
    for part in psutil.disk_partitions():
         try:
            usage = psutil.disk_usage(part.mountpoint)
            #print(f"{part.mountpoint} Used {usage.percent}%%")
            fObj.write("%s -> %s %% used\n"%(part.mountpoint,usage.percent))
         except:
            pass
    fObj.write(Border + "\n\n")

    net = psutil.net_io_counters() 
    fObj.write("\nNetwork Usage Report\n")
    fObj.write("Sent :  %.2f MB\n" %(net.bytes_sent/(1024 * 1024)))
    fObj.write("Received :  %.2f MB\n" %(net.bytes_recv/(1024 * 1024)))
    #fObj.write("\n"*20)
    fObj.write(Border + "\n\n")

    #Process Log
    Data = ProcessScan()

    for info in Data:
        fObj.write("PID : %s\n" %info.get("pid"))
        fObj.write("Name : %s\n" %info.get("name"))
        fObj.write("Username : %s\n" %info.get("username"))
        fObj.write("Status : %s\n" %info.get("status"))
        fObj.write("Start time : %s\n" %info.get("create_time"))
        fObj.write("CPU %% : %.2f\n" %info.get("cpu_percent"))
        fObj.write("Memory %% : %.2f\n" %info.get("memory_percent"))
        fObj.write("No of threads created by Process : %d\n" %info.get("num_threads"))
        #Q2
        fObj.write("No of files openend by Process : %d\n" %len(info.get("open_files")))

        fObj.write(Border + "\n\n")

    fObj.write(Border + "\n")
    fObj.write("==============End of Log File ======================\n")
    fObj.write(Border + "\n")

def ProcessScan():
     listprocess = []

    #Warm up for CPU percent
     for proc in psutil.process_iter():
          try:
               proc.cpu_percent()
          except:
               pass
          
     time.sleep(0.2) #seconds

     for proc in psutil.process_iter():
          try:
            info = proc.as_dict(attrs=["pid","name","username","status","create_time","num_threads","open_files"])
            #Convert create_time
            try:
                info["create_time"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(info["create_time"]))
            except:
               info["create_time"] = "NA"

            info["cpu_percent"] = proc.cpu_percent(None)
            info["memory_percent"] = proc.memory_percent()
            
            info["open_files"] = proc.open_files()

            listprocess.append(info)
          except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass
     return listprocess

#Command Line Input
def main():

    Boredr = "-"*50
    print(Boredr)
    print("====Marvellous Platform Serveillance System =====")
    print(Boredr)

    if(len(sys.argv) == 2):
        if(sys.argv[1] == "--h" or sys.argv[1] == "--H"):
            print("This script is used to :")
            print("1 : Create automatic logs")
            print("2 : Execute periodically")
            print("3 : Send mail with logs")
            print("4 : Store Info about Processes")
            print("5 : Store Info about CPU")
            print("6 : Store Info about RAM USAGE")
            print("7 : Store Info about Secondary storage")

        elif(sys.argv[1] == "--u" or sys.argv[1] == "--U"):
            print("Use the automation script as ")
            print("ScriptName.py TimeInterval DirectoryName")
            print("TimeInterval : Time in minutes for periodic scheduling")
            print("DirectoryName : Name of Directory autolog(creates folder and put log file inside it)")
        else:
            print("Unable to proceed as there is no such option")
            print("Unable to proceed as there is no such optionPlease use --h or --u")
    elif(len(sys.argv) == 3):
        #python3 Demo.py 5 Marvellous
        
            print("Inside project logic")
            print("Time interval : ", sys.argv[1])
            print("Directory Name : ", sys.argv[2])

            #apply the scheduler
            #schedule.every(int(sys.argv[1])).minutes.do(CreateLog,sys.argv[2])
            schedule.every(int(sys.argv[1])).seconds.do(CreateLog,sys.argv[2])
            
            print("Marvellous Platform Serveillance System started successfully")
            print("Directory created with name ", sys.argv[2])
            print("Time Interval in minutes : ", sys.argv[1])
            print("Press Ctrl+C to stop the execution")

            #Wait till abort
            while(True):
                 schedule.run_pending()
                 time.sleep(1)
    else:
        print("Invalid no of Args")
        print("Unable to proceed as there is no such option")
        print("Unable to proceed as there is no such optionPlease use --h or --u")

    print(Boredr)
    print("=========Thank you for using our script.==========")
    print(Boredr)

if(__name__ == "__main__"):
    main()