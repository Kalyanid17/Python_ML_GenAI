
#kalyanid17python.test@gmail.com
#pass : Kalyanid17python
#app_password = "iqym toim nlyp fezw", generated from Gmail acc->security->App Password, 2 step varication should be turned on
import smtplib
from email.message import EmailMessage

def send_mail(sender, app_password, receiver, subject, body):
    
    msg = EmailMessage()

    msg["From"] = sender
    msg["To"] = receiver
    msg["Subject"] = subject

    msg.set_content(body)

    smtp = smtplib.SMTP_SSL("smtp.gmail.com", 465)
    
    smtp.login(sender, app_password)
    
    smtp.send_message(msg)
    
    smtp.quit()
