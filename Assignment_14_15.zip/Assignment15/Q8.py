##Write a lambda function using filter() which accepts list of no and returns list of no
#which are divisible by 3 and 5 both

isDivisible = lambda No : No % 3 == 0 and No % 5 == 0

def main():

    Data = []
    print("How many numbers : ")
    Cnt = int(input())

    print("Enter  Numbers : ")
    for i in range(Cnt):
        Data.append(int(input()))

    Res = list(filter(isDivisible, Data))

    print("Nos divisible by 3 and  5  are : ", Res)

if(__name__ == "__main__"):
    main()
    