#Write lambda function using reduce() which accepts list of nos and returns min element

from functools import reduce
min = lambda A,B : A if A < B else B

def main():

    Data = []
    print("How many numbers : ")
    Cnt = int(input())

    print("Enter  nnumbers : ")
    for i in range(Cnt):
        Data.append(int(input()))

    Res = reduce(min, Data)

    print("Min : ", Res)

if(__name__ == "__main__"):
    main()
    
