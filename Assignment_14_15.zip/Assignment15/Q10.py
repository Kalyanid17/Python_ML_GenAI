#rite a lambda function using filter() which accepts list of no and returns count of even nos
isEven = lambda No : No % 2 == 0 

def main():

    Data = []
    print("How many numbers : ")
    Cnt = int(input())

    print("Enter  Numbers : ")
    for i in range(Cnt):
        Data.append(int(input()))

    Res = list(filter(isEven, Data))

    #print(Res)
    print("Count of Even numbers : ", len(Res))

if(__name__ == "__main__"):
    main()
    