#Write a lambda function using filter() which accepts list of strings and returns list of strings
#having length > 5

isValidStr = lambda s : len(s) > 5

def main():

    Data = []
    print("How many strings : ")
    Cnt = int(input())

    print("Enter  strings : ")
    for i in range(Cnt):
        Data.append(input())

    Res = list(filter(isValidStr, Data))

    print("Strings having length > 5  are : ", Res)

if(__name__ == "__main__"):
    main()
    