#Write a lambda functin using reduce() which accepts list of nos and returns addition of all elements

from functools import reduce

Add = lambda No1,No2 :  No1 + No2 

def main():
    
    Data = []

    print("How many numbers you want to enter : ")
    cnt = int(input())

    print("Enter numbers : ")
    for i in range(cnt):
        Data.append(int(input()))

    ret = reduce(Add,Data)

    print("Addition is : ",ret)

if(__name__ == "__main__"):
    main()
