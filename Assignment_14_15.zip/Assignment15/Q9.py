#Write lambda function using reduce which accepts list of numbers and return multiplication of all nos
from functools import reduce

mult = lambda No1,No2 : No1*No2

def main():

    Data = []
    print("How many numbers : ")
    Cnt = int(input())

    print("Enter  Numbers : ")
    for i in range(Cnt):
        Data.append(int(input()))

    Res = int(reduce(mult, Data))

    print("Multiplication : ", Res)

if(__name__ == "__main__"):
    main()
    