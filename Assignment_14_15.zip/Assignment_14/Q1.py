#Write a lambda function to aacept 1 no and return its square

square = lambda No : No ** 2

def main():

    print("Enter a number : ")
    No1 = int(input())

    Ret = square(No1)

    print("Square is ", Ret) 

if(__name__ == "__main__"):
    main()