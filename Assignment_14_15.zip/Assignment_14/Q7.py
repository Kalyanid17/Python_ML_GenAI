#Write a lambda function accepting 1 no and return  True if its divisible by 5 else return false.

DivisibleFive = lambda A : A % 5  == 0

def main():
    print("Enter a no")
    No1 = int(input())

    Ret = DivisibleFive(No1)
    print(Ret)

    
if(__name__ == "__main__"):
    main()