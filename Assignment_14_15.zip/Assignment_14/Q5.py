#Write a lambda function accepting 1 no and return  True if the o is even else return false.

ChkEven = lambda A : A % 2  == 0

def main():
    print("Enter a no")
    No1 = int(input())

    Ret = ChkEven(No1)
    print(Ret)

    
if(__name__ == "__main__"):
    main()