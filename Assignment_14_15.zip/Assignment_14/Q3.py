#Write lambda function to aacepts 2 number and returns max number 

max = lambda A,B : A if (A > B) else B

def main():
    print("Enter 2 no")
    No1 = int(input())
    No2 = int(input())

    Ret = max(No1,No2)
    print("Max no is : ", Ret)

    
if(__name__ == "__main__"):
    main()