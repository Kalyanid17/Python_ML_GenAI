#Write a lambda function accepting 1 no and return  True if the o is Odd else return false.

ChkOdd = lambda A : A % 2  == 1

def main():
    print("Enter a no")
    No1 = int(input())

    Ret = ChkOdd(No1)
    print(Ret)

    
if(__name__ == "__main__"):
    main()