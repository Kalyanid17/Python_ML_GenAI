#Write a lambda function accepting 2 no and return  their multiplication
Mult = lambda A,B : A * B

def main():
    print("Enter 2 no")
    No1 = int(input())
    No2 = int(input())

    Ret = Mult(No1, No2)
    print("Multiplication is : ",Ret)

    
if(__name__ == "__main__"):
    main()