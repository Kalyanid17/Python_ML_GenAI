#Write a lambda function accepting 2 no and return  their addition
Add = lambda A,B : A + B

def main():
    print("Enter a no")
    No1 = int(input())
    No2 = int(input())

    Ret = Add(No1, No2)
    print("Addition is : ",Ret)

    
if(__name__ == "__main__"):
    main()