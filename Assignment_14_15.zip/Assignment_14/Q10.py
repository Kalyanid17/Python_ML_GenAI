#Write a lambda function accepting 3 no and return  largest
Mult = lambda A,B,C : max(A,B,C)

def main():
    print("Enter 3 no")
    No1 = int(input())
    No2 = int(input())
    No3 = int(input())

    Ret = Mult(No1, No2, No3)
    print("Largest no is : ",Ret)

    
if(__name__ == "__main__"):
    main()