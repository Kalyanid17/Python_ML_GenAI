##Write a lambda function to aacept 1 no and return its cube

cube = lambda No : No ** 3

def main():
    print("Enter a no")
    No1 = int(input())

    Ret = cube(No1)
    print("Cube of a no is : ", Ret)

    
if(__name__ == "__main__"):
    main()