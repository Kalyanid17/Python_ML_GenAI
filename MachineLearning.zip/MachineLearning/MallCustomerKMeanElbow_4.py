#UnSupervised Learning, no lables / No dependent variables

import pandas as pd
import matplotlib.pyplot as plt

from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

def main():
    #----------------------------------------------------
    # Step 1 : Load the dataset
    #----------------------------------------------------
    print("Step 1 : Load the dataset")
    df = pd.read_csv("Mall_Customers.csv")

    print("First few records : ")
    print(df.head())

    print("Shape of dataset : ")
    print(df.shape)

    print("Missing values : ")
    print(df.isnull().sum())

    #----------------------------------------------------
    # Step 2 : Select Features (Inpedependent)
    #----------------------------------------------------
    print("Step 2 : Select Features (Inpedependent)")
    
    X = df[["AnnualIncome","SpendingScore"]]
    print("Selected Features : ")
    print(X.head())

    print("Shape of selected features : ")
    print(X.shape)

    #----------------------------------------------------
    # Step 3: Scale the data
    #----------------------------------------------------
    # We need to scale the data since AnnualIncome and SpendingScore value has huge gap
    # e.g entries between 90 to 101, (103,23), (103,60), (113,43) etc.
    print("Step 3: Scale the data")
    scalar = StandardScaler()
    X_scaled = scalar.fit_transform(X)

    print("Data after scaling : ")
    print(X_scaled[:5]) # X_scaled becomes, rowwise data, but head method needs 
    # it as columnwise, hence instead of using head, we write :5 , it will give us 1st 5 rows

    #----------------------------------------------------
    # Step 4: Use elbow method
    #----------------------------------------------------
    print("Step 4: Use elbow method")

    WCSS = []
    for i in range(1,11):
        # how many times its should repeat  - n_init
        model = KMeans(n_clusters=i, random_state=42, n_init=10)
        model.fit(X_scaled)
        WCSS.append(model.inertia_)

    plt.figure(figsize=(8,5))
    plt.plot(range(1,11), WCSS, marker = 'o')
    plt.xlabel("Number of Clusters")
    plt.ylabel("WCSS")
    plt.title("Elbow method")
    plt.grid(True)
    plt.show()

    #----------------------------------------------------
    # Step 5: Train the model
    #----------------------------------------------------
    print("Step 5: Train the model")
    #Finally we decided the value off K = 4(i.e no of clusters we need to form)
    # consideringt this value as 4 , since graph indicates from k= 4 onwords
    # WCSS value started increasing, that means cluster started getting scattered.
    # hence, using graph (elbow like shape) we are considering k=4
    model = KMeans(n_clusters=4, random_state=42, n_init=10)
    clusters = model.fit_predict(X_scaled)
    df["cluster"] = clusters

    print("Dataset with cluster")
    print(df.head(50))
if (__name__ == "__main__"):
    main()