import pandas as pd
def main():

    sObj = pd.Series([11,21,51,101,111])
    print(sObj)


if __name__ == "__main__":
    main()