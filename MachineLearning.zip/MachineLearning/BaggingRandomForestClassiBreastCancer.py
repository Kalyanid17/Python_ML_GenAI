import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix


#------------------------------------------------------
# Step 1 : Load Dataset
#------------------------------------------------------

df = pd.read_csv("breast_cancer.csv")
print("Shape of dataset : ", df.shape)
print("First 5 records : ", df.head())

#------------------------------------------------------
# Step 2 : Seperate features and lables
#------------------------------------------------------

X = df.drop("target", axis = 1) # cut vertically , i.e axis =1
Y = df["target"]

#------------------------------------------------------
# Step 3 : Spilt dataset for training and testing
#------------------------------------------------------

X_train,X_test,Y_train,Y_test = train_test_split(X,Y,test_size=0.2,random_state=42)

#------------------------------------------------------
# Step 4 : Create Random Forest mmodel
#------------------------------------------------------

rf_model = RandomForestClassifier(
    n_estimators=10,
    random_state=42)

#------------------------------------------------------
# Step 5 : Train  mmodel
#------------------------------------------------------

rf_model.fit(X_train, Y_train)

#------------------------------------------------------
# Step 6: Test  mmodel
#------------------------------------------------------

Y_pred = rf_model.predict(X_test)

#------------------------------------------------------
# Step 7: Evaluate  mmodel
#------------------------------------------------------

print("Bagging Random Forest Accuracy : ", accuracy_score(Y_test,Y_pred))
print("Confusion matrix: ")
print(confusion_matrix(Y_test,Y_pred)) 

# Bagging Accuracy :  0.956140350877193
# Confusion matrix: 
# [[40  3]
#  [ 2 69]]