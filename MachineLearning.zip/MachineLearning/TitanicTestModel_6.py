
import pandas as pd
import numpy as np
import joblib 


from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score,confusion_matrix

# K and R Header writing style

#-------------------------------------------------------
# Function name : LoadPreservedModel
# Description : It is used to load preserve model
# Parameters :  filename

# Return :  model
# Date : 14/03/2026
# Author : Kalyani Darekar
#-------------------------------------------------------
def LoadPreservedModel(filename):
    loaded_model = joblib.load(filename)

    print("Model loaded successfully")
    return loaded_model
#-------------------------------------------------------
# Function name : PreserveModel
# Description : It is used to preserve model in secondary
# Parameters : model, filename
#              df -> Pandas Dataframe object
#              message
#              message -> heading text to display
# Return :  None
# Date : 14/03/2026
# Author : Kalyani Darekar
#-------------------------------------------------------

def PreserveModel(model, filename):
    joblib.dump(model,filename=filename)

    print("Model preserved successfully with name", filename)
#-------------------------------------------------------
# Function name : TrainTitanicModel
# Description : It does split X, Y, training data, testing adata
# Parameters : df
#              df -> Pandas Dataframe object
#              message
#              message -> heading text to display
# Return :  None
# Date : 14/03/2026
# Author : Kalyani Darekar
#-------------------------------------------------------

def TrainTitanicModel(df):
    #Split Features and labels
    X = df.drop("Survived", axis=1)
    Y = df["Survived"]

    print("Features : ")
    print(X.head())

    print("Labels : ")
    print(Y.head())

    print("Shape of X: ", X.shape)
    print("Shape of Y: ", Y.shape)

    X_train,X_test,Y_train,Y_test = train_test_split(X,Y,test_size=0.2,random_state=42)
    print("Shape X_train : ", X_train.shape)
    print("Shape X_test : ", X_test.shape)
    print("Shape Y_train : ", Y_train.shape)
    print("Shape Y_test : ", Y_test.shape)

    model = LogisticRegression(max_iter=1000)

    model.fit(X_train, Y_train)

    print("Model trained successfully")

    print("Intercept of model: ", model.intercept_)

    print("Coefficient of model")
    for feature, coeff in zip(X.columns,model.coef_[0]):
        print(feature, ":" , coeff)
    
    PreserveModel(model,"marvelloustitanic.pkl")
    loaded_model = LoadPreservedModel("marvelloustitanic.pkl")

    Y_pred = loaded_model.predict(X_test)

    acc = accuracy_score(Y_pred, Y_test)
    print("Accuracy : ", acc*100)

    cm = confusion_matrix(Y_pred, Y_test)
    print("Confusion Mattrix is : ", cm)
#-------------------------------------------------------
# Function name : ShowData
# Description : It displays basic information about the dataset
# Parameters : df
#              df -> Pandas Dataframe object
#              message
#              message -> heading text to display
# Return :  None
# Date : 14/03/2026
# Author : Kalyani Darekar
#-------------------------------------------------------
def ShowData(df,message):
    DisplayInfo(message)

    print("\nFirst 5 lines of Dataset : ")
    print(df.head())

    print("\nShape of Dataset : ")
    print(df.shape)

    print("\nColumn Names : ")
    print(df.columns.tolist())

    print("\nMissing values in each column : ")
    print(df.isnull().sum())
#-------------------------------------------------------
# Function name : DisplayInfo
# Description : It displays formatted title
# Parameters : title (str)
# Return :  None
# Date : 14/03/2026
# Author : Kalyani Darekar
#-------------------------------------------------------
def DisplayInfo(title):
    print("\n" + "="*70)
    print(title)
    print("="*70)

#-------------------------------------------------------
# Function name : CleanTitanicData
# Description : It does preprocessing
#               It removes unneccessary columns
#               It handles missing values
#               It Converts text data to numeric format
#               It Does encoding to categorical columns
# Parameters : df -> pandas dataframe
# Return :  df -> cleaned pandas dataframe
# Date : 14/03/2026
# Author : Kalyani Darekar
#-------------------------------------------------------
def CleanTitanicData(df):
    DisplayInfo("Step 2 : Original Data")
    print(df.head())

    # Remove unneccessary columns
    # Zero column has all values as zero, which is not affecting the result, hence can be reoved
    # Passengerid is also not affecting the result, i.e survived column, hence can be removed
    drop_columns = ["Passengerid", "zero", "Name", "Cabin"]
    existing_columns = [col for col in drop_columns if col in df.columns]

    print("\n Columns to be dropped : ")
    print(existing_columns)

    # Drop unwanted columns
    df = df.drop(columns=existing_columns)
    DisplayInfo("Step 2 : Data after column removal")
    print(df.head())

    # Handle age column (missing values can be reolaced with median )
    if("Age" in df.columns):
        print("Age column before filling missing values")
        print(df["Age"].head(10))

        #coerce -> Invalid value gets converted info NaN
        df["Age"] = pd.to_numeric(df["Age"], errors="coerce") 

        age_median = df["Age"].median()

        #Relace missing values with median
        df["Age"] = df["Age"].fillna(age_median) 

        print("Age column after preprocessing")
        print(df["Age"].head(10))

    # Handle Fare column (missing values can be reolaced with median )
    if("Fare" in df.columns):
        print("\n Fare column before preprocessing")
        print(df["Fare"].head(10))

        df["Fare"] = pd.to_numeric(df["Fare"], errors="coerce") 

        fare_median = df["Fare"].median()

        print("\nMedian of Fare column is  : ", fare_median)

        #Relace missing values with median
        df["Fare"] = df["Fare"].fillna(fare_median) 

        print("Fare column after preprocessing")
        print(df["Fare"].head(10))

    # Handle Embarked column
    if("Embarked" in df.columns):
        print("\n Embarked column before preprocessing")
        print(df["Embarked"].head(10))

        # astype -> Converts the data in string
        df["Embarked"] = df["Embarked"].astype(str).str.strip()     #astype is like tostring()

        # Remove missing values
        df["Embarked"] = df["Embarked"].replace(['nan','None',''], np.nan)

        # mode() - Get most frequent value
        embarked_mode = df["Embarked"].mode()[0]
        print("Mode of embarked column: ", embarked_mode)

        df["Embarked"] = df["Embarked"].fillna(embarked_mode)

        print("Embarked column after preprocessing")
        print(df["Embarked"].head(10))

     # Handle Sex column
    if("Sex" in df.columns):
        print("\n Sex column before preprocessing")
        print(df["Sex"].head(10))

        df["Sex"] = pd.to_numeric(df["Sex"], errors="coerce") 

        print("Sex column after preprocessing")
        print(df["Sex"].head(10))

    DisplayInfo("Data after preprocessing")
    print(df.head())

    print("Missing values after preprocessing") #Missing values before was 2 for Embarked column
    print(df.isnull().sum())

    #Encode Embarked column
    df = pd.get_dummies(df,columns=["Embarked"],drop_first=True)
    print("\nData after encoding")

    print(df.head(10))

    print("Shape of dataset : ", df.shape)

    #Convert boolean columns into integer
    for col in df.columns:
        if(df[col].dtype == bool):
            df[col] = df[col].astype(int)

    DisplayInfo("Data after encoding")
    
    print(df.head())


    return df
#-------------------------------------------------------
# Function name : MarvellousTitanicLogistic
# Description : This is main pipeline controller
#               It loads the dataset, show raw data, p
#               reprocess the dataset and train the model
# Parameters : Datapath of dataset file
# Return :  None
# Date : 14/03/2026
# Author : Kalyani Darekar
#-------------------------------------------------------
def MarvellousTitanicLogistic(Datapath): 
    DisplayInfo("Step1 : Loading the dataset")
    df = pd.read_csv(Datapath)

    ShowData(df,"Initial Dataset")
    df = CleanTitanicData(df)

    TrainTitanicModel(df)

#-------------------------------------------------------
# Function name : main
# Description : startin g point of app
# Parameters : None
# Return :  None
# Date : 14/03/2026
# Author : Kalyani Darekar
#-------------------------------------------------------

def main():
    MarvellousTitanicLogistic("MarvellousTitanicDataSet.csv")


if(__name__== "__main__"):
    main()