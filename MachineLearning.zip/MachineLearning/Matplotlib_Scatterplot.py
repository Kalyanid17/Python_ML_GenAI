import matplotlib.pyplot  as plt
import seaborn as sns

def main():

    #Linear Relationship (Features)
    sns.scatterplot(x = [1,2,3], y=[3,1,4]) # for feature analysis, shows relationship in x and y
    plt.show()


if(__name__ == "__main__"):
    main()

