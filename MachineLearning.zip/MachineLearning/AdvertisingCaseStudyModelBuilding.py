#industrial
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error,r2_score

def MarvellousAdvertise(Datapath):
    Border = "-"*40
    #--------------------------------------------------#
    # Step 1 : Load Dataset
    #--------------------------------------------------
    print(Border)
    print("Step 1 : Load Dataset")
    print(Border)

    df = pd.read_csv(Datapath)

    print("Few Records from the Dataset : ")
    print(df.head())

    #--------------------------------------------------#
    # Step 2 : Remove unwanted columns
    #--------------------------------------------------
    # There are some tools also avaiable to EDA

    print(Border)
    print("Step 2 : Remove unwanted columns")
    print(Border)

    print("Share of Dataset before Removel : ",df.shape)

    if 'Unnamed: 0' in df.columns:
        df.drop(columns=['Unnamed: 0'], inplace=True)

    print("Share of Dataset after Removel : ",df.shape)
    
    print(Border)
    print("Cleaned Dataset : ")
    print(Border)

    print(df.head())

    #--------------------------------------------------#
    # Step 3 : Check Missing values
    #--------------------------------------------------
    print(Border)
    print("Step 3 : Check Missing values")
    print(Border)

    print("Missing values count : \n",df.isnull().sum())

    #--------------------------------------------------#
    # Step 4 : Display Statistical Summary
    #--------------------------------------------------
    print(Border)
    print("Step 4 : Display Statistical Summary")
    print(Border)

    print(df.describe()) # To find out outliers, mean should have nearby values,min and max should have proper range

    #--------------------------------------------------#
    # Step 5 : Corelation between columns
    #--------------------------------------------------
    print(Border)
    print("Step 5 : Correlation between columns")
    print(Border)

    print("Correlation matrix: ")
    print(df.corr())    #Helps to dcide which columns needs to be kept for training, in case somewhere its 0, we don't need it

    #--------------------------------------------------
    # Step 6 : Split Dataset into Independent and Dependent Variables
    #--------------------------------------------------
    print(Border)
    print("Step 6 : Split Dataset into Independent and Dependent Variables")
    print(Border)

    X = df[['TV','radio','newspaper']]
    Y = df['sales']

    print("Shape of Independent variables", X.shape) #(200,3)
    print("Shape of Dependent variables: ", Y.shape) #(200,)

    #--------------------------------------------------
    # Step 7 : Split Dataset Training and Testing
    #--------------------------------------------------
    print(Border)
    print("Step 7 : Split Dataset Training and Testing")
    print(Border)

    X_train, X_test, Y_train, Y_test = train_test_split(X,Y,test_size=0.2,random_state=42)
    
    print("X_Train shape : ", X_train.shape) #(160,3)
    print("X_Test shape : ", X_test.shape)  #(40,3)
    print("Y_Train shape : ", Y_train.shape) #(160,)
    print("Y_Test shape : ", Y_test.shape) #(40,)

    #--------------------------------------------------
    # Step 8 : Create and train the Model
    #--------------------------------------------------
    print(Border)
    print("Step 8 :  Create and train the Model")
    print(Border)

    model = LinearRegression()
    model.fit(X_train,Y_train)

    #--------------------------------------------------
    # Step 9 : Test the Model
    #--------------------------------------------------
    print(Border)
    print("Step 9 :  Test the Model")
    print(Border)

    Y_pred = model.predict(X_test)

    #--------------------------------------------------
    # Step 10 : Evaluate the Model
    #--------------------------------------------------
    print(Border)
    print("Step 10 : Evaluate the Model")
    print(Border)

    MSE = mean_squared_error(Y_test,Y_pred)
    RMSE = np.sqrt(MSE)
    R2 = r2_score(Y_test, Y_pred)

    print("Mean squared Error : ",MSE)
    print("Root Mean squared Error : ",RMSE)
    print("R square Error : ",R2)

    #--------------------------------------------------
    # Step 11 : Calculate Model coefficient
    #--------------------------------------------------
    print(Border)
    print("Step 11 : Calculate Model coefficient")
    print(Border)

    for column, value in zip(X.columns, model.coef_):
        print(f"{column} : {value}")

    print("Intercept : ", model.intercept_)

    #--------------------------------------------------
    # Step 12 : Compare the actual and predicted values
    #--------------------------------------------------
    print(Border)
    print("Step 12 : Compare the actual and predicted values")
    print(Border)

    Result = pd.DataFrame({'Actual sale' : Y_test.Values,
                           'Predicted Sale' : Y_pred 
                           })
    
    print(Result.head())


def main():
   MarvellousAdvertise("Advertising.csv")



if(__name__ == "__main__"):
    main()