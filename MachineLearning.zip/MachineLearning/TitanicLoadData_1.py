
import pandas as pd
import numpy as np
import joblib 


from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score,confusion_matrix

# K and R Header writing style
#-------------------------------------------------------
# Function name : ShowData
# Description : It displays basic information about the dataset
# Parameters : df
#              df -> Pandas Dataframe object
#              message
#              message -> heading text to display
# Return :  None
# Date : 14/03/2026
# Author : Kalyani Darekar
#-------------------------------------------------------
def ShowData(df,message):
    DisplayInfo(message)

    print("\nFirst 5 lines of Dataset : ")
    print(df.head())

    print("\nShape of Dataset : ")
    print(df.shape)

    print("\nColumn Names : ")
    print(df.columns.tolist())

    print("\nMissing values in each column : ")
    print(df.isnull().sum())
#-------------------------------------------------------
# Function name : DisplayInfo
# Description : It displays formatted title
# Parameters : title (str)
# Return :  None
# Date : 14/03/2026
# Author : Kalyani Darekar
#-------------------------------------------------------
def DisplayInfo(title):
    print("\n" + "="*70)
    print(title)
    print("="*70)
#-------------------------------------------------------
# Function name : MarvellousTitanicLogistic
# Description : This is main pipeline controller
#               It loads the dataset, show raw data, p
#               reprocess the dataset and train the model
# Parameters : Datapath of dataset file
# Return :  None
# Date : 14/03/2026
# Author : Kalyani Darekar
#-------------------------------------------------------
def MarvellousTitanicLogistic(Datapath): 
    DisplayInfo("Step1 : Loading the dataset")
    df = pd.read_csv(Datapath)

    ShowData(df,"Initial Dataset")


#-------------------------------------------------------
# Function name : main
# Description : startin g point of app
# Parameters : None
# Return :  None
# Date : 14/03/2026
# Author : Kalyani Darekar
#-------------------------------------------------------

def main():
    MarvellousTitanicLogistic("MarvellousTitanicDataSet.csv")


if(__name__== "__main__"):
    main()