import pandas as pd

def main():

    Data = {"Name" : ["Sagar","Amit","Pooja"],
            "Age" : [23,26,25],
            "City" : ["Pune", "Mumbai", "Satara"]}
    
    dobj = pd.DataFrame(Data)

    #Fetch specific Row
    print(dobj.loc[1])  #Gives row
    print(dobj.loc[0])  #Gives row

if (__name__ == "__main__"):
    main()