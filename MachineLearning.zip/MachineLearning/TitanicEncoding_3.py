
import pandas as pd
import numpy as np
import joblib 


from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score,confusion_matrix

# K and R Header writing style
#-------------------------------------------------------
# Function name : ShowData
# Description : It displays basic information about the dataset
# Parameters : df
#              df -> Pandas Dataframe object
#              message
#              message -> heading text to display
# Return :  None
# Date : 14/03/2026
# Author : Kalyani Darekar
#-------------------------------------------------------
def ShowData(df,message):
    DisplayInfo(message)

    print("\nFirst 5 lines of Dataset : ")
    print(df.head())

    print("\nShape of Dataset : ")
    print(df.shape)

    print("\nColumn Names : ")
    print(df.columns.tolist())

    print("\nMissing values in each column : ")
    print(df.isnull().sum())
#-------------------------------------------------------
# Function name : DisplayInfo
# Description : It displays formatted title
# Parameters : title (str)
# Return :  None
# Date : 14/03/2026
# Author : Kalyani Darekar
#-------------------------------------------------------
def DisplayInfo(title):
    print("\n" + "="*70)
    print(title)
    print("="*70)

#-------------------------------------------------------
# Function name : CleanTitanicData
# Description : It does preprocessing
#               It removes unneccessary columns
#               It handles missing values
#               It Converts text data to numeric format
#               It Does encoding to categorical columns
# Parameters : df -> pandas dataframe
# Return :  df -> cleaned pandas dataframe
# Date : 14/03/2026
# Author : Kalyani Darekar
#-------------------------------------------------------
def CleanTitanicData(df):
    DisplayInfo("Step 2 : Original Data")
    print(df.head())

    # Remove unneccessary columns
    drop_columns = ["Passengerid", "zero", "Name", "Cabin"]
    existing_columns = [col for col in drop_columns if col in df.columns]

    print("\n Columns to be dropped : ")
    print(existing_columns)

    # Drop unwanted columns
    df = df.drop(columns=existing_columns)
    DisplayInfo("Step 2 : Data after column removal")
    print(df.head())

    # Handle age column
    if("Age" in df.columns):
        print("Age column before filling missing values")
        print(df["Age"].head(10))

        #coerce -> Invalid value gets converted info NaN
        df["Age"] = pd.to_numeric(df["Age"], errors="coerce") 

        age_median = df["Age"].median()

        #Relace missing values with median
        df["Age"] = df["Age"].fillna(age_median) 

        print("Age column after preprocessing")
        print(df["Age"].head(10))

    # Handle Fare column
    if("Fare" in df.columns):
        print("\n Fare column before preprocessing")
        print(df["Fare"].head(10))

        df["Fare"] = pd.to_numeric(df["Fare"], errors="coerce") 

        fare_median = df["Fare"].median()

        print("\nMedian of Fare column is  : ", fare_median)

        #Relace missing values with median
        df["Fare"] = df["Fare"].fillna(fare_median) 

        print("Fare column after preprocessing")
        print(df["Fare"].head(10))

    # Handle Embarked column
    if("Embarked" in df.columns):
        print("\n Embarked column before preprocessing")
        print(df["Embarked"].head(10))

        # astype -> Converts the data in string
        df["Embarked"] = df["Embarked"].astype(str).str.strip()     #astype is like tostring()

        # Remove missing values
        df["Embarked"] = df["Embarked"].replace(['nan','None',''], np.nan)

        #Get most frequent value
        embarked_mode = df["Embarked"].mode()[0]
        print("Mode of embarked column: ", embarked_mode)

        df["Embarked"] = df["Embarked"].fillna(embarked_mode)

        print("Embarked column after preprocessing")
        print(df["Embarked"].head(10))

     # Handle Sex column
    if("Sex" in df.columns):
        print("\n Sex column before preprocessing")
        print(df["Sex"].head(10))

        df["Sex"] = pd.to_numeric(df["Sex"], errors="coerce") 

        print("Sex column after preprocessing")
        print(df["Sex"].head(10))

    DisplayInfo("Data after preprocessing")
    print(df.head())

    print("Missing values after preprocessing")
    print(df.isnull().sum())

    #Encode Embarked column
    df = pd.get_dummies(df,columns=["Embarked"],drop_first=True)
    print("\nData after encoding")

    print(df.head(10))

    print("Shape of dataset : ", df.shape)

    #Convert boolean columns into integer
    for col in df.columns:
        if(df[col].dtype == bool):
            df[col] = df[col].astype(int)

    DisplayInfo("Data after encoding")
    
    print(df.head())


    return df
#-------------------------------------------------------
# Function name : MarvellousTitanicLogistic
# Description : This is main pipeline controller
#               It loads the dataset, show raw data, p
#               reprocess the dataset and train the model
# Parameters : Datapath of dataset file
# Return :  None
# Date : 14/03/2026
# Author : Kalyani Darekar
#-------------------------------------------------------
def MarvellousTitanicLogistic(Datapath): 
    DisplayInfo("Step1 : Loading the dataset")
    df = pd.read_csv(Datapath)

    ShowData(df,"Initial Dataset")
    df = CleanTitanicData(df)


#-------------------------------------------------------
# Function name : main
# Description : startin g point of app
# Parameters : None
# Return :  None
# Date : 14/03/2026
# Author : Kalyani Darekar
#-------------------------------------------------------

def main():
    MarvellousTitanicLogistic("MarvellousTitanicDataSet.csv")


if(__name__== "__main__"):
    main()