import pandas as pd
def main():

    sObj = pd.Series([11.0,21.0,51.0,101.0,111.0], index=[5,6,7,8,9])
    print(sObj)

    print(sObj[7])  #51.0
if __name__ == "__main__":
    main()