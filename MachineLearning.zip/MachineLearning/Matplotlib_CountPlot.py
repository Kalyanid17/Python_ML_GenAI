import matplotlib.pyplot  as plt
import seaborn as sns

def main():

    sns.countplot(x = ["A","B","A","A","B","A","C"]) #catogorical Data , for classification
    plt.show()


if(__name__ == "__main__"):
    main()

