import pandas as pd
def main():

    sObj = pd.Series([11.0,21.0,51.0,101.0,111.0])  #Homogeneous data
    print(sObj)


if __name__ == "__main__":
    main()