import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import BaggingRegressor
from sklearn.metrics import mean_squared_error,r2_score


#------------------------------------------------------
# Step 1 : Load Dataset
#------------------------------------------------------

df = pd.read_csv("california_housing.csv")
print("Shape of dataset : ", df.shape)
print("First 5 records : ", df.head())

#------------------------------------------------------
# Step 2 : Seperate features and lables
#------------------------------------------------------

X = df.drop("target", axis = 1) # cut vertically , i.e axis =1
Y = df["target"]

#------------------------------------------------------
# Step 3 : Spilt dataset for training and testing
#------------------------------------------------------

X_train,X_test,Y_train,Y_test = train_test_split(X,Y,test_size=0.2,random_state=42)

#------------------------------------------------------
# Step 4 : Create base mmodel
#------------------------------------------------------

base_model = DecisionTreeRegressor(random_state=42)

#------------------------------------------------------
# Step 5 : Create bagging mmodel
#------------------------------------------------------

bagging_model = BaggingRegressor(
    estimator=base_model,
    n_estimators=10,
    random_state=42
) #n_estimators = how many models u want to create

#------------------------------------------------------
# Step 6 : Train bagging mmodel
#------------------------------------------------------

bagging_model.fit(X_train, Y_train)

#------------------------------------------------------
# Step 7: Test bagging mmodel
#------------------------------------------------------

Y_pred = bagging_model.predict(X_test)

#------------------------------------------------------
# Step 8: Evaluate bagging mmodel
#------------------------------------------------------

print("Mean squared Error : ", mean_squared_error(Y_test,Y_pred)) # 0.2827
#if MSE is less then model is better
print("R Square : ", r2_score(Y_test,Y_pred)) # 0.7843