#  [A,B,C,D]
#X [1,2,3,5]
#Y [2,3,1,6]
# Res [R, R, B,B]

#Predict(3,3) -> ?

import numpy as np
import math

def EucDistance(P1, P2):
    Ans = math.sqrt((P1['X'] - P2['X'])**2 + (P1['Y'] - P2['Y'])**2)
    return Ans


def MarvellousKNeighbourClassifier():
    Border = "-"*40
   
    data = [
            {'point' : 'A','X':1,'Y':2,'label':'Red'},
            {'point' : 'B','X':2,'Y':3,'label':'Red'},
            {'point' : 'C','X':3,'Y':1,'label':'Blue'},
            {'point' : 'D','X':5,'Y':6,'label':'Blue'}
            ]

    print(Border)
    print("Marvellous User Defined KNN")
    print(Border)

    print(Border)
    print("Trainig Data Set")
    print(Border)

    for i in data:
        print(i)

    print(Border)

    new_point = {'X':3, 'Y':3}
    
    #Calculate al distances 
    for d in  data:
        d['distance'] =  EucDistance(d,new_point)

    print(Border)
    print("Calculated Distances are :")
    print(Border)
    
    for d in data:
        print(d)

    sorted_data = sorted(data, key=lambda item : item['distance'])

    print(Border)
    print("Sorted Data is ")
    print(Border)

    for d in sorted_data:
        print(d)

    k = 3

    nearest = sorted_data[:k]

    print(Border)
    print("Nearest 3 elements are : ")
    print(Border)

    for d in nearest:
        print(d)

    #Voting
    votes = {}

    for neighbour in nearest:
        label = neighbour['label']
        votes[label] = votes.get(label,0) + 1

    print(Border)
    print("Voting Result : ")
    print(Border)

    for d in votes:
        print("Name : ", d, "Number of votes: ", votes[d])

    print(Border)

    predicted_class = max(votes, key=votes.get)
    print("predicted class of (3,3) is :", predicted_class )

    
def main():
    MarvellousKNeighbourClassifier()

if(__name__ == "__main__"):
    main()