


import sklearn


def main():
    print("Ball classification Case study")

    # Feature Encoding
     
    #Rough = 1
    #Smooth = 0
    Features = [[35, 1],[47, 1],[90, 0],[48,1],
                [90, 0],[35, 1],[92, 0], [35, 1],[35, 1],[35, 1],
                [96, 0],[43, 1], [110, 0],[35, 0],[95, 0]]
    
    #Lable Encoding
    #Tennis = 1
    #Cricket = 2
    Lables = [1, 1, 2, 1, 2, 1,2,1,1,1,
             2,1,2,1,2]
   


if(__name__ == "__main__"):
    main()

#Dataset Size : 15