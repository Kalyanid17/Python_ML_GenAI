#   Steps for Machine Learning Application

#   Step 1 : Data Gathering/Data Collection
#   Step 2 : Data Analysis
#   Step 3 : Data Cleaning
#   Step 4 : Model Selection (Algorithm to be used)
#   Step 5 : Model Training
#   step 6 : Model Testing / Evaluation
#   step 7 : Model Improvment (e.g Radio tuning)
#   step 8 : Prediction / Deployment

import sklearn


def main():
    print("Ball classification Case study")

    # Data Loading / Gathering 
    Features = [[35, "Rough"],[47, "Rough"],[90, "Smooth"],[48, "Rough"],
                [90, "Smooth"],[35, "Rough"],[92, "Smooth"], [35, "Rough"],[35, "Rough"],[35, "Rough"],
                [96, "Smooth"],[43, "Rough"], [110, "Smooth"],[35, "Rough"],[95, "Smooth"]]
    
    Lables = ["Tennis", "Tennis", "Cricket", "Tennis", "Cricket", "Tennis","Cricket","Tennis","Tennis","Tennis",
              "Cricket","Tennis","Cricket","Tennis","Cricket"]

if(__name__ == "__main__"):
    main()

#Dataset Size : 15