import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import BaggingRegressor
from sklearn.metrics import mean_squared_error,r2_score


#------------------------------------------------------
# Step 1 : Load Dataset
#------------------------------------------------------

df = pd.read_csv("california_housing.csv")
print("Shape of dataset : ", df.shape)
print("First 5 records : ", df.head())

#------------------------------------------------------
# Step 2 : Seperate features and lables
#------------------------------------------------------

X = df.drop("target", axis = 1) # cut vertically , i.e axis =1
Y = df["target"]

#------------------------------------------------------
# Step 3 : Spilt dataset for training and testing
#------------------------------------------------------

X_train,X_test,Y_train,Y_test = train_test_split(X,Y,test_size=0.2,random_state=42)

#------------------------------------------------------
# Step 4 : Create base mmodel
#------------------------------------------------------

model = DecisionTreeRegressor(random_state=42)



#------------------------------------------------------
# Step 5 : Train bagging mmodel
#------------------------------------------------------

model.fit(X_train, Y_train)

#------------------------------------------------------
# Step 7: Test bagging mmodel
#------------------------------------------------------

Y_pred = model.predict(X_test)

#------------------------------------------------------
# Step 8: Evaluate bagging mmodel
#------------------------------------------------------

print("Mean squared Error : ", mean_squared_error(Y_test,Y_pred)) #if MSE is less then model is better
print("R Square : ", r2_score(Y_test,Y_pred))