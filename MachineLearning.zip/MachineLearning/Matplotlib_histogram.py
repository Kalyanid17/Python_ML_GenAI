import matplotlib.pyplot  as plt
import seaborn as sns

def main():

    #Contiguous values
    sns.histplot(data = [10,20,30,20,20,20,30,40])  #Numeric,contiguous data, Regression
    plt.show()


if(__name__ == "__main__"):
    main()

    
