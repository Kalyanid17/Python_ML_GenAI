import pandas as pd
def main():

    sObj = pd.Series([25000,27000,29000,30000], index=["PPA","LB","Python","React"])
    print(sObj)

    print(sObj["Python"])

if __name__ == "__main__":
    main()