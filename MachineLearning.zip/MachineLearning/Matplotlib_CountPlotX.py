import matplotlib.pyplot  as plt
import seaborn as sns

def main():

    #catogorical Data
    sns.countplot(x = ["C","C","C++","Java","C++","Python","Javascript","C++","GoLang","C"]) #catogorical Data , for classification
    plt.show()


if(__name__ == "__main__"):
    main()

