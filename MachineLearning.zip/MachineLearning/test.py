#import numpy
#print(numpy.__version__) #2.4.2

import pandas
print(pandas.__version__) #2.2.0
#ValueError: numpy.dtype size changed, may indicate binary incompatibility. Expected 96 from C header, got 88 from PyObject

