


from sklearn import tree


def main():
    print("Ball classification Case study")

    # Independent Variables
     
    #Original Encoded Dataset
    X = [[35, 1],[47, 1],[90, 0],[48,1],
                [90, 0],[35, 1],[92, 0], [35, 1],[35, 1],[35, 1],
                [96, 0],[43, 1], [110, 0],[35, 0],[95, 0]]
    
    #Dependent Variables
    Y = [1, 1, 2, 1, 2, 1,2,1,1,1,2,1,2,1,2]
   
   #Independent varibles for training
    Xtrain = [[35, 1],[47, 1],[90, 0],[48,1],
                [90, 0],[35, 1],[92, 0], [35, 1],[35, 1],[35, 1],
                [96, 0],[43, 1], [110, 0]]
    
    #Independent varibles for testing
    Xtest = [[35, 0],[95, 0]]

    #Dependent varibles for training
    Ytrain = [1, 1, 2, 1, 2, 1,2,1,1,1,2,1,2]

    #Dependent varibles for testing
    Ytest = [1,2]

    modelObj = tree.DecisionTreeClassifier()

    trainedModel = modelObj.fit(Xtrain, Ytrain)

    Result = trainedModel.predict(Xtest)

    print("Model predicts the Object as : ",Result) #[1 2] [Tennis Cricket]


if(__name__ == "__main__"):
    main()

