


from sklearn import tree


def main():
    print("Ball classification Case study")

    # Independent Variables
     
    #Rough = 1
    #Smooth = 0
    X = [[35, 1],[47, 1],[90, 0],[48,1],
                [90, 0],[35, 1],[92, 0], [35, 1],[35, 1],[35, 1],
                [96, 0],[43, 1], [110, 0],[35, 0],[95, 0]]
    
    #Dependent Variables
    #Tennis = 1
    #Cricket = 2
    Y = [1, 1, 2, 1, 2, 1,2,1,1,1,
             2,1,2,1,2]
   
    modelObj = tree.DecisionTreeClassifier()

    trainedModel = modelObj.fit(X, Y)

    Result = trainedModel.predict([[37,1],[94,0]])

    print("Model predicts the Object as : ",Result) #[1 2] [Tennis Cricket]


if(__name__ == "__main__"):
    main()

