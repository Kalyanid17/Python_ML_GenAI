import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import BaggingClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix


#------------------------------------------------------
# Step 1 : Load Dataset
#------------------------------------------------------

df = pd.read_csv("breast_cancer.csv")
print("Shape of dataset : ", df.shape)
print("First 5 records : ", df.head())

#------------------------------------------------------
# Step 2 : Seperate features and lables
#------------------------------------------------------

X = df.drop("target", axis = 1) # cut vertically , i.e axis =1
Y = df["target"]

#------------------------------------------------------
# Step 3 : Spilt dataset for training and testing
#------------------------------------------------------

X_train,X_test,Y_train,Y_test = train_test_split(X,Y,test_size=0.2,random_state=42)

#------------------------------------------------------
# Step 4 : Create base mmodel
#------------------------------------------------------

base_model = DecisionTreeClassifier(random_state=42)

#------------------------------------------------------
# Step 5 : Create bagging mmodel
#------------------------------------------------------

bagging_model = BaggingClassifier(
    estimator=base_model,
    n_estimators=10,
    random_state=42
) #n_estimators = how many models u want to create

#------------------------------------------------------
# Step 6 : Train bagging mmodel
#------------------------------------------------------

bagging_model.fit(X_train, Y_train)

#------------------------------------------------------
# Step 7: Test bagging mmodel
#------------------------------------------------------

Y_pred = bagging_model.predict(X_test)

#------------------------------------------------------
# Step 8: Evaluate bagging mmodel
#------------------------------------------------------

print("Bagging Accuracy : ", accuracy_score(Y_test,Y_pred))
print("Confusion matrix: ")
print(confusion_matrix(Y_test,Y_pred))

# Bagging Accuracy :  0.956140350877193
# Confusion matrix: 
# [[40  3]
#  [ 2 69]]

# BaggingClassifficationBreastCancer.py and BaggingRandomForestClassBreastCancer.py 
# These two programs gives same accuracy, since in BaggingClassificationBreastCancer.py
# we are using DecisionTreeClassifier to create 10 models(trees), which is same
# as creating forest.