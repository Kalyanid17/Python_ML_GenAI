import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix


#------------------------------------------------------
# Step 1 : Load Dataset
#------------------------------------------------------

df = pd.read_csv("breast_cancer.csv")
print("Shape of dataset : ", df.shape)
print("First 5 records : ", df.head())

#------------------------------------------------------
# Step 2 : Seperate features and lables
#------------------------------------------------------

X = df.drop("target", axis = 1) # cut vertically , i.e axis =1
Y = df["target"]

#------------------------------------------------------
# Step 3 : Spilt dataset for training and testing
#------------------------------------------------------

X_train,X_test,Y_train,Y_test = train_test_split(X,Y,test_size=0.2,random_state=42)

#------------------------------------------------------
# Step 4 : Create  mmodel
#------------------------------------------------------

model = DecisionTreeClassifier(random_state=42)

#------------------------------------------------------
# Step 5 : Train mmodel
#------------------------------------------------------

model.fit(X_train, Y_train)

#------------------------------------------------------
# Step 6: Test  mmodel
#------------------------------------------------------

Y_pred = model.predict(X_test)

#------------------------------------------------------
# Step 7 : Evaluate  mmodel
#------------------------------------------------------

print("Accuracy : ", accuracy_score(Y_test,Y_pred)) # gets droped as we r using single model, in general in individual 30% acc drop, and in ensemble 30% acc increases in case noise is there in data
#Here we have very clean data hence, acc diff is 1 percent
print("Confusion matrix: ")
print(confusion_matrix(Y_test,Y_pred))