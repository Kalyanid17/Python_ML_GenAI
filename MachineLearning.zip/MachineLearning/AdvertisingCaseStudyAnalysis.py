#industrial
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error,r2_score

def MarvellousAdvertise(Datapath):
    Border = "-"*40
    #--------------------------------------------------#
    # Step 1 : Load Dataset
    #--------------------------------------------------
    print(Border)
    print("Step 1 : Load Dataset")
    print(Border)

    df = pd.read_csv(Datapath)

    print("Few Records from the Dataset : ")
    print(df.head())

    #--------------------------------------------------#
    # Step 2 : Remove unwanted columns
    #--------------------------------------------------
    # There are some tools also avaiable to EDA

    print(Border)
    print("Step 2 : Remove unwanted columns")
    print(Border)

    print("Share of Dataset before Removel : ",df.shape)

    if 'Unnamed: 0' in df.columns:
        df.drop(columns=['Unnamed: 0'], inplace=True)

    print("Share of Dataset after Removel : ",df.shape)
    
    print(Border)
    print("Cleaned Dataset : ")
    print(Border)

    print(df.head())

    #--------------------------------------------------#
    # Step 3 : Check Missing values
    #--------------------------------------------------
    print(Border)
    print("Step 3 : Check Missing values")
    print(Border)

    print("Missing values count : \n",df.isnull().sum())

    #--------------------------------------------------#
    # Step 4 : Display Statistical Summary
    #--------------------------------------------------
    print(Border)
    print("Step 4 : Display Statistical Summary")
    print(Border)

    print(df.describe()) # To find out outliers, mean should have nearby values,min and max should have proper range

    #--------------------------------------------------#
    # Step 5 : Corelation between columns
    #--------------------------------------------------
    print(Border)
    print("Step 5 : Correlation between columns")
    print(Border)

    print("Correlation matrix: ")
    print(df.corr())    #Helps to dcide which columns needs to be kept for training, in case somewhere its 0, we don't need it

    

def main():
   MarvellousAdvertise("Advertising.csv")



if(__name__ == "__main__"):
    main()