import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.metrics import mean_squared_error,r2_score


#------------------------------------------------------
# Step 1 : Load Dataset
#------------------------------------------------------

df = pd.read_csv("california_housing.csv")
print("Shape of dataset : ", df.shape)
print("First 5 records : ", df.head())

#------------------------------------------------------
# Step 2 : Seperate features and lables
#------------------------------------------------------

X = df.drop("target", axis = 1) # cut vertically , i.e axis =1
Y = df["target"]

#------------------------------------------------------
# Step 3 : Spilt dataset for training and testing
#------------------------------------------------------

X_train,X_test,Y_train,Y_test = train_test_split(X,Y,test_size=0.2,random_state=42)

#------------------------------------------------------
# Step 4 : Create gradient boosting model
#------------------------------------------------------

boost_model = GradientBoostingRegressor(
    n_estimators=100, #regressor model count should be max o.w acc drops
    learning_rate=0.1,
    max_depth=3,
    random_state=42
    )


#------------------------------------------------------
# Step 5 : Train boosting mmodel
#------------------------------------------------------

boost_model.fit(X_train, Y_train)

#------------------------------------------------------
# Step 6: Test boosting mmodel
#------------------------------------------------------

Y_pred = boost_model.predict(X_test)

#------------------------------------------------------
# Step 7: Evaluate boosting mmodel
#------------------------------------------------------

print("Mean squared Error : ", mean_squared_error(Y_test,Y_pred)) #0.2939
#if MSE is less then model is better
print("R Square : ", r2_score(Y_test,Y_pred))