# Object oriented Programming

class Demo:
    def __init__(self):
        print("Inside Constructor")

def main():
  dObj1 = Demo()
  dObj2 = Demo()
    
main()