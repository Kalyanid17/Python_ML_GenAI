
def CheckPerfect(No):

  iSum = 0
  for i in range(1,(int(No/2) + 1)):
    if(No % i == 0):
      iSum = iSum + i

  return iSum == No

#Selection if else
def main():
  value = 0

  print("Enter no : ")
  value = int(input())

  Ret = CheckPerfect(value)

  if(Ret == True):
    print("It is Perfect no")
  else:
    print("It is Not a Perfect no")

           
main()