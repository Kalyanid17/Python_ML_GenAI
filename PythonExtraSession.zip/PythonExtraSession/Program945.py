
def CheckEven(no):
  if(no%2 == 0):
    print("It is Even no ")
  else:
    print("It is Odd no ")

#Selection if else
def main():
  value = 0

  print("Enter no : ")
  value = int(input())

  CheckEven(value)
           
main()