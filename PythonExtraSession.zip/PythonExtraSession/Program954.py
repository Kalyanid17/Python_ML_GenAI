

#Selection if else
def main():
  Arr = [10,20,30,40,50]
  print(Arr[0])
  print(Arr[1])
  print(Arr[2])
  print(Arr[3])

           
main()