
def SumDigits(No):
  Digit = 0
  iSum = 0
  while (No != 0):
    Digit = No % 10
    iSum = iSum + Digit
    No = No//10  #Floor division, it takes whole no, i.e without digit

  return iSum 

#Selection if else
def main():
  No = 0

  print("Enter number : ")
  No = int(input())

  Ret = SumDigits(No)

  print("Sum of Digits = " , Ret)
           
main()