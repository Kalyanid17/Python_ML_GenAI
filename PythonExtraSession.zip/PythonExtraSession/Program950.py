
def DisplayDigits(No):
  Digit = 0
  while (No != 0):
    Digit = No % 10
    No = No/10  #Issue
    print(Digit)

#Selection if else
def main():
  No = 0

  print("Enter number : ")
  No = int(input())

  DisplayDigits(No)

           
main()