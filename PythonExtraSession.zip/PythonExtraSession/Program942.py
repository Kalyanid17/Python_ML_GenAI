
#Selection if else
def main():
  for i in range(5):
    print(i) # 0 1 2 3 4 on new line every int
           

main()