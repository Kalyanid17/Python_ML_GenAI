def Minimum(Brr):
    iMin = 0
    iMin = Brr[0]
    
    for i in range(len(Brr)):
        if(Brr[i] < iMin):
            iMin = Brr[i]
    
    return iMin

def main():
    print("Enter string : ")
    Arr = input()

    print("Entered string  : ", Arr)
    print("Length of string is  : ", len(Arr))
main()