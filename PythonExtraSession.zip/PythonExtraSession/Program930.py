

def main():
    # printf("\n"); C
    # cout << "\n"; c++
    print("Jay Ganesh ...")
    
if(__name__ == "__main__"):
    main()