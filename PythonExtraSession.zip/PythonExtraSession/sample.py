
def Display():
    print("Inside Dispaly of Sample.py")
    print("__name__ from sample.py is : ",__name__)