# Object oriented Programming

class Demo:
    def __init__(self, A, B): #__dell__ destructor
        print("Inside Constructor")
        self.No1 = A
        self.No2 = B

    def Display(self):
       print("Inside Display")


def main():
  dObj1 = Demo(11,21)

  print(dObj1.No1)
  print(dObj1.No2)
    
  dObj1.Display()
main()