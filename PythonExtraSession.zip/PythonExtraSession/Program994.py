print("Enter the size of array")
size = int(input()) # 5

# int *Arr = (int *)malloc(sizeof(int) * size) # 'C'
Arr = [0] * size    #fast works
print("Sizeof Array is : ", len(Arr))

print(Arr[0])
print(Arr[1])
print(Arr[2])
print(Arr[3])

# free(Arr)
# delete Arr
# Arr = Null
# System.gc()

del Arr