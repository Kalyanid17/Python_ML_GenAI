
#Selection if else
def main():
    print("Enter first no : ")
    no1 = int(input())

    print("Enter second no : ")
    no2 = int(input())

    if(no1 > no2):
        print("Maximun is  : ", no1)
    else:
        print("Maximun is  : ", no2)

main()