def main():
    Arr = []
    Arr.append(11)
    Arr.append(12)
    Arr.append(13)

    print(Arr)

main()