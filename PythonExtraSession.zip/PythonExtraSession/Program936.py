

def main():
    no1 = 0
    no2 = 0
    ans = 0

    print("Enter first no : ")
    no1 = int(input())

    print("Enter first no : ")
    no2 = int(input())

    ans = no1 + no2
    print("Addition is  : ", ans)

main()