# Object oriented Programming

class Arithmatic:
    #Contructor
    def __init__(self,A,B):
        self.No1 = A #Characteristics
        self.No2 = B #Characteristics

    def Addition(self):
        Ans = 0
        Ans = self.No1 + self.No2
        return Ans

    def Substraction(self):
        Ans = 0
        Ans = self.No1 - self.No2
        return Ans

def main():
  obj = Arithmatic(11,10)
  print("Addition is : " , obj.Addition())
  print("Substraction is : " , obj.Substraction())
main()