
def DisplayDigits(No):
  Digit = 0
  while (No != 0):
    Digit = No % 10
    print(Digit)
    No = No//10  #Floor division, it takes whole no, i.e without digit
    

#Selection if else
def main():
  No = 0

  print("Enter number : ")
  No = int(input())

  DisplayDigits(No)

           
main()