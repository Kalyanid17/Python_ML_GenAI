#Link list - Singly Linear Linked List

# Done
class Node:
    def __init__(self, value):
        self.data = value
        self.next = None

class SinglyLL:
    # Done
    def __init__(self):
        self.first = None
        self.iCount = 0

    def InsertFirst(self,no):
        newn = Node(no)

        # LL is empty
        if(self.first == None):
            self.first = newn
        # It contains at least 1 node
        else:
            newn.next = self.first
            self.first = newn

        self.iCount = self.iCount + 1

    def InsertLast(self,no):
        pass

    def InsertAtPos(self, no, pos):
        pass

    def DeleteFirst(self):
        pass

    def DeleteLast(self):
        pass

    def DeleteAtPos(self, pos):
        pass

    #Done
    def Count(self):
        return self.iCount

     #Done
    def Display(self):
        temp = self.first

        while(temp != None):
            print("|", temp.data, "|->", end=" ")
            temp = temp.next
        
        print("None")
    
def main():
    sObj = SinglyLL()

    sObj.InsertFirst(101)
    sObj.InsertFirst(51)
    sObj.InsertFirst(21)
    sObj.InsertFirst(11)

    print("Elements of LinkedList are: ")
    sObj.Display()
    print("No of Elements in LinkedList are : ", sObj.Count())
    
if __name__ == "__main__":
    main()