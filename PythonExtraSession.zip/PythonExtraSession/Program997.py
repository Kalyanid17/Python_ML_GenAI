#Link list - Singly Linear Linked List

# Done
class Node:
    def __init__(self, value):
        self.data = value
        self.next = None

class SinglyLL:
    # Done
    def __init__(self):
        self.first = None
        self.iCount = 0

     # Done
    def InsertFirst(self,no):
        newn = Node(no)

        # LL is empty
        if(self.first == None):
            self.first = newn
        # It contains at least 1 node
        else:
            newn.next = self.first
            self.first = newn

        self.iCount = self.iCount + 1

    # Done
    def InsertLast(self,no):
        newn = Node(no)

        # LL is empty
        if(self.first == None):
            self.first = newn
        # It contains at least 1 node
        else:
            temp = self.first

            while (temp.next != None):
                temp = temp.next

            temp.next = newn

        self.iCount = self.iCount + 1

    # Done
    def InsertAtPos(self, no, pos):

        # Invalid Position handle
        if(pos < 1 or pos > (self.iCount + 1)):
            print("Invalid Position")
            return
        
        if(pos == 1):
           self.InsertFirst(no)
           return
        elif(pos == self.iCount + 1):
            self.InsertLast(no)
            return
        else:
            newn = Node(no)
            temp = self.first

            for i in range(1,pos-1):
                temp = temp.next

            newn.next = temp.next
            temp.next = newn

            self.iCount = self.iCount + 1

    # Done
    def DeleteFirst(self):
        if(self.first == None):
            return
        
        temp = self.first
        self.first = self.first.next
        del temp # it just decrease ref count by 1 , internally, optional

        self.iCount = self.iCount - 1

    def DeleteLast(self):
        # LL is empty
        if(self.first == None):
            return
        
        #LL contains 1 Node
        if(self.first.next == None):
            del self.first # ref count =1, will become 0, true use
            self.first = None
            self.iCount = 0
        #LL contains more than 1 node
        else:
            temp = self.first

            while(temp.next.next != None):
                temp = temp.next

            del temp.next
            temp.next = None

            self.iCount = self.iCount - 1

    # Done
    def DeleteAtPos(self, pos):
        # Invalid Position handle
        if(pos < 1 or pos > (self.iCount)):
            print("Invalid Position")
            return
        
        if(pos == 1):
           self.DeleteFirst()
           return
        elif(pos == self.iCount):
            self.DeleteLast()
            return
        else:
            temp = self.first

            for i in range(1,pos-1):
                temp = temp.next

            temp.next = temp.next.next

            self.iCount = self.iCount - 1


    #Done
    def Count(self):
        return self.iCount

     #Done
    def Display(self):
        temp = self.first

        while(temp != None):
            print("|", temp.data, "|->", end=" ")
            temp = temp.next
        
        print("None")
    
def main():
    sObj = SinglyLL()

    sObj.InsertFirst(101)
    sObj.InsertFirst(51)
    sObj.InsertFirst(21)
    sObj.InsertFirst(11)

    print("Elements of LinkedList are: ")
    sObj.Display()
    print("No of Elements in LinkedList are : ", sObj.Count())

    sObj.InsertFirst(111)
    sObj.InsertLast(121)

    print("Elements of LinkedList are: ")
    sObj.Display()
    print("No of Elements in LinkedList are : ", sObj.Count())

    sObj.InsertAtPos(75, 4)
    print("Elements of LinkedList are: ")
    sObj.Display()
    print("No of Elements in LinkedList are : ", sObj.Count())

    sObj.DeleteFirst()
    sObj.DeleteFirst()
    print("Elements of LinkedList are: ")
    sObj.Display()
    print("No of Elements in LinkedList are : ", sObj.Count())
    
    sObj.DeleteLast()
    print("Elements of LinkedList are: ")
    sObj.Display()
    print("No of Elements in LinkedList are : ", sObj.Count())

    sObj.DeleteAtPos(3)
    print("Elements of LinkedList are: ")
    sObj.Display()
    print("No of Elements in LinkedList are : ", sObj.Count())
if __name__ == "__main__":
    main()