def DisplayFactors(No):

  for i in range(1,No+1):
    if(No % i == 0):
      print(i)

#Selection if else
def main():
  value = 0

  print("Enter no : ")
  value = int(input())

  DisplayFactors(value)

           
main()