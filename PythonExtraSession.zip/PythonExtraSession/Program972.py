
def CountCapital(Brr):
    iCount = 0
    for ch in Brr:
        if(ord(ch) >= 65 and ord(ch)<=90): # Issue, Python doesn't alow Asccii value
            iCount = iCount + 1
    return iCount
          
def main():
    print("Enter string : ")
    Arr = input()
  
    Ret = CountCapital(Arr)

    print("No of capital characters are : ", Ret)
main()