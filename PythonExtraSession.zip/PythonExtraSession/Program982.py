import sample

print("Inside main Application")
print("__name__ from main application is : ", __name__)

sample.Display()