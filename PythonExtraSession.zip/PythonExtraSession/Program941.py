
#Selection if else
def main():
    Arr = range(5)
    print(Arr) #range(0,5)

main()