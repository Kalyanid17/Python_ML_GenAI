def SumFactors(No):

  iSum = 0
  for i in range(1,(int(No/2) + 1)):
    if(No % i == 0):
      iSum = iSum + i

  return iSum

#Selection if else
def main():
  value = 0

  print("Enter no : ")
  value = int(input())

  Ret = SumFactors(value)

  print("Sum of Factors : ", Ret)

           
main()