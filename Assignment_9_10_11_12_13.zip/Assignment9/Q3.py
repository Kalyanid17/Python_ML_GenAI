#WRP to accept one no and prints square of that number
#input 5
#output 25

def calSquare(a):
    return a**2

def main():
    No1 = 0
    Square = 0
    print("Enter a no : ")
    No1 = int(input())
    Square = calSquare(No1)

    print("Square of ", No1, " = ", Square)

if(__name__ == "__main__"):
    main()