#WRP to accept one no and prints cube of that number
#input 2
#output 8

def calCube(a):
    return (a**2)*a   # (a**3)

def main():
    No1 = 0
    Cube = 0
    print("Enter a no : ")
    No1 = int(input())
    Cube = calCube(No1)

    print("Cube of ", No1, " = ", Cube)

if(__name__ == "__main__"):
    main()