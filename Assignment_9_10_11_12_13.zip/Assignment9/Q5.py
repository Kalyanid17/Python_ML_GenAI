#WRP which accepts a no and checks whether it is divisible by 3 and 5
#Input : 15
#Output : Divisible by 3 and 5

def isDivisible(a):
    return (a % 3 == 0 and a % 5 == 0)   

def main():
    No1 = 0
    
    print("Enter a no : ")
    No1 = int(input())
    if(isDivisible(No1)):
        print(No1 , " is Divisible by 3 and 5")
    else:
        print(No1 , " is NOT Divisible by 3 and 5")

if(__name__ == "__main__"):
    main()