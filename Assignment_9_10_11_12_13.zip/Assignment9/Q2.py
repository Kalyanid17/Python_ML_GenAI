#WRP which contains a function ChkGreater() that accepts 2 numbers and prints the greater no.
#Input : 10,20
#Output : 20 is greater

def ChkGreater(a, b):
    if(a > b):
        return a
    else:
        return b

def main():
    No1 = 0
    No2 = 0
    Max = 0

    print("Enter 2 numbers : ")
    No1 = int(input())
    No2 = int(input())

    Max = ChkGreater(No1, No2)

    print(Max , "is Greater ")

if(__name__ == "__main__"):
    main()