# WRP which contains one function named as Display and prints "Jay Ganesh.." on console.

def Display():
    print("Jay Ganesh..")

def main():
    Display()


if(__name__ == "__main__"):
    main()