#WRP to accept no and print all odd no till that no
#input : 10
#o/p : 1,3,5,7,9

def ChkEven(a):

    Odd = list()
    i = 1
    while i<=a:
        if(i % 2 == 1):
            Odd.append(i)
        i = i+1
    return  Odd

def main():
    No1 = 0
    
    print("Enter a no : ")
    No1 = int(input())

    Res = ChkEven(No1)
    print(Res)

if(__name__ == "__main__"):
    main()