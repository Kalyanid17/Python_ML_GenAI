#WRP to accept one no and prints its table
#Input : 4
#Output : 4 8 12 16 20 24 28 32 40

def getTable(a):

    Table = list()
    for i in range(1,11):
        Table.append(a * i)
    return Table  

def main():
    No1 = 0
    
    print("Enter a no : ")
    No1 = int(input())

    Res = getTable(No1)
    print(Res)

if(__name__ == "__main__"):
    main()