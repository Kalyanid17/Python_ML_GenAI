#WRP to accept 1 no and print sum of first n natural no
#Input : 5
#Output : 15

def calSumNatural(a):

    Sum = 0
    i = 0
    while (i <= a):
        Sum = Sum + i
        i = i+1
    return Sum  

def main():
    No1 = 0
    
    print("Enter a no : ")
    No1 = int(input())

    Res = calSumNatural(No1)
    print(Res)

if(__name__ == "__main__"):
    main()