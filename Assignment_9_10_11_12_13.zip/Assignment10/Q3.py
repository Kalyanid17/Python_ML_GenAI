#WRP to accept 1 no and print factorial no
#Input : 5
#Output : 120

def calFactorial(a):
    Fact = 1
    
    for i in range(1, a+1):
        Fact = Fact * i
    return Fact  

def main():
    No1 = 0
    
    print("Enter a no : ")
    No1 = int(input())

    Res = calFactorial(No1)
    print("Res = " , Res)

if(__name__ == "__main__"):
    main()