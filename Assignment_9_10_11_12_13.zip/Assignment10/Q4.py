#WRP to accept no and print all even no till that no
#input : 10
#o/p : 2,4,6,8,10

def ChkEven(a):

    Even = list()
    i = 1
    while i<=a:
        if(i % 2 == 0):
            Even.append(i)
        i = i+1
    return  Even

def main():
    No1 = 0
    
    print("Enter a no : ")
    No1 = int(input())

    Res = ChkEven(No1)
    print(Res)

if(__name__ == "__main__"):
    main()