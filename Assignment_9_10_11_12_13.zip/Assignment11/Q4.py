#WRP to accept a no and prints reverse of that no
#i/p : 123
#o/p : 321

def ReverseNumber(a):
  
    reverse = 0

    while (a > 0):
        rem = int(a % 10)
        reverse = reverse * 10 + rem
        a = int(a / 10)       

    return reverse

def main():
    No1 = 0
    
    print("Enter a no : ")
    No1 = int(input())

    reverse = ReverseNumber(No1)
    
    print(reverse)
    

if(__name__ == "__main__"):
    main()