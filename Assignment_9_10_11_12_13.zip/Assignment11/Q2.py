#WRP to accept number and print no of digits in that no
#i/p : 7521
#o/p : 4


def countDigit(a):
  
    cnt = 0

    while (a > 0):
        a = int(a / 10)
        cnt = cnt +1

    return cnt
        

def main():
    No1 = 0
    
    print("Enter a no : ")
    No1 = int(input())

    noOfDigits = countDigit(No1)
    
    print(noOfDigits)
    

if(__name__ == "__main__"):
    main()