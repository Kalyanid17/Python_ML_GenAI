#WRP to accept no and print sum of its digits
#i/p : 123
#o/p : 6

def SumDigits(a):
    
    sum = 0

    while (a > 0):
        digit = int(a % 10)
        sum = sum + digit
        a = int(a / 10)

    return sum
        

def main():
    No1 = 0
    
    print("Enter a no : ")
    No1 = int(input())

    noOfDigits = SumDigits(No1)
    
    print(noOfDigits)
    

if(__name__ == "__main__"):
    main()