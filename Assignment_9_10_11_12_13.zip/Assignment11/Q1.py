#WRP to accept 1 no and checks if its prime or not factorial no
#Input :11
#Output : Prime number , It is a number which has only 2 factors 1 and the number itself

def chkPrime(a):
    isPrime = False

    i = 2
    for i in range(2,a+1):
        if(a % i) > 0:
            continue
        else:
            break

    if(i == a):
        return True

def main():
    No1 = 0
    
    print("Enter a no : ")
    No1 = int(input())

    if(chkPrime(No1)):
        print("Prime Number")
    else:
        print("Not a Prime Number")

if(__name__ == "__main__"):
    main()