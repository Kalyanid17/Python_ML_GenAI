#WRP to check if number is palindrome or not
#i/p : 121
#o/p : Palindrome

def ReverseNumber(a):
  
    reverse = 0

    while (a > 0):
        rem = int(a % 10)
        reverse = reverse * 10 + rem
        a = int(a / 10)       

    return reverse

def main():
    No1 = 0
    
    print("Enter a no : ")
    No1 = int(input())

    reverse = ReverseNumber(No1)

    if(reverse == No1):
        print("Palindrome")
    else:
        print("Not a Palindrome")

    
if(__name__ == "__main__"):
    main()