#WRP which accepts one no and print that many numbers starting from 1
#i/p : 5
#o/p : 1 2 3 4 5



def main():

    print("Enter a No")
    No1 = int(input())

    
    for i in range(1, No1 + 1):
        if(i == (No1)):
            print(i)
        else: 
            print(i, end=" ")
            

if __name__ == "__main__":
    main()