#WRP which accepts one no and print its facctors
#i/p : 12
#o/p : 1 2 3 4 6 12

def getFactors(No):
    FactorLst = []
    
    for i in range(1, No + 1):
        if(No % i == 0):
            FactorLst.append(i)

    return FactorLst

def main():

    print("Enter a No")
    No1 = int(input())

    factLst = getFactors(No1)
    
    for i in range(len(factLst)):
        if(i == (len(factLst)- 1)):
            print(factLst[i])
        else: 
            print(factLst[i], end=" ")
            

if __name__ == "__main__":
    main()