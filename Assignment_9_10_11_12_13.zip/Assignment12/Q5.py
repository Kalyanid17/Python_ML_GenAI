#WRP which accepts one no and print that many numbers in reverse order
#i/p : 5
#o/p : 5 4 3 2 1



def main():

    print("Enter a No")
    No1 = int(input())

    i = No1
    for i  in range(No1 , 0, -1):
        if(i == (1)):
            print(i)
        else: 
            print(i, end=" ")
            

if __name__ == "__main__":
    main()