#WRP which accepts 2 numbers and prints its addition,substraction,multiplicationa nd division

def Add(No1, No2):
    return No1 + No2

def Sub(No1, No2):
    return No1 - No2

def Mult(No1, No2):
    return No1 * No2

def Div(No1, No2):
    return No1 / No2

def main():

    print("Enter 2 Numbers")
    No1 = int(input())
    No2 = int(input())

    print("Addition is : " , Add(No1,No2))
    print("Substraction is : " , Sub(No1,No2))
    print("Multplication is : " , Mult(No1,No2))
    print("Division is : " , Div(No1,No2))      

if __name__ == "__main__":
    main()