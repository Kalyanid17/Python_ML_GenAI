#WRP to aacept 1 character and check if its vowel or consonant.
#i/p : a
#o/p : Vowel

def chkVowel(c):
    VowelLst = ["a", "i", "e", "o", "u"]
    if(VowelLst.__contains__(c)):
        return True 
    else:
        return False

def main():

    print("Enter a character")
    c = (input())

    if(chkVowel(c)):
        print("Vowel")
    else:
        print("Consonant")

if __name__ == "__main__":
    main()