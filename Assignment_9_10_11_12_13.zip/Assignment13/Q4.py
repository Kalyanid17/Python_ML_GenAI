#WRP to accept one no and prints its binary equivalent
    
def main():

    print("Enter a Number : ")
    No = int(input())
    print(format(No,'b'))

if (__name__ == "__main__"):
    main()    


    