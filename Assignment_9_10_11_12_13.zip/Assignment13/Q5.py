#WRP which accepts markks and display grade.
#Condition e.g 

#>=75 -> Distinction, >= 60 -> First class, >= 50 -> Second class, < 50 ->fail

def getGrade(Marks):

    Grade = ""

    if(Marks >= 75):
        Grade = "Distinction"
    elif(Marks >= 60):
         Grade = "First class"
    elif(Marks >= 50):
         Grade = "Second class"
    elif(Marks < 50):
         Grade = "Fail"
    
    return Grade

def main():

    print("Enter Marks : ")
    Marks = float(input())
    print(getGrade(Marks))

if (__name__ == "__main__"):
    main()    
