#WRP to accept one no and check whether its perfect no or not
#I/p : 6
#o/p : Perfect no

def ChkPerfect(No1):

    Sum = 0
    Divisor = []

    for i in range(1, No1):
        if(No1 % i == 0):
            Sum = Sum + i

    if(Sum == No1):
        return True
    else:
        return False
    
def main():

    print("Enter a Number : ")
    No = int(input())
   

    if(ChkPerfect(No)):
        print("Perfect")
    else:
        print("Not a Perfect Number")


if (__name__ == "__main__"):
    main()    


    