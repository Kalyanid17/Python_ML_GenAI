#WRP a program to accept radious of circle  and  calculate area of circle


def main():
    pi = 3.14

    print("Enter  radious of a circle : ")
    r = float(input())
   

    area = pi * (r ** 2)

    print("Area of a Circle is  : ", area)


if (__name__ == "__main__"):
    main()