#WRP a program to accept length and width and calculate area of rectangle


def main():
    print("Enter length and width of a Rectangle : ")
    length = float(input())
    width = float(input())

    area = length * width

    print("Area of a Rectangle is  : ", area)


if (__name__ == "__main__"):
    main()