# Using pandas function calculate and display:
# Average study hours
# Average Attendance
# Maximun PreviousScore
# Minimun SleepHours

import pandas as pd

def main():

    df = pd.read_csv("student_performance_ml.csv")

    #first 5 records
    print("First 5 records : ")
    print(df.head())

    #last 5 records
    print("Last 5 records : ")
    print(df.tail())

    #total no of rows and cols
    print("Dimention of Dataset : ")
    print(df.shape)

    #list of column names
    print("Column Names :" , list(df.columns))

    # Data type of each column
    print("Data type of each column : " , df.dtypes)

    ####################################################
    # Display total no of students in the dataset

    print("Total no of Students are : ", len(df))

    # Count how many students passed(FinalResult = 1)
    print("No of students passed(FinalResult = 1) : ", (df["FinalResult"] == 1).sum())

    # Count how many students failed(FinalResult = 0)
    print("No of students failed(FinalResult = 0) : ", (df["FinalResult"] == 0).sum())

    #################################################
    # Average study hours
    print("Average Study houres : ", df["StudyHours"].mean())
    # Average Attendance
    print("Average Attendance : ", df["Attendance"].mean())
    # Maximun PreviousScore
    print("Maximum Previous Score : ", df["PreviousScore"].max())
    # Minimun SleepHours
    print("Minimum Sleep Hours : ", df["SleepHours"].min())
if (__name__ == "__main__"):
    main()