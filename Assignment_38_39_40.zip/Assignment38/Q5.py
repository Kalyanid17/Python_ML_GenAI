# Based on the dataset values, analyze whether:
# Higher study hours increases chance of passing
# Higher attendance improves finalResult
# Write your observation in 4-5 lines

#- Yes , higher study hours increases the chance of passing, which can be seen from below scatterplot
# for studyHours and FinalResult. It displays if study hours are inbetween 5 to 8,
# The student succeeds.

#- Yes, Higher attendance improves finalResult, which can be seen from below plotted 
# scatterplot for Attendance and Finalresult.It displays if Attendance is greater than,
# 75% the student succeeds.

import pandas as pd
import matplotlib.pyplot as Plt
import seaborn as sns

df = pd.read_csv("student_performance_ml.csv") 
sns.scatterplot(x=df['StudyHours'], y=df['FinalResult'])
Plt.show()
sns.scatterplot(x=df['Attendance'], y=df['FinalResult'])
Plt.show()