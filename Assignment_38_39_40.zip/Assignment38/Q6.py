# Plot a histogram of StudyHours.
# Explain what the distribution tells you.

import pandas as pd
import matplotlib.pyplot as Pl
import seaborn as sns

df = pd.read_csv("student_performance_ml.csv")
sns.histplot(data=list(df["StudyHours"]))
Pl.show()