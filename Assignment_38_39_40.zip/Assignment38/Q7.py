# Create a Scatterplot 
# StudyHours Vs PreviousScore

import pandas as pd
import matplotlib.pyplot as Plt
import seaborn as sns

df = pd.read_csv("student_performance_ml.csv") 
sns.scatterplot(x=df['StudyHours'], y=df['PreviousScore'])
Plt.show()