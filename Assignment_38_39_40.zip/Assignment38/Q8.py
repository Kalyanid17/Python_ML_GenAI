#Plot boxplot using Attendance column
#Check if outliers are present

import pandas as pd
import matplotlib.pyplot as Plt
import seaborn as sns

df = pd.read_csv("student_performance_ml.csv") 
sns.boxplot(x=df['Attendance'])
Plt.show()
