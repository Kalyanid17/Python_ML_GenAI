# WRp to load the file student_performance_ml.csv using pandas.Display
# first 5 records
# last 5 records
# total no of rows and columns
# List of column names
# Data type of each column

import pandas as pd

def main():

    df = pd.read_csv("student_performance_ml.csv")

    #first 5 records
    print("First 5 records : ")
    print(df.head())

    #last 5 records
    print("Last 5 records : ")
    print(df.tail())

    #total no of rows and cols
    print("Dimention of Dataset : ")
    print(df.shape)

    #list of column names
    print("Column Names :" , list(df.columns))

    # Data type of each column
    print("Data type of each column : " , df.dtypes)


if (__name__ == "__main__"):
    main()