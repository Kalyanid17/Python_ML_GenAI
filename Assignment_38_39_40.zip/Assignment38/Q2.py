# WRP :
# Display total no of students in the dataset
# Count how many students passed(FinalResult = 1)
# Count How many students failed (Finalresult = 0)

import pandas as pd

def main():

    df = pd.read_csv("student_performance_ml.csv")

    #first 5 records
    print("First 5 records : ")
    print(df.head())

    #last 5 records
    print("Last 5 records : ")
    print(df.tail())

    #total no of rows and cols
    print("Dimention of Dataset : ")
    print(df.shape)

    #list of column names
    print("Column Names :" , list(df.columns))

    # Data type of each column
    print("Data type of each column : " , df.dtypes)

    ####################################################
    # Display total no of students in the dataset

    print("Total no of Students are : ", len(df))

    # Count how many students passed(FinalResult = 1)
    print("No of students passed(FinalResult = 1) : ", (df["FinalResult"] == 1).sum())

    # Count how many students failed(FinalResult = 0)
    print("No of students failed(FinalResult = 0) : ", (df["FinalResult"] == 0).sum())

if (__name__ == "__main__"):
    main()