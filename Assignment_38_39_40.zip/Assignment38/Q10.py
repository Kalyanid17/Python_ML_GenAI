# Plot SleepHours against FinalResult.
# Does sleeping more guarantee success? Explain.

import pandas as pd
import matplotlib.pyplot as Plt
import seaborn as sns

df = pd.read_csv("student_performance_ml.csv") 
sns.scatterplot(x=df['SleepHours'], y=df['FinalResult'])
Plt.show()

#Since the students taking sleep hours in between 6 to 8 , are denoting higher success rate.
#Hence we can say sleeping more guarantee success