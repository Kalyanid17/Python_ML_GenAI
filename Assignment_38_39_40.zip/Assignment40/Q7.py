#7.Train model using 
# random_state = 0, random_state = 10, random_state = 42
# Compare testing accuracy. Does result change?

import pandas  as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
     accuracy_score,
     confusion_matrix,
     ConfusionMatrixDisplay
)
import matplotlib.pyplot as plt
import os


def main():
    
    filePath = os.path.pardir + "/student_performance_ml.csv"
    
    ################################################
    #1. Dataset loading
    ###############################################
    df = pd.read_csv(filePath)

    ################################################
    #2. Data Analysis
    ###############################################
    print("Shape of Dataset : " , df.shape)
    print("Column Names : ", list(df.columns))

    print("Missing values(Per column)")
    print(df.isnull().sum())

    print("Class Distribution(FinalResult count)")
    print(df["FinalResult"].value_counts())

    print("Statistical report of Dataset")
    print(df.describe())

    #################################################################
    # Step 3 : Visualisation od Dataset
    #################################################################

    #Scatter plot
    plt.figure(figsize=(7,5))   #Decides a plane, till 7 on X axix and 5 on Y axis

    #In case of multiclass classification, its difficult to understand the data
    #using visualization, hence convert it into binary classification by considering 2 features.
    #Here we are considering petal length and petal width

    for sp in df["FinalResult"].unique():
        temp = df[df["FinalResult"] == sp]
        plt.scatter(temp["StudyHours"], temp["Attendance"], label = sp)

    plt.title("Student Evaluation")
    plt.xlabel("StudyHours")
    plt.ylabel("Attendance")

    plt.legend()
    plt.grid(True)
    plt.show()  #Shows the picture created in memory.


    #################################################################
    # Step 4 : train_test_split
    #################################################################
    feature_cols = [
            "StudyHours",
            "Attendance",
            "PreviousScore",
            "AssignmentsCompleted",
            "SleepHours"]


    X = df[feature_cols]
    
    Y = df["FinalResult"]

    X_train, X_test, Y_train, Y_test = train_test_split(X,Y,test_size=0.2,random_state=42) 

    #################################################################
    # Step 5 : Model training
    #################################################################

    model0 = DecisionTreeClassifier(criterion="gini",max_depth=5, random_state=0)
    model10 = DecisionTreeClassifier(criterion="gini",max_depth=5, random_state=10)
    model42 = DecisionTreeClassifier(criterion="gini",max_depth=5, random_state=42)

    model0.fit(X_train,Y_train)
    model10.fit(X_train,Y_train)
    model42.fit(X_train,Y_train)

    print("Model learnt Successfully.")


    #################################################################
    # Step 6 : Model Prediction
    #################################################################
    Pred_res0 = model0.predict(X_test)
    Pred_res10 = model10.predict(X_test)
    Pred_res42 = model42.predict(X_test)

    print("Actual Result : ", list(Y_test))
    print("Predicted Result with random_state 0 : ", Pred_res0)
    print("Predicted Result with random_state 10 : ", Pred_res10)
    print("Predicted Result with random_state 42 : ", Pred_res42)

    #################################################################
    # Step 7 : Accuracy Calculation
    #################################################################
    accuracy0 = accuracy_score(Y_test, Pred_res0)
    accuracy10 = accuracy_score(Y_test, Pred_res10)
    accuracy42 = accuracy_score(Y_test, Pred_res42)

    print("Testing Accuracy of model with random_state 0 is : ", accuracy0*100)
    print("Testing Accuracy of model with random_state 10 is : ", accuracy10*100)
    print("Testing Accuracy of model with random_state 42 is : ", accuracy42*100)

    print("Model tested Successfully.")

   

if (__name__ == "__main__"):
    main()