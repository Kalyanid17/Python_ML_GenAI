#5. Without using accuracy_score, manually calculate accuracy:
# verify if it matches with sklearn acc
