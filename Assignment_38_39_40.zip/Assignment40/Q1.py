# 1. After training the Decision Tree Model, use:
# model.feature_importances_
# Display Importance score of each feature
# Which feature contributes the most in predicting FinalResult?
# Which feature contributes the least in predicting FinalResult?

import pandas  as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
     accuracy_score,
     confusion_matrix,
     ConfusionMatrixDisplay
)
import matplotlib.pyplot as plt
import os


def main():
    
    filePath = os.path.pardir + "/student_performance_ml.csv"
    
    ################################################
    #1. Dataset loading
    ###############################################
    df = pd.read_csv(filePath)

    ################################################
    #2. Data Analysis
    ###############################################
    print("Shape of Dataset : " , df.shape)
    print("Column Names : ", list(df.columns))

    print("Missing values(Per column)")
    print(df.isnull().sum())

    print("Class Distribution(FinalResult count)")
    print(df["FinalResult"].value_counts())

    print("Statistical report of Dataset")
    print(df.describe())

    #################################################################
    # Step 3 : Visualisation od Dataset
    #################################################################

    #Scatter plot
    plt.figure(figsize=(7,5))   #Decides a plane, till 7 on X axix and 5 on Y axis

    #In case of multiclass classification, its difficult to understand the data
    #using visualization, hence convert it into binary classification by considering 2 features.
    #Here we are considering petal length and petal width

    for sp in df["FinalResult"].unique():
        temp = df[df["FinalResult"] == sp]
        plt.scatter(temp["StudyHours"], temp["Attendance"], label = sp)

    plt.title("Student Evaluation")
    plt.xlabel("StudyHours")
    plt.ylabel("Attendance")

    plt.legend()
    plt.grid(True)
    plt.show()  #Shows the picture created in memory.


    #################################################################
    # Step 4 : train_test_split
    #################################################################
    feature_cols = [
            "StudyHours",
            "Attendance",
            "PreviousScore",
            "AssignmentsCompleted",
            "SleepHours"]


    X = df[feature_cols]
    
    Y = df["FinalResult"]

    X_train, X_test, Y_train, Y_test = train_test_split(X,Y,test_size=0.2,random_state=42) 

    #################################################################
    # Step 5 : Model training
    #################################################################
    model = DecisionTreeClassifier(criterion="gini",max_depth=5, random_state=42)

    model.fit(X_train,Y_train)

    print("Model learnt Successfully.")

    model_pref = model.feature_importances_
    print(" Feature contribution in model training : ", model_pref)
    print(" Feature Attendance contributed the most in model training")
    print(" Feature StudyHours,PreviousScore,AssignmentsCompleted,SleepHours contributed the least in model training")
    #################################################################
    # Step 6 : Model Prediction
    #################################################################
    Pred_res = model.predict(X_test)

    print("Actual Result : ", list(Y_test))
    print("Predicted Result : ", Pred_res)

    #################################################################
    # Step 7 : Accuracy Calculation
    #################################################################
    accuracy = accuracy_score(Y_test, Pred_res)

    print("Testing Accuracy of model is : ", accuracy*100)

    print("Model tested Successfully.")

    #################################################################
    # Step 8 : Confusion Matrix Generation
    #################################################################
    cm = confusion_matrix(Y_test, Pred_res)

    print("Confusion Matrix is : ")
    print(cm)

    #################################################################
    # Step 9 : Final Conclusion
    #################################################################
    print("Please check for Plotted Confusion Matrix ")
    data = ConfusionMatrixDisplay(confusion_matrix=cm,display_labels=model.classes_)
    data.plot()
    plt.show()

    print("Model Testing Accuracy  is : ", accuracy*100)
    print(f"Since average accuracy is 100% its best Model to Decide if Student Pass Or Fail in Exam according to provided parameters")

    #################################################################
    # Step 9 : Final Conclusion
    #################################################################

if (__name__ == "__main__"):
    main()