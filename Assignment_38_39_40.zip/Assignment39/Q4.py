# Generate confusion matrix using sklearn. Display it using ConfusionMatrixDisplay.
# explain clearly 
# True Positive, True Negative, False Positive,False Negative

import pandas  as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
     accuracy_score,
     confusion_matrix,
     ConfusionMatrixDisplay
)
import matplotlib.pyplot as plt
import os


def main():
    
    filePath = os.path.pardir + "/student_performance_ml.csv"
    
    df = pd.read_csv(filePath)

    feature_cols = [
            "StudyHours",
            "Attendance",
            "PreviousScore",
            "AssignmentsCompleted",
            "SleepHours"]


    X = df[feature_cols]
    
    Y = df["FinalResult"]

    X_train, X_test, Y_train, Y_test = train_test_split(X,Y,test_size=0.2,random_state=42) 

    model = DecisionTreeClassifier(criterion="gini",max_depth=5, random_state=42)

    model.fit(X_train,Y_train)

    print("Model learnt Successfully.")

    Pred_res = model.predict(X_test)

    print("Actual Result : ", list(Y_test))
    print("Predicted Result : ", Pred_res)

    accuracy = accuracy_score(Y_test, Pred_res)

    print("Accuracy of model is : ", accuracy*100)

    print("Model tested Successfully.")

    cm = confusion_matrix(Y_test, Pred_res)

    print("Confusion Matrix is : ")
    print(cm)

    print("Please check for Plotted Confusion Matrix ")
    data = ConfusionMatrixDisplay(confusion_matrix=cm,display_labels=model.classes_)
    data.plot()
    plt.show()


if (__name__ == "__main__"):
    main()