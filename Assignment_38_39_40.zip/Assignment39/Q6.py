# Train tree decidion Tree model with :
# max_depth = 1
# max_depth = 3
# max_depth = None
# Compare their testing accuracies write your observations


import pandas  as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
     accuracy_score,
     confusion_matrix,
     ConfusionMatrixDisplay
)
import matplotlib.pyplot as plt
import os


def main():
    
    filePath = os.path.pardir + "/student_performance_ml.csv"
    
    df = pd.read_csv(filePath)

    feature_cols = [
            "StudyHours",
            "Attendance",
            "PreviousScore",
            "AssignmentsCompleted",
            "SleepHours"]


    X = df[feature_cols]
    
    Y = df["FinalResult"]

    X_train, X_test, Y_train, Y_test = train_test_split(X,Y,test_size=0.5,random_state=42) 

    model_depth_None = DecisionTreeClassifier(criterion="gini",max_depth=None)
    model_depth_1 = DecisionTreeClassifier(criterion="gini",max_depth=1)
    model_depth_3 = DecisionTreeClassifier(criterion="gini", max_depth=3)

    model_depth_None.fit(X_train,Y_train)
    model_depth_1.fit(X_train,Y_train)
    model_depth_3.fit(X_train,Y_train)

    print("Model learnt Successfully.")

    Pred_res_dNone = model_depth_None.predict(X_test)
    Pred_res_d1 = model_depth_1.predict(X_test)
    Pred_res_d3 = model_depth_3.predict(X_test)


    acc_dNone = accuracy_score(Y_test, Pred_res_dNone)
    acc_d1 = accuracy_score(Y_test, Pred_res_d1)
    acc_d3 = accuracy_score(Y_test, Pred_res_d3)

    print("Testing Accuracy of model with MaxDepth None is : ", acc_dNone*100)
    print("Testing Accuracy of model with MaxDepth 1 is : ", acc_d1*100)
    print("Testing Accuracy of model with MaxDepth 3 is : ", acc_d3*100)

    print("Model tested Successfully.")

   


if (__name__ == "__main__"):
    main()

    #With test_size = 0.2 ,  all 3 models are giving testing accuracy 100 %.
    #Whereas  test_size = 0.5 ,  all 3 models are giving testing accuracy 93.3333 %.
    # Hence All 3 models are performing in a same way for different max_depth values. 