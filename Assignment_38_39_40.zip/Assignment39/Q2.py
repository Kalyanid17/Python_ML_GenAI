#Use trained model to predict the results for X_test. Display predicted values along with the
#actual values.

#Import DecisionTreeClassifier from sklearn.Create model object and train it using fit.

import pandas  as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
import os


def main():
    
    filePath = os.path.pardir + "/student_performance_ml.csv"
    
    df = pd.read_csv(filePath)

    feature_cols = [
            "StudyHours",
            "Attendance",
            "PreviousScore",
            "AssignmentsCompleted",
            "SleepHours"]


    X = df[feature_cols]
    
    Y = df["FinalResult"]

    X_train, X_test, Y_train, Y_test = train_test_split(X,Y,test_size=0.2,random_state=42) 

    model = DecisionTreeClassifier(criterion="gini",max_depth=5, random_state=42)

    model.fit(X_train,Y_train)

    print("Model learnt Successfully.")

    Pred_res = model.predict(X_test)

    print("Actual Result : ", list(Y_test))
    print("Predicted Result : ", Pred_res)


if (__name__ == "__main__"):
    main()