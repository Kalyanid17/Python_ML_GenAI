# Visualize 
# Plot Confusion matrix and ROC curve --
# Err - TypeError: unsupported operand type(s) for -: 'str' and 'str'
# need to try encoding Depedent variable, i.e 'Y'

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import ConfusionMatrixDisplay, accuracy_score, auc,confusion_matrix,classification_report, roc_curve

from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier

def Visualize(lrr_model,knn_model,rf_model, cm_lrr, cm_knn, cm_rf,Y_test, lrr_pred,knn_pred,rf_pred):
    print("Plot Confusion matrix (Logistic Regression): ") 
    data = ConfusionMatrixDisplay(confusion_matrix=cm_lrr, display_labels = lrr_model.classes_)
    data.plot()
    plt.title("Logistic Regression Confusion Matrix")
    plt.show()

    print("Plot Confusion matrix (KNN): ") 
    data = ConfusionMatrixDisplay(confusion_matrix=cm_knn, display_labels = knn_model.classes_)
    data.plot()
    plt.title("K Nearest Neighbour Confusion Matrix")
    plt.show()

    print("Plot Confusion matrix (Random Forest): ") 
    data = ConfusionMatrixDisplay(confusion_matrix=cm_rf, display_labels = rf_model.classes_)
    data.plot()
    plt.title("Random Forest Confusion Matrix")
    plt.show()

    # ROC Curve
    # Calculate ROC curve
    #Y_test = Y_test.map({'yes': 1, 'no': 0}).astype(int)
    #lrr_pred = lrr_pred.map({'yes': 1, 'no': 0}).astype(int)
    fpr, tpr, thresholds = roc_curve(Y_test, lrr_pred, pos_label=1) 
    roc_auc = auc(fpr, tpr)
    # Plot the ROC curve
    plt.figure()  
    plt.plot(fpr, tpr, label='ROC curve (area = %0.2f)' % roc_auc)
    plt.plot([0, 1], [0, 1], 'k--', label='No Skill')
    plt.xlim([0.0, 1.0])
    plt.ylim([0, 1])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('ROC Curve for Logistic Regression Classifier')
    plt.legend()
    plt.show()

def EvaluateModel(X_test,Y_test,lrr_model,knn_model,rf_model):
    # Accuracy
    lrr_pred = lrr_model.predict(X_test)
    lrr_accuracy = accuracy_score(Y_test, lrr_pred)

    knn_pred = knn_model.predict(X_test)
    knn_accuracy = accuracy_score(Y_test,knn_pred)

    rf_pred = rf_model.predict(X_test)
    rf_accuracy = accuracy_score(Y_test,rf_pred)

    print("Accuracy of Logistic Regression Model : ", lrr_accuracy*100)
    print("Accuracy of K Nearest Neighouber Model : ", knn_accuracy*100)
    print("Accuracy of Random Forest Model : ", rf_accuracy*100)

    # Confusion Matrix
    cm_lrr = confusion_matrix(Y_test,lrr_pred) 
    cm_knn = confusion_matrix(Y_test,knn_pred) 
    cm_rf = confusion_matrix(Y_test,rf_pred) 

    print("Confusion Matrix of Logistic Regression Model : ")
    print(cm_lrr)
    print("Confusion Matrix of K Nearest Neighouber Model : ")
    print(cm_knn)
    print("Confusion Matrix of Random Forest  Model : ")
    print(cm_rf)

    # Classification report
    print("Classification Report of Logistic Regression Model : ")
    print(classification_report(Y_test,lrr_pred))
    print("Classification Report of K Nearest Neighouber Model : ")
    print(classification_report(Y_test,knn_pred))
    print("Classification Report of Random Forest Model : ")
    print(classification_report(Y_test,rf_pred))

    Visualize(lrr_model,knn_model,rf_model, cm_lrr, cm_knn, cm_rf,Y_test, lrr_pred,knn_pred,rf_pred)

    return cm_lrr, cm_knn, cm_rf

def BuildModel(X_train,X_test,Y_train,Y_test):
    lrr_model = LogisticRegression(max_iter=5000)
    knn_model = KNeighborsClassifier(n_neighbors=6)
    rf_model = RandomForestClassifier(n_estimators=10,random_state=42)

    lrr_model = lrr_model.fit(X_train,Y_train)
    knn_model = knn_model.fit(X_train,Y_train)
    rf_model = rf_model.fit(X_train,Y_train)

    return lrr_model,knn_model,rf_model

def SplitData(X_Scaled,Y):
    X_train,X_test,Y_train,Y_test = train_test_split(X_Scaled,Y, test_size=0.2,random_state=42)
    return X_train,X_test,Y_train,Y_test

def ScaleData(df):
    #Since values for numerc colunms has big differences, need to scale it
    #Split Features and labels
    X = df.drop("y", axis=1)
    Y = df["y"]
    
    #X_train,X_test,Y_train,Y_test = train_test_split(X,Y,test_size=0.2,random_state=42)
    
    print("Feature Scaling")

    scaler = StandardScaler()

    #Independent variable scaling
    #X_train_scaled = scaler.fit_transform(X_train)
    X_scaled = scaler.fit_transform(X)
    print("Feature scaling is done")
    return X_scaled, Y

def EncodeData(df):
    #Encoding all categorical columns
    #Encode job column
    df = pd.get_dummies(df,columns=["job"],drop_first=True)
    #Encode marital colmn
    df = pd.get_dummies(df,columns=["marital"], drop_first=True)
    #Encode education colmn
    df = pd.get_dummies(df,columns=["education"], drop_first=True)
    #Encode default colmn
    df = pd.get_dummies(df,columns=["default"], drop_first=True)
    #Encode housing colmn
    df = pd.get_dummies(df,columns=["housing"], drop_first=True)
    #Encode loan colmn
    df = pd.get_dummies(df,columns=["loan"], drop_first=True)
    #Encode month colmn
    df = pd.get_dummies(df,columns=["month"], drop_first=True)

    print("Data after encoding")
    
    print(df.head())

    #     Data after encoding
    #    age  balance  day  duration  campaign  job_blue-collar  ...  month_mar  month_may  month_nov  month_oct  month_sep  y_yes
    # 0   58     2143    5       261         1            False  ...      False       True      False      False      False  False
    # 1   44       29    5       151         1            False  ...      False       True      False      False      False  False

    #Convert boolean columns into integer, to remove True False from above data
    for col in df.columns:
        if(df[col].dtype == bool):
            df[col] = df[col].astype(int)


    print("\nData after encoding")

    print(df.head(10))
    
    return df


def LoadData(Datapath):

    df = pd.read_csv(Datapath,sep=';')

    print("COLUMNS : ")
    print(df.columns)
    # Handle missing or unknown values (e.g unknown in categorical features)
    drop_cols = ["contact","pdays","previous","poutcome"]
    existing_columns = [col for col in drop_cols if col in df.columns]

    print("\n Columns to be dropped : ")
    print(existing_columns)

    # Drop unwanted columns
    df = df.drop(columns=existing_columns)
    print("Data after column removal")
    print(df.head())

    # Display basic stats and visuallize data distribution
    print("Shape : ", df.shape)
    print("Missing Values : ")
    print(df.isnull().sum())
    print("First 5 lines : ")
    print(df.head())
    
    sns.scatterplot(x=df['balance'], y=df['y'])
    #sns.boxplot(x=df['y'])
    plt.title("Bank data Scatterplot")
    plt.xlabel("Balance")
    plt.ylabel("y")
    plt.show()

    return df


def main():
    df = LoadData("bank-full.csv")
    
    df = EncodeData(df)
    X_Scaled, Y = ScaleData(df)
    X_train,X_test,Y_train,Y_test = SplitData(X_Scaled,Y)
    lrr_model,knn_model,rf_model  = BuildModel(X_train,X_test,Y_train,Y_test)
    cm_lrr, cm_knn, cm_rf = EvaluateModel(X_test,Y_test,lrr_model,knn_model,rf_model)
    
    


if(__name__ == "__main__"):
    main()