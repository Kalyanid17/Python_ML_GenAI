# 1. Load and explore the Dataset
# Handle missing or unknown values (e.g unknown in categorical features)
# Display basic stats and visuallize data distribution

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def LoadData(Datapath):

    df = pd.read_csv(Datapath,sep=';')

    print("COLUMNS : ")
    print(df.columns)
    # Handle missing or unknown values (e.g unknown in categorical features)
    drop_cols = ["contact","pdays","previous","poutcome"]
    existing_columns = [col for col in drop_cols if col in df.columns]

    print("\n Columns to be dropped : ")
    print(existing_columns)

    # Drop unwanted columns
    df = df.drop(columns=existing_columns)
    print("Data after column removal")
    print(df.head())

    # Display basic stats and visuallize data distribution
    print("Shape : ", df.shape)
    print("Missing Values : ")
    print(df.isnull().sum())
    print("First 5 lines : ")
    print(df.head())
    
    sns.scatterplot(x=df['balance'], y=df['y'])
    #sns.boxplot(x=df['y'])
    plt.title("Bank data Scatterplot")
    plt.xlabel("Balance")
    plt.ylabel("y")
    plt.show()


def main():
    LoadData("bank-full.csv")


if(__name__ == "__main__"):
    main()