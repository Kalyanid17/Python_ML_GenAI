# 2. Preprocess the Data
# Convert categorical vars using label encoding or one-hot encoding
# Scale numeric features (e.g StandardScalar)

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


def ScaleData(df):
    #Split Features and labels
    X = df.drop("y", axis=1)
    Y = df["y"]
    
    #X_train,X_test,Y_train,Y_test = train_test_split(X,Y,test_size=0.2,random_state=42)
    
    print("Feature Scaling")

    scaler = StandardScaler()

    #Independent variable scaling
    #X_train_scaled = scaler.fit_transform(X_train)
    X_scaled = scaler.fit_transform(X)
    print("Feature scaling is done")
    return X_scaled

def EncodeData(df):
    #Encoding all categorical columns
    #Encode job column
    df = pd.get_dummies(df,columns=["job"],drop_first=True)
    #Encode marital colmn
    df = pd.get_dummies(df,columns=["marital"], drop_first=True)
    #Encode education colmn
    df = pd.get_dummies(df,columns=["education"], drop_first=True)
    #Encode default colmn
    df = pd.get_dummies(df,columns=["default"], drop_first=True)
    #Encode housing colmn
    df = pd.get_dummies(df,columns=["housing"], drop_first=True)
    #Encode loan colmn
    df = pd.get_dummies(df,columns=["loan"], drop_first=True)
    #Encode month colmn
    df = pd.get_dummies(df,columns=["month"], drop_first=True)
    #Encode y colmn
    #df = pd.get_dummies(df,columns=["y"], drop_first=True)


    print("Data after encoding")
    
    print(df.head())

    #     Data after encoding
    #    age  balance  day  duration  campaign  job_blue-collar  ...  month_mar  month_may  month_nov  month_oct  month_sep  y_yes
    # 0   58     2143    5       261         1            False  ...      False       True      False      False      False  False
    # 1   44       29    5       151         1            False  ...      False       True      False      False      False  False

    #Convert boolean columns into integer, to remove True False from above data
    for col in df.columns:
        if(df[col].dtype == bool):
            df[col] = df[col].astype(int)


    print("\nData after encoding")

    print(df.head(10))
    #Since values for numerc colunms has big differences, need to scale it

    return df


def LoadData(Datapath):

    df = pd.read_csv(Datapath,sep=';')

    print("COLUMNS : ")
    print(df.columns)
    # Handle missing or unknown values (e.g unknown in categorical features)
    drop_cols = ["contact","pdays","previous","poutcome"]
    existing_columns = [col for col in drop_cols if col in df.columns]

    print("\n Columns to be dropped : ")
    print(existing_columns)

    # Drop unwanted columns
    df = df.drop(columns=existing_columns)
    print("Data after column removal")
    print(df.head())

    # Display basic stats and visuallize data distribution
    print("Shape : ", df.shape)
    print("Missing Values : ")
    print(df.isnull().sum())
    print("First 5 lines : ")
    print(df.head())
    
    sns.scatterplot(x=df['balance'], y=df['y'])
    #sns.boxplot(x=df['y'])
    plt.title("Bank data Scatterplot")
    plt.xlabel("Balance")
    plt.ylabel("y")
    plt.show()

    return df


def main():
    df = LoadData("bank-full.csv")
    
    df = EncodeData(df)
    X_Scaled = ScaleData(df)
    


if(__name__ == "__main__"):
    main()