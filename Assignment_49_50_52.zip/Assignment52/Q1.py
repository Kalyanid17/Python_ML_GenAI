# Cluster students into different academic performance groups based on features like :
# Final grade, study time, Failures, Absences
# This helps identify :
# Top performers, Average students, Sruggling students
# Dataset Name : Student Performance DataSet

# Selected Features:
# Use these numerical features for clustering :
# G1, G2, G3 -> First, Second, Final grades
# StudyTime : weekly study hours
# Failuers : No of past class's failuer
# Absences : No of school absences

# You should create below clusters as
# Top performers(cluster 0), Average Student(cluster 1), Struggeling student(cluster 2)

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.discriminant_analysis import StandardScaler
from sklearn.cluster import KMeans

def main():

    #----------------------------------------------------
    # Step 1 : Load the data
    #----------------------------------------------------
    print("Load Data : ")
    df = pd.read_csv("student-mat.csv",sep=';')

    print("Missing value check: ")
    df.isnull().sum()

    print("First few records : ")
    print(df.head(5))

    print("Shape of a dataset : ")
    print(df.shape)

    #----------------------------------------------------
    # Step 2 : Select Features (Inpedependent)
    #----------------------------------------------------
    print("Step 2 : Select Features (Inpedependent)")
    
    X = df[["G1","G2","G3","studytime","failures", "absences"]]
    print("Selected Features : ")
    print(X.head())

    print("Shape of selected features : ")
    print(X.shape)

    #----------------------------------------------------
    # Step 3: Scale the data
    #----------------------------------------------------
  
    print("Step 3: Scale the data")
    scalar = StandardScaler()
    X_scaled = scalar.fit_transform(X)

    print("Data after scaling : ")
    print(X_scaled[:5]) # X_scaled becomes, rowwise data, but head method needs 
    # it as columnwise, hence instead of using head, we write :5 , it will give us 1st 5 rows

    #----------------------------------------------------
    # Step 4: Use elbow method
    #----------------------------------------------------
    print("Step 4: Use elbow method")

    WCSS = []
    for i in range(1,11):
        # how many times its should repeat  - n_init
        model = KMeans(n_clusters=i, random_state=42, n_init=10)
        model.fit(X_scaled)
        WCSS.append(model.inertia_)

    plt.figure(figsize=(8,5))
    plt.plot(range(1,11), WCSS, marker = 'o')
    plt.xlabel("Number of Clusters")
    plt.ylabel("WCSS")
    plt.title("Elbow method")
    plt.grid(True)
    plt.show()

    #----------------------------------------------------
    # Step 5: Train the model
    #----------------------------------------------------
    print("Step 5: Train the model")
   
    model = KMeans(n_clusters=3, random_state=42, n_init=10)
    clusters = model.fit_predict(X_scaled)
    df["cluster"] = clusters

    print("Dataset with cluster")
    print(df.head(50))

if (__name__ == "__main__"):
    main()