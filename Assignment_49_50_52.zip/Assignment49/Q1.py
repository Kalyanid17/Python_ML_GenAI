# Exploratory Data Analysis(EDA):

# Load a dataset using pndas.
# Display the first 5 rows.
# Show column info and check for null values.
# Display basic statistics using .describe()
# Plot the distribution of the target variable(Outcome)
# Use graph like hist,boxplot or pairplot to identify patterns or outliers.

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def EDA():
    #######################################################
    # 1. Load a dataset using pndas
    #######################################################
    df = pd.read_csv("diabetes.csv")

    print("First 5 lines of Dataset : ")
    print(df.head())

    print("Column Information : ")
    print(df.columns)

    print("Null Checks : ")
    print(df.isnull().sum())
    
    print("Basic statistics of the dataset is : ")
    print(df.describe())

    print("Boxplot : ")
    sns.boxplot(x=df['Outcome'])
    plt.title("Diabetes")
    plt.show()

    #######################################################
    # 2. Find dependent and independent variables
    #######################################################
    X = df.drop("Outcome", axis=1)
    Y = df['Outcome']

    # print("Scatterplot Or Pairplot : ")
    # sns.scatterplot(y=Y)
    # plt.title("Diabetes")
    # plt.show()


def main():
    print("EDA (Exploratory Data Analysis)")
    EDA()

if __name__ == "__main__":
    main()
