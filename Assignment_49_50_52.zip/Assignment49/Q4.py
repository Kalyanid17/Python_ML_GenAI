# 4. Model Evaluation
# Print Accuracy score, confusion matrix, precision, recall and F1 score
# Use matplotlib or seaborn to visualize confusionmatrix.


import joblib
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.discriminant_analysis import StandardScaler
from sklearn.model_selection import train_test_split

from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score,confusion_matrix,precision_score,recall_score,f1_score,ConfusionMatrixDisplay

def PreserveModel(model, filename):
    joblib.dump(model,filename=filename)

    print("Model preserved successfully with name", filename)

def EDA():
    #######################################################
    # 1. Load a dataset using pndas
    #######################################################
    df = pd.read_csv("diabetes.csv")

    print("First 5 lines of Dataset : ")
    print(df.head())

    print("Column Information : ")
    print(df.columns)

    print("Null Checks : ")
    print(df.isnull().sum())
    
    print("Basic statistics of the dataset is : ")
    print(df.describe())

    print("Boxplot : ")
    sns.boxplot(x=df['Outcome'])
    plt.title("Diabetes")
    plt.show()

    # Handle Glucose column. Since Glucose can not be 0 in living person, we are 
    # replacing 0 with median
    df["Glucose"] = pd.to_numeric(df["Glucose"],errors="coerce")
    glucose_median = df["Glucose"].median()
    df["Glucose"] = df["Glucose"].fillna(glucose_median)
    print("Glucose column after replacement : ")
    print(df["Glucose"])

    # Handle Bloodpressure column. Since Bloodpressure can not be 0 in living person, we are 
    # replacing 0 with median
    df["BloodPressure"] = pd.to_numeric(df["BloodPressure"],errors="coerce")
    Bloodpressure_median = df["BloodPressure"].median()
    df["BloodPressure"] = df["BloodPressure"].fillna(Bloodpressure_median)
    print("Bloodpressure column after replacement : ")
    print(df["BloodPressure"])

    #######################################################
    # 2. Find dependent and independent variables
    #######################################################
    X = df.drop("Outcome", axis=1)
    Y = df['Outcome']

    print("Scale the data")
    scalar = StandardScaler()
    X_scaled = scalar.fit_transform(X)

    #######################################################
    # 3. Model building
    #######################################################

    logisticModel = LogisticRegression(max_iter=5000)
    DTModel = DecisionTreeClassifier(max_depth=5)
    KNNModel = KNeighborsClassifier(n_neighbors=18)

    X_train,X_test,Y_train,Y_test = train_test_split(X_scaled,Y,test_size=0.2,random_state=42)

    logisticModel.fit(X_train,Y_train)
    DTModel.fit(X_train,Y_train)
    KNNModel.fit(X_train,Y_train)


    # step 5 : Calculate individual accuracy
    pred_lr = logisticModel.predict(X_test)
    pred_dt = DTModel.predict(X_test)
    pred_knn = KNNModel.predict(X_test)
    

    logi_acc = accuracy_score(Y_test,pred_lr)
    dt_acc = accuracy_score(Y_test,pred_dt)
    knn_acc = accuracy_score(Y_test,pred_knn)

    # knn_acc = 0
    # #KNN
    # for i in range(1,20):
    #     KNNModel = KNeighborsClassifier(n_neighbors=i)
    #     KNNModel.fit(X_train,Y_train)
    #     pred_knn = KNNModel.predict(X_test)
    #     if (accuracy_score(pred_knn,Y_test)> knn_acc):
    #         knn_acc = accuracy_score(pred_knn,Y_test)
    #         mxAccK = i
    # print("Max KNN Acc is : ", knn_acc, " For K = ", mxAccK), K = 18

    print("Logistic Accuracy : ", logi_acc * 100)
    print("DT Accuracy : ", dt_acc * 100)
    print("KNN Accuracy : ", knn_acc * 100)  

    # Since Accuracy for Decision tree is high , we are preserving the Decision Tree model

    PreserveModel(DTModel,"ASSIGN49_DT.pkl")

    print("*************** Logistic Regression *********************")
    print("Confusion Matrix ")
    cm_lr = confusion_matrix(Y_test,pred_lr)
    print(cm_lr)
    print("Precisiion : ")
    pr_lr = precision_score(Y_test,pred_lr)
    print(pr_lr)
    print("Recall : ")
    rc_lr = recall_score(Y_test,pred_lr)
    print(rc_lr)
    print("F1 Score : ")
    f1_lr = f1_score(Y_test,pred_lr)
    print(f1_lr)

    print("*************** Decision Tree  *********************")
    print("Confusion Matrix ")
    cm_dt = confusion_matrix(Y_test,pred_dt)
    print(cm_dt)
    print("Precisiion : ")
    pr_dt = precision_score(Y_test,pred_dt)
    print(pr_dt)
    print("Recall : ")
    rc_dt = recall_score(Y_test,pred_dt)
    print(rc_dt)
    print("F1 Score : ")
    f1_dt = f1_score(Y_test,pred_dt)
    print(f1_dt)

    print("*************** KNN *********************")
    print("Confusion Matrix ")
    cm_knn = confusion_matrix(Y_test,pred_knn)
    print(cm_knn)
    print("Precisiion : ")
    pr_knn = precision_score(Y_test,pred_knn)
    print(pr_knn)
    print("Recall : ")
    rc_knn = recall_score(Y_test,pred_knn)
    print(rc_knn)
    print("F1 Score : ")
    f1_knn = f1_score(Y_test,pred_knn)
    print(f1_knn)

    print("******************** Plot Confusion Matrix, Logistic Regression ******************")
    data = ConfusionMatrixDisplay(confusion_matrix=cm_lr,display_labels=logisticModel.classes_)
    data.plot()
    plt.title("Confusion Matrix : Logistic Regression")
    plt.show()

    print("******************** Plot Confusion Matrix, Decision Tree ******************")
    data = ConfusionMatrixDisplay(confusion_matrix=cm_dt,display_labels=DTModel.classes_)
    data.plot()
    plt.title("Confusion Matrix : Decision Tree")
    plt.show()

    print("******************** Plot Confusion Matrix, KNN ******************")
    data = ConfusionMatrixDisplay(confusion_matrix=cm_knn,display_labels=KNNModel.classes_)
    data.plot()
    plt.title("Confusion Matrix : KNN")
    plt.show()

def main():
    print("EDA (Exploratory Data Analysis)")
    EDA()

if __name__ == "__main__":
    main()