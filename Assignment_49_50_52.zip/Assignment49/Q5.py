# Final Output : Predict whether a patient is diabetic on test data.
# Display predictions on screen and save them in csv file

import joblib
import pandas as pd


def LoadPreservedModel(filename):
    loaded_model = joblib.load(filename)

    print("Model loaded successfully")
    return loaded_model

def main():
    loaded_model = LoadPreservedModel("ASSIGN49_DT.pkl")

    diabetes = pd.read_csv("Test.csv")
    print("Loaded data : ", diabetes.head())

    X_TEST = diabetes.drop("Outcome", axis=1)
    #Y = diabetes['Outcome']

    Y_pred = loaded_model.predict(X_TEST)
    pd.DataFrame(Y_pred).to_csv("TestedOutcome.csv")

    

if __name__ == "__main__":
    main()