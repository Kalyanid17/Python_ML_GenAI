# Check and handle missing zero values in column like Glucose, Bloodpressure etc.
# Apply feature scaling using StandardScalar or MinMaxScalar
# Split the dataset in Features(X) and Target(Y)

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.discriminant_analysis import StandardScaler

def EDA():
    #######################################################
    # 1. Load a dataset using pndas
    #######################################################
    df = pd.read_csv("diabetes.csv")

    print("First 5 lines of Dataset : ")
    print(df.head())

    print("Column Information : ")
    print(df.columns)

    print("Null Checks : ")
    print(df.isnull().sum())
    
    print("Basic statistics of the dataset is : ")
    print(df.describe())

    print("Boxplot : ")
    sns.boxplot(x=df['Outcome'])
    plt.title("Diabetes")
    plt.show()

    # Handle Glucose column. Since Glucose can not be 0 in living person, we are 
    # replacing 0 with median
    df["Glucose"] = pd.to_numeric(df["Glucose"],errors="coerce")
    glucose_median = df["Glucose"].median()
    df["Glucose"] = df["Glucose"].fillna(glucose_median)
    print("Glucose column after replacement : ")
    print(df["Glucose"])

    # Handle Bloodpressure column. Since Bloodpressure can not be 0 in living person, we are 
    # replacing 0 with median
    df["BloodPressure"] = pd.to_numeric(df["BloodPressure"],errors="coerce")
    Bloodpressure_median = df["BloodPressure"].median()
    df["BloodPressure"] = df["BloodPressure"].fillna(Bloodpressure_median)
    print("Bloodpressure column after replacement : ")
    print(df["BloodPressure"])

    #######################################################
    # 2. Find dependent and independent variables
    #######################################################
    X = df.drop("Outcome", axis=1)
    Y = df['Outcome']

    print("Scale the data")
    scalar = StandardScaler()
    X_scaled = scalar.fit_transform(X)

def main():
    print("EDA (Exploratory Data Analysis)")
    EDA()

if __name__ == "__main__":
    main()
