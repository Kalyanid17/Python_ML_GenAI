# 3. Model Building
# Train at least 2 different algorithms on the dataset:
# Logistic Regression
# K - Nearest Neighbors(KNN)
# Decision UnicodeTranslateError
# Use train_test_split to devide the data


import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.discriminant_analysis import StandardScaler
from sklearn.model_selection import train_test_split

from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score,confusion_matrix


def EDA():
    #######################################################
    # 1. Load a dataset using pndas
    #######################################################
    df = pd.read_csv("diabetes.csv")

    print("First 5 lines of Dataset : ")
    print(df.head())

    print("Column Information : ")
    print(df.columns)

    print("Null Checks : ")
    print(df.isnull().sum())
    
    print("Basic statistics of the dataset is : ")
    print(df.describe())

    print("Boxplot : ")
    sns.boxplot(x=df['Outcome'])
    plt.title("Diabetes")
    plt.show()

    # Handle Glucose column. Since Glucose can not be 0 in living person, we are 
    # replacing 0 with median
    df["Glucose"] = pd.to_numeric(df["Glucose"],errors="coerce")
    glucose_median = df["Glucose"].median()
    df["Glucose"] = df["Glucose"].fillna(glucose_median)
    print("Glucose column after replacement : ")
    print(df["Glucose"])

    # Handle Bloodpressure column. Since Bloodpressure can not be 0 in living person, we are 
    # replacing 0 with median
    df["BloodPressure"] = pd.to_numeric(df["BloodPressure"],errors="coerce")
    Bloodpressure_median = df["BloodPressure"].median()
    df["BloodPressure"] = df["BloodPressure"].fillna(Bloodpressure_median)
    print("Bloodpressure column after replacement : ")
    print(df["BloodPressure"])

    #######################################################
    # 2. Find dependent and independent variables
    #######################################################
    X = df.drop("Outcome", axis=1)
    Y = df['Outcome']

    print("Scale the data")
    scalar = StandardScaler()
    X_scaled = scalar.fit_transform(X)

    #######################################################
    # 3. Model building
    #######################################################

    logisticModel = LogisticRegression(max_iter=5000)
    DTModel = DecisionTreeClassifier(max_depth=5)
    KNNModel = KNeighborsClassifier(n_neighbors=18)
   

    X_train,X_test,Y_train,Y_test = train_test_split(X_scaled,Y,test_size=0.2,random_state=42)

def main():
    print("EDA (Exploratory Data Analysis)")
    EDA()

if __name__ == "__main__":
    main()