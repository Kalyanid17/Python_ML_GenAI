import hashlib #module to help calculate MD file checksum

def CalculateChecksum(FileName):    #4567 byte assume
    fobj = open(FileName, "rb")

    hobj  = hashlib.md5()

    buffer = fobj.read(1000)    #1 KB = 1024 bytes

    while(len(buffer) > 0):
        hobj.update(buffer)
        buffer = fobj.read(1024) 

    fobj.close()

    return hobj.hexdigest() #retuns hexadecimal string

def main():

    Ret = CalculateChecksum("Demo.txt")

    print("Checksum is : ", Ret)

if (__name__ == "__main__"):
    main()