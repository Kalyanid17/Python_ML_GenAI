#by default command line args are string, since string is flexible datatype
import sys

def main():
   print(sys.argv[0])   #CommandLine2
   print(len(sys.argv)) #1

if __name__ == ("__main__"):
    main()

#CommandLine2.py 11 21 
    