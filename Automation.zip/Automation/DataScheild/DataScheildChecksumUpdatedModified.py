
import psutil
import sys
import os
import time
import schedule
import shutil
import hashlib

def calculate_hash(path):
    hobj = hashlib.md5()

    fobj = open(path, "rb")

    while True:
        data = fobj.read(1024)
        if not data:
            break
        else:
            hobj.update(data)
    fobj.close()

    return hobj.hexdigest()
    
def BackupFiles(Source, Destination):
    copied_files = []
    print("Creating the backup Folder for backup process")
    #exist_ok=True, if dir already exists go ahead, dont give err
    os.makedirs(Destination, exist_ok=True) #Creates nested folders, multilevel

    for root, dirs, files in os.walk(Source):
        for file in files:
            src_path = os.path.join(root,file)

            relative = os.path.relpath(src_path,Source)

            dest_path = os.path.join(Destination,relative)

            os.makedirs(os.path.dirname(dest_path), exist_ok=True)
            
            #Copy the files if its new or updated
            
            if((not os.path.exists(dest_path)) or (calculate_hash(src_path) != calculate_hash(dest_path))):
                shutil.copy2(src_path, dest_path)   #metadata of file
                copied_files.append(relative)

            

    return copied_files


def MarvellousDataScheildStart(Source="Data"):
    BackupName = "MarvellousBackup"

    print("Backup Process started Successfully at ", time.ctime())

    files = BackupFiles(Source,BackupName)

    print("Report about the Bckup")
    for name in files:
        print(name)



#Command Line Input
def main():

    Boredr = "-"*50
    print(Boredr)
    print("====Marvellous Data Scheild System =====")
    print(Boredr)

    if(len(sys.argv) == 2):
        if(sys.argv[1] == "--h" or sys.argv[1] == "--H"):
            print("This script is used to :")
            print("1 : Takes auto backup at given time")
            print("2 : Backup only New and updated files")
            print("3 : Create an Archieve of the backup periodically")

        elif(sys.argv[1] == "--u" or sys.argv[1] == "--U"):
            print("Use the automation script as ")
            print("ScriptName.py TimeInterval SourceDirectory")
            print("TimeInterval : Time in Hour for periodic scheduling")
            print("DirectoryName : Name of Directory to autolog")
            print("SourceDirectory : Name of the Directory to be backed up")

        else:
            print("Unable to proceed as there is no such option")
            print("Unable to proceed as there is no such optionPlease use --h or --u")
    #python3 Demo.py 5 Data
    elif(len(sys.argv) == 3):
        
        
            print("Inside project logic")
            print("Time interval : ", sys.argv[1])
            print("Directory Name : ", sys.argv[2])

            #apply the scheduler
            schedule.every(int(sys.argv[1])).minutes.do(MarvellousDataScheildStart,sys.argv[2])
            
            print("Marvellous Data Scheild System started successfully")
            print("Time Interval in minutes : ", sys.argv[1])
            print("Press Ctrl+C to stop the execution")

            #Wait till abort
            while(True):
                 schedule.run_pending()
                 time.sleep(1)
    else:
        print("Invalid no of Args")
        print("Unable to proceed as there is no such option")
        print("Unable to proceed as there is no such optionPlease use --h or --u")

    print(Boredr)
    print("=========Thank you for using our script.==========")
    print(Boredr)

if(__name__ == "__main__"):
    main()