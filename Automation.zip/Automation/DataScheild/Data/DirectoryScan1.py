
import os
def main():
    DirectoryName = input("Enter the name of Directory: ")

    print("Contents of the Directoy are : ")

    for FolderName, SubFolderName , FileName in os.walk(DirectoryName):
        print("Foldername : ", FolderName)
        
        for Subf in SubFolderName:
            print("SubFolderName : ", Subf)

        for fName in FileName:
            print("Filename : ", fName)    
    

if(__name__ == "__main__"):
    main()