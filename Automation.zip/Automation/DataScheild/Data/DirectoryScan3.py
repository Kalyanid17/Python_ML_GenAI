
import os

def DirectoryScanner(DirectoryName = "Marvellous"):

    Ret = os.path.exists(DirectoryName)

    if(Ret == False):
        print("There is no such Directory")
        return

    print("Contents of the Directoy are : ")
    
    for FolderName, SubFolderName , FileName in os.walk(DirectoryName):
        print("Foldername : ", FolderName)
        
        for Subf in SubFolderName:
            print("SubFolderName : ", Subf)

        for fName in FileName:
            print("Filename : ", fName)    


def main():
    DirectoryName = input("Enter the name of Directory: ")
    
    DirectoryScanner(DirectoryName)

    
    

if(__name__ == "__main__"):
    main()