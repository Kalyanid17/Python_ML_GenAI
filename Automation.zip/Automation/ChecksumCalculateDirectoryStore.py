import hashlib #module to help calculate MD file checksum
import os

def FindDuplicate(DirectoryName = "Marvellous"): #even if name and extension is same, checksum remains same
    Ret = False


    Ret = os.path.exists(DirectoryName)

    if Ret == False:
        print("There is no such Directory")
        return
    
    Ret = os.path.isdir(DirectoryName)
    if(Ret == False):
        print("Its not a directory")
        return
    
    Duplicate = {}

    for FolderName, SubFolderName, FileName in os.walk(DirectoryName):
        
        for Fname in FileName:
            Fname = os.path.join(FolderName,Fname)
            checksum = CalculateChecksum(os.path.join(Fname))

            if(checksum in Duplicate):
                Duplicate[checksum].append(Fname)
            else:
                Duplicate[checksum] = [Fname]

    return Duplicate

def DeleteDuplicate(Path = "Marvellous"):
    MyDict = FindDuplicate(Path)
    Result = list(filter(lambda x: len(x) > 1, MyDict.values()))
    Count = 0
    Cnt = 0

    for value in Result:
        for subValue in value:
            Count = Count + 1
            if(Count > 1):
                print("Deleted File : ", subValue)
                os.remove(subValue)
                Cnt = Cnt + 1
        Count = 0

    print("Total deleted File : ", Cnt)   
            



def DisplayResult(MyDict):
    Result = list(filter(lambda x: len(x) > 1, MyDict.values()))
    Count = 0

    for value in Result:
        for subValue in value:
            Count = Count + 1
            print(subValue)

        print("Value of Count : ", Count)
        Count = 0

def CalculateChecksum(FileName):    #4567 byte assume
    fobj = open(FileName, "rb")

    hobj  = hashlib.md5()

    buffer = fobj.read(1000)    #1 KB = 1024 bytes

    while(len(buffer) > 0):
        hobj.update(buffer)
        buffer = fobj.read(1024) 

    fobj.close()

    return hobj.hexdigest() #retuns hexadecimal string

def main():
    Ret = FindDuplicate()
    DeleteDuplicate()
    #DisplayResult(Ret)
   

if (__name__ == "__main__"):
    main()
