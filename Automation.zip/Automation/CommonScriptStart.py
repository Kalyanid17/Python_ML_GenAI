
import psutil
import sys
import os
import time
import schedule

def Fun(DirName):
     pass

#Command Line Input
def main():

    Boredr = "-"*50
    print(Boredr)
    print("====Marvellous Data Scheild System =====")
    print(Boredr)

    if(len(sys.argv) == 2):
        if(sys.argv[1] == "--h" or sys.argv[1] == "--H"):
            print("This script is used to :")
            print("1 : Takes auto backup at given time")
            print("2 : Backup only New and updated files")
            print("3 : Create an Archieve of the backup periodically")

        elif(sys.argv[1] == "--u" or sys.argv[1] == "--U"):
            print("Use the automation script as ")
            print("ScriptName.py TimeInterval SourceDirectory")
            print("TimeInterval : Time in Hour for periodic scheduling")
            print("DirectoryName : Name of Directory to autolog")
            print("SourceDirectory : Name of the Directory to be backed up")

        else:
            print("Unable to proceed as there is no such option")
            print("Unable to proceed as there is no such optionPlease use --h or --u")
    #python3 Demo.py 5 Data
    elif(len(sys.argv) == 3):
        
        
            print("Inside project logic")
            print("Time interval : ", sys.argv[1])
            print("Directory Name : ", sys.argv[2])

            #apply the scheduler
            schedule.every(int(sys.argv[1])).minutes.do(Fun,sys.argv[2])
            
            print("Marvellous Data Scheild System started successfully")
            print("Time Interval in minutes : ", sys.argv[1])
            print("Press Ctrl+C to stop the execution")

            #Wait till abort
            while(True):
                 schedule.run_pending()
                 time.sleep(1)
    else:
        print("Invalid no of Args")
        print("Unable to proceed as there is no such option")
        print("Unable to proceed as there is no such optionPlease use --h or --u")

    print(Boredr)
    print("=========Thank you for using our script.==========")
    print(Boredr)

if(__name__ == "__main__"):
    main()