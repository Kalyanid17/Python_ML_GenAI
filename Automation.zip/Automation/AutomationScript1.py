import sys

def main():
    Border = "-"*40
    print(Border)
    print("----------Marvellous Automation--------")
    print(Border)

    if(len(sys.argv) == 2):
        if((sys.argv[1] == "--h") or (sys.argv[1] == "--H")):
            print("This application is used to perform _____")
            print("This is a automation script")
        
        elif((sys.argv[1] == "--u") or (sys.argv[1] == "--U")):
            print("Use the given script as _____")
            print("ScriptName.py Argument1 Argument2")
            print("Argument1:----")
            print("Argument2:----")

        else:
            print("Use the gien flags as :")
            print("--u : Used to display the Usage")
            print("--h : Used to display the Help")

    else:
        print("Invalid no of command line arguments")
        print("Use the gien flags as :")
        print("--u : Used to display the Usage")
        print("--h : Used to display the Help")

    print(Border)
    print("-------Thank you for using our script-----")
    print("------------Marvellous Infosystems--------")
    print(Border)   

if __name__ == ("__main__"):
    main()