import sys
import os
import time

def DirecoryScanner(DirName="Marvellous"):
    
    Border = "_"*50
    Timestamp = time.ctime()

    logFileName = "Marvellous%s.log" %(Timestamp)
    logFileName = logFileName.replace(" ", "_")
    logFileName = logFileName.replace(":", "_")

    fobj = open(logFileName, "w")

    fobj.write(Border+"\n")
    fobj.write("This is a Log file created by Marvellous Automation\n")
    fobj.write("This is a Directory cleaner script\n")
    fobj.write(Border+"\n")

    Ret = False
     
    Ret = os.path.exists(DirName) 

    if(Ret == False):
        print("There is no such Dir")
        return
    
    Ret = os.path.isdir(DirName)

    if(Ret == False):
        print("It is not a Directory")
        return

    FileCount = 0
    EmptyFileCount = 0

    for Foldername, SubFolder, FileName in os.walk(DirName):

        for FName in FileName:
            FileCount = FileCount + 1
            
            FName = os.path.join(Foldername,FName)

            if(os.path.getsize(FName) == 0): #Empty file
                EmptyFileCount = EmptyFileCount + 1
                os.remove(FName)

    
    
    fobj.write("------------------Automation Report---------------\n")
    fobj.write("Total files scanned : " + str(FileCount) + "\n")
    fobj.write("Total Empty Files Found : " + str(EmptyFileCount) + "\n")
    fobj.write("This log file is created at : " + Timestamp + "\n")
    fobj.write(Border + "\n")  

    fobj.close()

def main():
    Border = "_"*50
    print(Border)
    print("------------Marvellous Automation Directory-------")
    print(Border)

    if(len(sys.argv) != 2): # filter code , which allows prog to exit in case some issue
        print("Invalid no of Args")
        print("Please specify name of directory")
        return
    
    DirecoryScanner(sys.argv[1])

    print(Border)
    print("------------Marvellous Automation Directory-------")
    print(Border)

    
if(__name__ == "__main__"):
    main()



