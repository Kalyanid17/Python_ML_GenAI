import hashlib #module to help calculate MD file checksum
import os

def DirectoryWatcher(DirectoryName = "Marvellous"): #even if name and extension is different, checksum remains same for same content
    Ret = False

    Ret = os.path.exists(DirectoryName)

    if Ret == False:
        print("There is no such Directory")
        return
    
    if(Ret == False):
        print("Its not a directory")
        return
    
    for FolderName, SubFolderName, FileName in os.walk(DirectoryName):
        
        for Fname in FileName:
            Fname = os.path.join(FolderName,Fname)
            checksum = CalculateChecksum(os.path.join(Fname))

            print(f"FileName : {Fname} , Checksum : {checksum}")

def CalculateChecksum(FileName):    #4567 byte assume
    fobj = open(FileName, "rb")

    hobj  = hashlib.md5()

    buffer = fobj.read(1000)    #1 KB = 1024 bytes

    while(len(buffer) > 0):
        hobj.update(buffer)
        buffer = fobj.read(1024) 

    fobj.close()

    return hobj.hexdigest() #retuns hexadecimal string

def main():
    DirectoryWatcher()
   

if (__name__ == "__main__"):
    main()
