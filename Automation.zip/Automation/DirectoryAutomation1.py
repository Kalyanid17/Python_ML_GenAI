import sys
import os

def DirecoryScanner(DirName="Marvellous"):
    
    Ret = False
     
    Ret = os.path.exists(DirName) 

    if(Ret == False):
        print("There is no such Dir")
        return
    
    Ret = os.path.isdir(DirName)

    if(Ret == False):
        print("It is not a Directory")
        return

    for Foldername, SubFolder, FileName in os.walk(DirName):

        for FName in FileName:
            print(FName)



def main():
    Border = "_"*50
    print(Border)
    print("------------Marvellous Automation Directory-------")
    print(Border)

    if(len(sys.argv) != 2): # filter code , which allows prog to exit in case some issue
        print("Invalid no of Args")
        print("Please specify name of directory")
        return
    
    DirecoryScanner(sys.argv[1])


    
if(__name__ == "__main__"):
    main()



