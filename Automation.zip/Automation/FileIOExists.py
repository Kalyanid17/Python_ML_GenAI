
import os

def main():
    FileName = input("Enter name of File : ")

    Ret = os.path.exists(FileName) #absolute path - if it starts with /, first / -root, next / -separator
                                    #relative path - starting with letter

    if(Ret == True):
        fObj = open(FileName, "r")
        print("File gets successfully opened")
    else:
        print("File doesn't exists")

#Directory
#Current Directory - currently process kuthe ahe


    

if(__name__ == "__main__"): #dunder key word, d = double and under = underscore
    main()