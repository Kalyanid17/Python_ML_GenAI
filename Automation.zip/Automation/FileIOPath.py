
import os

def main():
    FileName = input("Enter name of File : ")

    if(os.path.exists(FileName)):
        Ret = os.path.isabs(FileName)

        if(Ret == True):
            print("It is Absolute Path")
        else:
            print("It is Relative Path")
    else:
        print("FILE DOESN'T EXISTS")

#Directory
#Current Directory - currently process kuthe ahe


    

if(__name__ == "__main__"): #dunder key word, d = double and under = underscore
    main()