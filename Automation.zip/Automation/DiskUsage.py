
import psutil
import sys
import os
import time
import schedule

def CreateLog(FolderName):
    Ret = False
    Border = "-"*50

    Ret = os.path.exists(FolderName)

    if(Ret == True):
          Ret = os.path.isdir(FolderName)

          if(Ret == False):
               print("Unable to create folder as it might be Filename")
               return       
    else:
          os.mkdir(FolderName)
          print("Directory for logfiles gets created succesfully.")
    
    TimeStamp = time.strftime("%Y-%m-%d_%H-%M-%S")
    LogFileName = os.path.join(FolderName, "Marvellous_%s.log")%(TimeStamp)
    print(LogFileName)

    fObj = open(LogFileName,"w")
    fObj.write(Border + "\n")
    fObj.write("====Marvellous Platform Serveillance System =====\n")
    fObj.write("Log Created at " + time.ctime() + "\n")
    fObj.write(Border + "\n")

    fObj.write("\n"*20)
    fObj.write(Border + "\n")
    fObj.write("==============End of Log File ======================\n")
    fObj.write(Border + "\n")

    print("CPU Usage: ", psutil.cpu_percent())
    
    mem = psutil.virtual_memory()
    print("RAM Usage : ", mem.percent)

    for part in psutil.disk_partitions():
         usage = psutil.disk_usage(part.mountpoint)
         print(f"{part.mountpoint} Used {usage.percent}%%")

#Command Line Input
def main():
    Boredr = "-"*50
    print(Boredr)
    print("====Marvellous Platform Serveillance System =====")
    print(Boredr)

    if(len(sys.argv) == 2):
        if(sys.argv[1] == "--h" or sys.argv[1] == "--H"):
            print("This script is used to :")
            print("1 : Create automatic logs")
            print("2 : Execute periodically")
            print("3 : Send mail with logs")
            print("4 : Store Info about Processes")
            print("5 : Store Info about CPU")
            print("6 : Store Info about RAM USAGE")
            print("7 : Store Info about Secondary storage")

        elif(sys.argv[1] == "--u" or sys.argv[1] == "--U"):
            print("Use the automation script as ")
            print("ScriptName.py TimeInterval DirectoryName")
            print("TimeInterval : Time in minutes for periodic scheduling")
            print("DirectoryName : Name of Directory to autolog")
        else:
            print("Unable to proceed as there is no such option")
            print("Unable to proceed as there is no such optionPlease use --h or --u")
    elif(len(sys.argv) == 3):
        #python3 Demo.py 5 Marvellous
        
            print("Inside project logic")
            print("Time interval : ", sys.argv[1])
            print("Directory Name : ", sys.argv[2])

            #apply the scheduler
            schedule.every(int(sys.argv[1])).minutes.do(CreateLog,sys.argv[2])
            
            print("Marvellous Platform Serveillance System started successfully")
            print("Directory created with name ", sys.argv[2])
            print("Time Interval in minutes : ", sys.argv[1])
            print("Press Ctrl+C to stop the execution")

            #Wait till abort
            while(True):
                 schedule.run_pending()
                 time.sleep(1)
    else:
        print("Invalid no of Args")
        print("Unable to proceed as there is no such option")
        print("Unable to proceed as there is no such optionPlease use --h or --u")

    print(Boredr)
    print("=========Thank you for using our script.==========")
    print(Boredr)

if(__name__ == "__main__"):
    main()