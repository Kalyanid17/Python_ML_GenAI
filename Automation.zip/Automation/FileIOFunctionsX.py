
import os

def main():
    FileName = input("Enter name of File : ")

    if(os.path.exists(FileName)):
        fobj = open(FileName, "w")
        
        print(fobj.readable())
        print(fobj.writable())
        print(fobj.seekable())
       

    else:
        print("File Doesn't exists")
        


#Directory
#Current Directory - currently process kuthe ahe


    

if(__name__ == "__main__"): #dunder key word, d = double and under = underscore
    main()