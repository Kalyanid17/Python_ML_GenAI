
def main():
    fobj = None
    try:
        fobj = open("Hello.txt","r")
        print("File gets Successfully opened")

        print("Current offset i s: ", fobj.tell())
        Data = fobj.read(6)
        print("Current offset i s: ", fobj.tell())

        print("Data from file is : ", Data)
        fobj.close()

    except FileNotFoundError:
        print("File not found as there is no such file")

    finally:
        print("End of Application")

if(__name__ == "__main__"): #dunder key word, d = double and under = underscore
    main()