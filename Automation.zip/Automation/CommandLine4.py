#Python3 CommandLine4.py 10 11

import sys

def main():

     print("Addition : ", int(sys.argv[1]) + int(sys.argv[2]))

if __name__ == ("__main__"):
    main()