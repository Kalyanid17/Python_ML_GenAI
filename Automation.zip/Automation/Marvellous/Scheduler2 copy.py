import time
import datetime
import schedule

def fun():
    print("Inside fun at ", datetime.datetime.now())

def main():
    print("Inside Marvellous Automationscript at : ", datetime.datetime.now())
    
    schedule.every(20).seconds.do(fun) #after 20 seconds , main prog is not there, hence it doesn't go to fun


if __name__ == "__main__" :
    main()