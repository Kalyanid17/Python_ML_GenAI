
def main():
    open("Demo.txt")

if(__name__ == "__main__"): #dunder key word, d = double and under = underscore
    main()