
import os

def main():
    FileName = input("Enter name of File : ")

    Ret = os.path.isabs(FileName)

    if(Ret == True):
        print("It is Absolute Path")
    else:
        print("It is Relative Path")
        NewPath = os.path.abspath(FileName)
        print("Updated Path :", NewPath)


#Directory
#Current Directory - currently process kuthe ahe


    

if(__name__ == "__main__"): #dunder key word, d = double and under = underscore
    main()