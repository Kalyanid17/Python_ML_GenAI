
import os

def main():
    FileName = input("Enter name of File : ")

    if(os.path.exists(FileName)):
       fobj = open(FileName, "r")

       print(fobj.name)
       print(fobj.mode)
       print(fobj.closed)

       fobj.close()
       print(fobj.closed)

    else:
        print("File Doesn't exists")
        


#Directory
#Current Directory - currently process kuthe ahe


    

if(__name__ == "__main__"): #dunder key word, d = double and under = underscore
    main()