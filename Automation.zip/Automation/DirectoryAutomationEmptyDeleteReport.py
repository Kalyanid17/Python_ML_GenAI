import sys
import os

def DirecoryScanner(DirName="Marvellous"):
    
    Ret = False
     
    Ret = os.path.exists(DirName) 

    if(Ret == False):
        print("There is no such Dir")
        return
    
    Ret = os.path.isdir(DirName)

    if(Ret == False):
        print("It is not a Directory")
        return

    FileCount = 0
    EmptyFileCount = 0

    for Foldername, SubFolder, FileName in os.walk(DirName):

        for FName in FileName:
            FileCount = FileCount + 1
            
            FName = os.path.join(Foldername,FName)
            print("FileName : ",FName)
            print("File  Size: ",os.path.getsize(FName)) 

            if(os.path.getsize(FName) == 0): #Empty file
                EmptyFileCount = EmptyFileCount + 1
                os.remove(FName)

    Border = "_"*50
    print(Border)
    print("------------------Automation Report---------------")
    print("Total files scanned : ", FileCount)
    print("Total Empty Files Found : ", EmptyFileCount)
    print(Border)    

def main():
    Border = "_"*50
    print(Border)
    print("------------Marvellous Automation Directory-------")
    print(Border)

    if(len(sys.argv) != 2): # filter code , which allows prog to exit in case some issue
        print("Invalid no of Args")
        print("Please specify name of directory")
        return
    
    DirecoryScanner(sys.argv[1])

    print(Border)
    print("------------Marvellous Automation Directory-------")
    print(Border)

    
if(__name__ == "__main__"):
    main()



