
#kalyanid17python.test@gmail.com
#pass : Kalyanid17python
#app_password = "iqym toim nlyp fezw", generated from Gmail acc->security->App Password, 2 step varication should be turned on
import smtplib
from email.message import EmailMessage

def send_mail(sender, app_password, receiver, subject, body):
    
    msg = EmailMessage()

    msg["From"] = sender
    msg["To"] = receiver
    msg["Subject"] = subject

    msg.set_content(body)

    smtp = smtplib.SMTP_SSL("smtp.gmail.com", 465)
    
    smtp.login(sender, app_password)
    
    smtp.send_message(msg)
    
    smtp.quit()

def main():

    sender_email = "kalyanid17python.test@gmail.com"

    app_password = "iqym toim nlyp fezw"

    receiver_email = "kalyanipratik1703@gmail.com"

    subject = "Test my mail from python script"

    body = ''"""Jay Ganesh,
             This is  a test mail sent using marvellous python.
            Regards,
            Marvellous Infosystems
            """
    
    send_mail(sender_email,app_password,receiver_email,subject,body)

    print("Marvellous mail Sent Successfully")

if(__name__ == "__main__"):
        main()