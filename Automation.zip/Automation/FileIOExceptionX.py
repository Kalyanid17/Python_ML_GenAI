
def main():
    try:
        open("Demo.txt","r")
        print("File gets Successfully opened")

    except FileNotFoundError:
        print("File not found as there is no such file")

    finally:
        print("End of Application")

if(__name__ == "__main__"): #dunder key word, d = double and under = underscore
    main()