#-------------------------------------------
# Networkk structure :
# Input Layer : 2 inputs
# Hidden Layer : 2 neurons with ReLU activation
# Output Layer : 1 neuron with Sigmiod activation
# 
# Purpose :
# To Understand how data moves from input layer
# to hidden layer and finally to output layer.
# -------------------------------------------

import math

#-------------------------------------------
# Function Name : Marvellous_ReLU
# Description : Applies ReLU activation function
# Formula : ReLU(x) = max(0,x)
# Use : Commonly used in hidden layers
# -------------------------------------------

def Marvellous_ReLU(value):
    return max(0, value)

#-------------------------------------------
# Function Name : Marvellous_Sigmiod
# Description : Applies Sigmiod activation function
# Formula : 1/ (1 + e^(-x))
# Use : Commonly used in output layer for binary classfication
# Output : 0 to 1
# -------------------------------------------

def Marvellous_Sigmoid(value):
    return 1 / (1+math.exp(-value))

#-------------------------------------------
# Function Name : Marvellous_Calculate_Weighted_Sum(inputs,weights,bias)
# Description : Calculates weighted sum of inputs
# Formula : z = (x1*w1 + x2*w2 + .... + xnwn) + b
# Parameters : 
# inputs -> List of input values
# weights : List of Weights
# bias -> Bias value
# Returns : weighted sum
# -------------------------------------------

def Marvellous_Calculate_Weighted_Sum(inputs,weights,bias):
    weighted_sum = sum(weight * input_value for weight,input_value in zip(weights,inputs)) + bias
    return weighted_sum

#-------------------------------------------
# Function Name : Marvellous_Display_Multiplication_Details
# Description : Displays step - by -step multiplication of inputs and weights for one neuron
# Formula : z = (x1*w1 + x2*w2 + .... + xnwn) + b
# Parameters : 
# inputs -> List of input values
# weights : List of Weights
# -------------------------------------------

def Marvellous_Display_Multiplication_Details(inputs, weights):
    print("Step 1 : Multiply inputs by corresponding weights")
    for index in range(len(inputs)):
        print(f"({weights[index]} * {inputs[index]}) = {weights[index]*inputs[index]:.3f}")

#-------------------------------------------
# Function Name : Marvellous_process_Hidden_layer
# Description : Processes all neurons of hidden layer using ReLU activation function
# Parameters : 
# inputs -> input values from input layer
# hidden_weights : Weight matrix for hidden layer
# hidden_biases : Bias list for hidden neurons
# Returns : List of hidden layer outputs
# -------------------------------------------
        
def Marvellous_process_Hidden_layer(inputs, hidden_weights,hidden_biases):
    hidden_outputs = []

    print("\n==================HIDDEN LAYER=======================\n")

    for neuron_index in range(len(hidden_weights)):
        print(f"Hidden Neuron {neuron_index + 1}:")

        current_weights = hidden_weights[neuron_index]
        current_bias = hidden_biases[neuron_index]

        # Display multiplication details
        Marvellous_Display_Multiplication_Details(inputs, current_weights)

        # Calculate weighted sum
        z_value = Marvellous_Calculate_Weighted_Sum(inputs,current_weights,current_bias)
        print(f" Step 2 :  Add all multiplication results and bias {current_bias}")
        print(f" z = {z_value:.3f}")

        #Apply ReLU activation
        activated_output = Marvellous_ReLU(z_value)
        print(f"Step 3 : Apply ReLU activation")
        print(f" ReLU({z_value:.3f}) = {activated_output:.3f}\n")

        hidden_outputs.append(activated_output)

    return hidden_outputs

#-------------------------------------------
# Function Name : Marvellous_process_Output_layer
# Description : Processes all neurons of output layer neuron using Sigmoid activation function
# Parameters : 
# hidden_outputs -> outputs from hidden layer
# output_weights : Weight o/p  neuron
# output_bias : Bias of output neuron
# Returns : Final weighted sum and final output
# -------------------------------------------
def Marvellous_process_Output_layer(hidden_outputs, output_weights,output_bias):

    print("\n==================OUTPUT LAYER=======================\n")
    print("Output neuron")
    print("Step 1 : Multiply hidden layer output by output weights")

    for index in range(len(hidden_outputs)):
        print(
            f" ({output_weights[index]} * {hidden_outputs[index]:.3f}) = "
            f" {output_weights[index] * hidden_outputs[index]:.3f}"
            )
        
    #Calculate weighted sum for output layer    
    z_output = Marvellous_Calculate_Weighted_Sum(hidden_outputs,output_weights,output_bias)
    print(f" Step2 : Add all multiplication results and biad {output_bias}")
    print(f" z= {z_output:.3f}")

    # Apply Sigmoid activation
    final_output = Marvellous_Sigmoid(z_output)
    print(" Step 3 : Apply Sigmoid activation")
    print(f" Sigmoid({z_output:.3f}) = {final_output:.3f}")
    return z_output,final_output


#-------------------------------------------
# Function Name : Marvellous_Display_Network_Summary
# Description : Displays final output of network
# Parameters : 
# hidden_outputs ->  Hidden layer outputs
# final_output : Output layer fib=nal value
# -------------------------------------------

def Marvellous_Display_network_Summary(hidden_outputs, final_output):
    print("\n============================Final Summary ====================\n")
    print(f"Hidden Layer Outputs : {hidden_outputs}")
    print(f"Final netwrork output: {final_output:.3f}")
    print(f"Confidence Percentage: {final_output * 100:.2f}%")

    if final_output >= 0.5:
        print("Prediction : Positive Class")
    else:
        print("Prediction : Negative Class")

#-------------------------------------------
# Function Name : Marvellous_ANN_Forward_Pass
# Description : Complete forward pass of ANN
# Parameters : 
# inputs -> List of input values
# Flow
# Input layer -> Hidden Layer -> Output layer
# -------------------------------------------
        
def Marvellous_ANN_Forward_Pass(inputs):
    print("===========================INPUT LAYER ======================")
    print("Input x1 = {inputs[0]}")
    print("Input x2 = {inputs[1]}")

    #------------------------------------------------
    # Hiddden layer weights and biases
    # Two neurons in hidden layer
    # -----------------------------------------------

    hidden_weights = [
        [0.5, -0.2],     #Weights for hidden neuron 1
        [0.8, 0.4]       #Weight for hidden neuron 2
    ]

    hidden_biases = [
        0.1,    # bias for hidden neuron 1
        -0.1    # bias for hideen neuron 2
    ]

    #------------------------------------------------
    # Output layer  weights and bias
    # One neuron in output layer
    # -----------------------------------------------
    output_weights = [1.0, -1.5]
    output_bias = 0.2

    # Process hidden layer
    hidden_outputs = Marvellous_process_Hidden_layer(
        inputs,
        hidden_weights,
        hidden_biases
    )

    # Process ouptput layer
    z_output, final_output  = Marvellous_process_Output_layer(
        hidden_outputs,
        output_weights,
        output_bias)
    
    # Display Summary
    Marvellous_Display_network_Summary(hidden_outputs, final_output)

    #------------------------------------------
    # Funation name : main
    # Description : Entry point of program
    #------------------------------------------

    def main():
        #Example input vals
        # TYou can change thfese values and test different oupputs
        inputs = [2.0, 3.0]

        # Start ANN forward pass
        Marvellous_ANN_Forward_Pass(inputs)

    #------------------------------------------
    # Funation name : main
    #------------------------------------------
        
        if __name__ == "__main__":
            main()