#Design Python application that creates 2 separate threads named EvenList & oddList
#Both thread should accept one integer no as a i/p
#The EvenList thread should :
    #Identify all even nos from list  
    # Calculate and  display their sum 
#The OddList thread should :
    #Identify all odd nos from list 
    # Calculate and  display their sum 
#Thread should run concurrently

import threading


def EvenList(Data):
    Sum = 0
    for i in range(len(Data)):
       if(Data[i] % 2 == 0):
            Sum = Sum + Data[i]
    print("Even Numbers Sum = ", Sum)

def OddList(Data):
      Sum = 0
      for i in range(len(Data)):
       if(Data[i] % 2 == 1):
            Sum = Sum + Data[i]
      print("Odd Numbers Sum = ", Sum)

def main():

    Data1 =[]
    Data2 = []

    print("How many nos in List1 : ")
    cnt1 = int(input())

    print("Enter elements in 1st List : ")
    for i in range(cnt1):
        Data1.append(int(input()))

    print("How many nos in List2 : ")
    cnt2 = int(input())

    print("Enter elements in 2nd List : ")
    for i in range(cnt2):
        Data2.append(int(input()))
    

    EvenLstThead = threading.Thread(target=EvenList,args = (Data1,))
    OddLstThead = threading.Thread(target=OddList,args = (Data2,))

    EvenLstThead.start()
    OddLstThead.start()

    EvenLstThead.join()
    OddLstThead.join()

    print("Exit from main")

if(__name__ == "__main__"):
    main()