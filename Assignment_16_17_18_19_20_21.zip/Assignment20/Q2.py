#Design Python application that creates 2 separate threads named evenFactor & oddFactor
#Both thread should accept one integer no as a parameteer
#The EvenFactor thread should :
    #Identify all even factors of given no 
    # Calculate and  display sum of even factors
#The OddFactor thread should :
    #Identify all odd factors of given no 
    # Calculate and  display sum of odd factors
#After both threads completes execution, the main thred display the message:
#"Exit from main"

import threading


def EvenFactor(No):
    Sum = 0
    for i in range(1,No+1):
        if (No % i == 0 and i % 2 == 0) :
            Sum = Sum + i
    print("EvenFactor Sum = ", Sum)

def OddFactor(No):
     Sum = 0
     for i in range(1,No+1):
        if(No % i == 0 and i % 2 == 1):
            Sum = Sum + i
     print("OddFactor Sum = ", Sum)

def main():

    EvenFactorThead = threading.Thread(target=EvenFactor,args = (10,))
    OddFactorThead = threading.Thread(target=OddFactor,args = (10,))

    EvenFactorThead.start()
    OddFactorThead.start()

    EvenFactorThead.join()
    OddFactorThead.join()

    print("Exit from main")

if(__name__ == "__main__"):
    main()