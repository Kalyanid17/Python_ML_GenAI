#Design Python application that creates 3 separate threads named small, capital, digits.
#All thread should accept string  as a i/p
#The small thread should count and display the no of lowercase chars
#The capital thread should count and display the no of uppercase chars
#The Digits thread should count and display the no of numeric chars
#The each thread should display:
    #ThreadId
    #ThreadName
#Thread should run concurrently

import threading


def CountLowerChar(str):
    print("ThreadId of smallThread is : ", threading.get_ident())
    print("Name is : ", threading.current_thread().name)
    Cnt = 0
    for i in range(len(str)):
       if(ord(str[i]) >= 97 and ord(str[i]) <= 122):
            Cnt = Cnt + 1
    print("No of lower char = ", Cnt)

def CountUpperChar(str):
    print("ThreadId of CountUpperChar is : ", threading.get_ident())
    print("Name is : ", threading.current_thread().name)
    Cnt = 0
    for i in range(len(str)):
       if(ord(str[i]) >= 65 and ord(str[i]) <= 90):
            Cnt = Cnt + 1
    print("No of upper char = ", Cnt)

def CountDigit(str):
    print("ThreadId of CountDigit is : ", threading.get_ident())
    print("Name is : ", threading.current_thread().name)
    Cnt = 0
    for i in range(len(str)):
       if(ord(str[i]) >= 48 and ord(str[i]) <= 57):
            Cnt = Cnt + 1
    print("No of digits  = ", Cnt)

def main():
    print(ord('A'))
    print("Enter a string: ")
    Data = input()

    SmallThead = threading.Thread(target=CountLowerChar,args = (Data,))
    CapitalThead = threading.Thread(target=CountUpperChar,args = (Data,))
    DigitThead = threading.Thread(target=CountDigit,args = (Data,))

    SmallThead.start()
    CapitalThead.start()
    DigitThead.start()

    SmallThead.join()
    CapitalThead.join()
    DigitThead.join()

    print("Exit from main")

if(__name__ == "__main__"):
    main()