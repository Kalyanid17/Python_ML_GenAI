#Design Python application that creates 2 separate threads named Thread1 & Thread2
#Thread1 should dislay nos from 1 to 50
#Thread2 should display nos in reverse order from 50 to 1
#Thread2 should start execution only after Thread1
#"Use proper synchronization

import threading


def Display():
   
    for i in range(1,51):
        print("T1 : ",i)

def DisplayReverse():
   
    for i in range(50,0,-1):
        print("T2 : ",i)

def main():

    Thread1 = threading.Thread(target=Display)
    Thread1.start()
    Thread1.join()

    Thread2 = threading.Thread(target=DisplayReverse)
    Thread2.start()
    Thread2.join()

    print("Exit from main")

if(__name__ == "__main__"):
    main()