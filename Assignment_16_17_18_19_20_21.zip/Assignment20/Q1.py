#Design Python application that creates 2 separate threads named even & odd
#Even thread should display first 10 Even nos
#Odd should display first 10 odd nos
#Both thread should execute independently usin the threading modulr
#Ensure proper thread creatin and execution

import threading

def DisplayEven():
    for i in range(2,21,2):
        print("Even : " , i)

def DisplayOdd():
    for i in range(1,21,2):
        print("Odd : " , i)

def main():

    EvenThead = threading.Thread(target=DisplayEven,args = ())
    OddThead = threading.Thread(target=DisplayOdd,args = ())

    EvenThead.start()
    OddThead.start()

    EvenThead.join()
    OddThead.join()

if(__name__ == "__main__"):
    main()