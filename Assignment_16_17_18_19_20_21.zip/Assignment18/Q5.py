#WRP to accept N numbers from user And store into list.Return Addition of all prime numberes
#from that list.Main Python file accept N numbers from user and pass each no to ChkPrime()
#whivh is part of user defined  module named MarvellousNum.Name of the function from main python file sould be ListPrime().

#I/p : No of elemetns : 11
#i/p Elements: 13 5 45 7 4 56 10 34 2 5 8
#o/p : 32(13+5+7+2+5)

import MarvellousNum

def ListPrime(Data):
    Sum = 0

    for i in range(len(Data)):
        if MarvellousNum.ChkPrime(Data[i]):
            Sum = Sum + Data[i]

    return Sum

def main():
    Data = []

    print("How many numbers")
    Cnt = int(input())

    print("Enter numbers: ")
    for i in range(Cnt):
        Data.append(int(input()))


    print("Addition of Entered Prime Numbers is : ", ListPrime(Data))

if __name__ == "__main__":
    main()
