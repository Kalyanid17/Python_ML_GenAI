#WRP to accept N nos from user and store it into List.Return Maximum no of all elemts from that list.
#i/p : no of elements : 7
#i/p ele : 13   5   45  7   4   56
#o/p : 56

def GetMax (Data):
    Max = Data[0]
    for i in range(1,len(Data)):
        if Data[i] > Max:
            Max = Data[i]

    return Max

def main():
    Data = []

    print("How many numbers")
    Cnt = int(input())

    print("Enter numbers: ")
    for i in range(Cnt):
        Data.append(int(input()))

    print("Maximum of Entered Numbers is : ", GetMax(Data))

if __name__ == "__main__":
    main()

