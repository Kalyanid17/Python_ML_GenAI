#WRP to accept N nos from user and store it into List.Accept another no from user and return frequency 
#of that number from list
#i/p : Number of elements : 11
#i/p Ele: 13 5 45 7 4 56 5 34 2 5 65
#o/p : 3   

def GetFrequency (Data, No):
    Frequncy = 0
    for i in range(len(Data)):
        if Data[i] == No:
            Frequncy = Frequncy + 1

    return Frequncy

def main():
    Data = []

    print("How many numbers")
    Cnt = int(input())

    print("Enter numbers: ")
    for i in range(Cnt):
        Data.append(int(input()))

    print("Enter Number to be searched : ")
    No = int(input())

    print("Frequency of Entered Numbers is : ", GetFrequency(Data,No))

if __name__ == "__main__":
    main()

