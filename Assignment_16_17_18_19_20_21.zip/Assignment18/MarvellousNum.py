
# def ChkPrime(No):
#     i = 2
    
#     for i in (2,No+1):
#         if No % i == 0:
#             break
    
#     print("i = ",i)

#     if i == No:
#         return True
#     else:
#         return False    

def ChkPrime(a):

    i = 2
    for i in range(2,a+1):
        if(a % i) > 0:
             continue
        else:
            break

    if(i == a):
        return True
    else:
        return False
