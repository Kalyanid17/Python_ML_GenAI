#WRP to accept N nos from user and store it into List.Return Addition of all elemts from that list.
#i/p : no of elements : 6
#i/p ele : 13   5   45  7   4   56
#o/p : 130

def AddNumbers (Data):
    Sum = 0
    for i in range(len(Data)):
        Sum = Sum + Data[i]

    return Sum

def main():
    Data = []

    print("How many numbers")
    Cnt = int(input())

    print("Enter numbers: ")
    for i in range(Cnt):
        Data.append(int(input()))

    print("Sum of Entered Numbers is : ", AddNumbers(Data))

if __name__ == "__main__":
    main()

