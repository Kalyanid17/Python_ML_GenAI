#WRP to accept N nos from user and store it into List.Return Minimum no of all elemts from that list.
#i/p : no of elements : 4
#i/p ele : 13   5   45  7   
#o/p : 5

def GetMin (Data):
    Min = Data[0]
    for i in range(1,len(Data)):
        if Data[i] < Min:
            Min = Data[i]

    return Min

def main():
    Data = []

    print("How many numbers")
    Cnt = int(input())

    print("Enter numbers: ")
    for i in range(Cnt):
        Data.append(int(input()))

    print("Minimum of Entered Numbers is : ", GetMin(Data))

if __name__ == "__main__":
    main()

