#Wrp to accept 1 no and print below pattern
#i/p 3
#o/p * * *
#    * * *
#    * * *

def main():

    print("Enter a no : ")
    Cnt = int(input())

    for j in range(Cnt):

        for i in range(Cnt):
            print("*", end=" ")
        print("\n")

if(__name__ == "__main__"):
        main()