#WRP to accept one no and print its factorial
#i/p : 5, o/p : 120

def Factorial(No):
    Fact = 1
    for i in range(No,0,-1):
        Fact = Fact * i
    return Fact

def main():
    print("Enter a no: ")
    No = int(input())

    Res = Factorial(No)
    print("Factorisl is : ", Res)

if(__name__ == "__main__"):
    main()