import Arithmetic

def main():

    print("Enter 2 numbers : ")
    No1 = int(input())
    No2 = int(input())

    Sum = Arithmetic.Add(No1,No2)
    print("Summation is : ", Sum)

    Sub = Arithmetic.Sub(No1,No2)
    print("Substarction is : ", Sub)

    Mult = Arithmetic.Mult(No1,No2)
    print("Multiplication is : ", Mult)

    Div = Arithmetic.Div(No1,No2)
    print("Division is : ", Div)

if(__name__ == "__main__"):
    main()