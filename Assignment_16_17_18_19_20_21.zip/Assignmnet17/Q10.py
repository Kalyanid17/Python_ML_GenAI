#WRP to accept a no and print Addition of its digits
#i/p  : 5187934     o/p : 37

def getNoOfDigitsSum(No):
   Sum = 0
   while No > 0:
       Digit = int(No%10)
       No = No/10
       Sum = Sum + Digit
   return Sum

def main():
    print("Enter a no: ")
    No = int(input())

    print("Addition of No of Digits in ", No , " : ", getNoOfDigitsSum(No))      

if(__name__ == "__main__"):
    main()