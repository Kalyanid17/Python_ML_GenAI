#WRP to accept no and print below pattern
#i/p : 5
#o/p :
#   1   2   3   4   5
#   1   2   3   4   5
#   1   2   3   4   5
#   1   2   3   4   5
#   1   2   3   4   5

def PrintPattern(No):
    for i in range(1,No + 1):
        for j  in range(1, No+1):
            print(j, end=" ")
        print("\n")

def main():
    print("Enter a no: ")
    No = int(input())

    PrintPattern(No)       

if(__name__ == "__main__"):
    main()