#WRP to accept a no and prin whether its prime or nnot
#i/p : 5 , o/p : Prime no

def ChkPrime(No):
    i = 1
    
    for i in range(2,No):
        if No % i == 0:
            break
    
    if i == No - 1 :
        return True
    else:
        return False

def main():
    print("Enter a no: ")
    No = int(input())

    if(ChkPrime(No)):
        print("Prime no")
    else:
        print("Not a Prime no")

if(__name__ == "__main__"):
    main()