#WRP to accept no and print below pattern
#i/p : 5
#   * * * * *
#   * * * *
#   * * *
#   * *
#   *

def PrintPattern(No):
    for i in range(No, 0 , -1):
        for j  in range(i):
            print("*", end=" ")
        print("\n")

def main():
    print("Enter a no: ")
    No = int(input())

    PrintPattern(No)       

if(__name__ == "__main__"):
    main()