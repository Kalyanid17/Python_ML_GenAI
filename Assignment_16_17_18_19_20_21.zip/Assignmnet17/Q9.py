#WRP to accept a no and print no of digits in that no
#i/p  : 5187934     o/p : 7

def getNoOfDigits(No):
   Cnt = 0
   while No > 0:
       No = int(No/10)
       Cnt = Cnt + 1 
#    if No > -99999 and No < 0: -- for 001 o/p = 3
#       Cnt = Cnt + 1 
   return Cnt

def main():
    print("Enter a no: ")
    No = int(input())

    print("No of Digits in ", No , " : ", getNoOfDigits(No))      

if(__name__ == "__main__"):
    main()