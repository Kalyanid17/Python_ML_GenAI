#Create one modulenamed as Arithmetic which contains 4 functions as Add() for addition,
#Sub() for substraction, Mult() for multiplication and Div() for Division.All function accept 2 parameter and perform operation.Write
#a program which call all functions from module by accepting the paramters from user.

def Add(No1, No2):
    Res = No1 + No2
    return Res

def Sub(No1,No2):
    Res = No1 - No2
    return Res

def Mult(No1,No2):
    Res = No1 * No2
    return Res

def Div(No1,No2):
    Res = No1/No2
    return Res





