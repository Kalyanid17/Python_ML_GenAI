
#wrp to accept one no and print addition of its factors
#i/p = 12   o/p : 16   (1+2+3+4+6)

def AddFactor(No):
    Sum = 0
    for i in range(1,No):
        if No % i == 0:
            Sum = Sum + i
    return Sum

def main():
    print("Enter a no: ")
    No = int(input())

    Res = AddFactor(No)
    print("Sum is : ", Res)

if(__name__ == "__main__"):
    main()