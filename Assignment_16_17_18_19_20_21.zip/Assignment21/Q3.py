#

import threading

Cnt = 0
lObj = threading.Lock()

def Increament():
    global Cnt
    with lObj:
        Cnt = Cnt + 1
    print("Cnt by ", threading.current_thread, "is : ", Cnt)


def main():

    T1 = threading.Thread(target=Increament)
    T2 = threading.Thread(target=Increament)

    T1.start()
    T2.start()

    T1.join()
    T2.join()

if(__name__ == "__main__"):
    main()