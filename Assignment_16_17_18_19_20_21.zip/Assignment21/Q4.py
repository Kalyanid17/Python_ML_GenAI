#Design Python application that creates 2 separate threads 
#T1 should display Sum of nos from list
#T2 thread should display product nos from list
#Return result to the main and display them

import threading

def Sum(Data):
    Sum = 0

    for i in range(len(Data)):
        Sum = Sum + Data[i]
    print("Sum : ", Sum)
    
def product(Data):
    prod = 1

    for i in range(len(Data)):
        prod = prod * Data[i]
    print("Product : ", prod)


def main():

    Data = []

    print("Enter how many Numbers : ") 
    Cnt = int(input())

    print("Enter Numbers : ")
    
    for i in range(Cnt):
        Data.append(int(input()))

    T1 = threading.Thread(target=sum, args=(Data,))
    T2 = threading.Thread(target=product, args=(Data,))

    Sum = T1.start()
    Product = T2.start()

    T1.join()
    T2.join()

    #print("Sum by T1 : ", Sum)
    #print("Product by T2 : ", Product)

if(__name__ == "__main__"):
    main()