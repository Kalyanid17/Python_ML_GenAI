#Design Python application that creates 2 separate threads named Max & Min
#Both thread should accept list of integers 
#prime should display Max nos from list
#nonprime thread should display Min nos from list


import threading

def DisplayMax(Data):
    Max = Data[0]

    for i in range(len(Data)):
        if(Data[i] > Max):
            Max = Data[i]
    print("Max : ", Max)
    
def DisplayMin(Data):
    Min = Data[0]

    for i in range(len(Data)):
        if(Data[i] < Min):
            Min = Data[i]
    print("Min : ", Min)


def main():

    Data = []

    print("Enter how many Numbers : ") 
    Cnt = int(input())

    print("Enter Numbers : ")
    
    for i in range(Cnt):
        Data.append(int(input()))

    Max = threading.Thread(target=DisplayMax, args=(Data,))
    Min = threading.Thread(target=DisplayMin, args=(Data,))

    Max.start()
    Min.start()

    Max.join()
    Min.join()

if(__name__ == "__main__"):
    main()