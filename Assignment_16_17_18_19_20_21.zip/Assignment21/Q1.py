#Design Python application that creates 2 separate threads named prime & nonprime
#Both thread should accept list of integers 
#prime should display all prime nos from list
#nonprime thread should display all Nonprime nos from list


import threading

def ChkPrime(No):
    i = 2

    for i in range(2,No + 1):
        if (No % i == 0):
            break

    if i == No:
        return True
    else:
        return False

def DisplayPrime(Data):
    prime = []
    for i in range(len(Data)):
        if(ChkPrime(Data[i])):
            prime.append(Data[i])
    print("Prime Nos : ", prime)
    
def DisplayNonPrime(Data):
    Nonprime = []
    for i in range(len(Data)):
        if(ChkPrime(Data[i]) == False):
            Nonprime.append(Data[i])
    print("Prime Nos : ", Nonprime)

def main():

    Data = []

    print("Enter how many Numbers : ") 
    Cnt = int(input())

    print("Enter Numbers : ")
    
    for i in range(Cnt):
        Data.append(int(input()))

    Prime = threading.Thread(target=DisplayPrime, args=(Data,))
    NonPrime = threading.Thread(target=DisplayNonPrime, args=(Data,))

    Prime.start()
    NonPrime.start()

    Prime.join()
    NonPrime.join()

if(__name__ == "__main__"):
    main()