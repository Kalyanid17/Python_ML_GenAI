#WRP  which contains filter(), map() and reduce() in it.Python app which contains 1 list of nos.
#List conains a nos accepted from user.Filter should filter all nos which are even.
#Map function will calculate its square.Reduce will retun additin of all those numbers.

#i/p list : [5,2,3,4,3,4,1,2,8,10]
#List after filter : [2,4,4,2,8,10] 
#list after map : [4,16,16,4,64,100]
#o/p of reduce : 204

from functools import reduce


ChkEven = lambda No : No % 2 == 0

square = lambda No : No ** 2

Add = lambda No1,No2 : No1 + No2

def main():
    Data = []
    
    print("Enter how many Numbers : ") 
    Cnt = int(input())

    print("Enter Numbers : ")
    
    for i in range(Cnt):
        Data.append(int(input()))

    FData = list(filter(ChkEven,Data))
    print("Data after Filter : ", FData)

    MData = list(map(square,FData))
    print("Data after map : ", MData)

    RData = reduce(Add,MData)
    print("Final Addition : ", RData)

if __name__ == "__main__":
    main()