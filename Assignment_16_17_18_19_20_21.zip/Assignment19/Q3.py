#WRP  which contains filter(), map() and reduce() in it.Python app which contains 1 list of nos.
#List conains a nos accepted from user.Filter should filter all nos which are >= 70 and <=90.
#Map function will increase each no by 10.Reduce will retun product of all those numbers.

#i/p list : [4,34,36,76,68,24,89,23,86,90,45,70]
#List after filter : [76,89,86,90,70] 
#list after map : [86,99,96,100,80]
#o/p of reduce : 6538752000

from functools import reduce


ChkInBetweenRange = lambda No : True if No >= 70 and  No <= 90 else False

Increament = lambda No : No + 10

Mult = lambda No1,No2 : No1 * No2

def main():
    Data = []
    
    print("Enter how many Numbers : ") 
    Cnt = int(input())

    print("Enter Numbers : ")
    
    for i in range(Cnt):
        Data.append(int(input()))

    FData = list(filter(ChkInBetweenRange,Data))
    print("Data after Filter : ", FData)

    MData = list(map(Increament,FData))
    print("Data after map : ", MData)

    RData = reduce(Mult,MData)
    print("Final Multiplication : ", RData)

if __name__ == "__main__":
    main()