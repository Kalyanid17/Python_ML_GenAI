#WRP which contains 1 lambda function to accept one parameter and return power of 2.
#i/p : 4     o/p : 16
#i/p: 6      o/p:36

Power = lambda No : No ** 2 

def main():
    print("Enter a Number : ") 
    No = int(input())

    print("Power : ", Power(No))

if __name__ == "__main__":
    main()