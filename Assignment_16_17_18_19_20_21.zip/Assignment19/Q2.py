#WRP which contains 1 lambda function to accept two parameter and return their multiplication.
#i/p : 4  3   o/p : 12
#i/p: 6   3   o/p:18

Multiplication = lambda No1,No2 : No1 * No2 

def main():
    print("Enter  Numbers : ") 
    No1 = int(input())
    No2 = int(input())

    print("Multiplication : ", Multiplication(No1,No2))

if __name__ == "__main__":
    main()