#WRP  which contains filter(), map() and reduce() in it.Python app which contains 1 list of nos.
#List conains a nos accepted from user.Filter should filter all nos which are prime.
#Map function will multiply each no by 2. Reduce will retun maximum no from those numbers.(you can use 
#normal functions instead of lambda functions)

#i/p list : [2,70,11,10,17,23,31,77]
#List after filter : [2,11,17,23,31] 
#list after map : [4,22,34,46,62]
#o/p of reduce : 62

from functools import reduce


def ChkPrime(No):
    i = 2

    for i in range(2,No + 1):
        if (No % i == 0):
            break

    if i == No:
        return True
    else:
        return False


Mult = lambda No : No * 2

Max = lambda No1,No2 : No1 if No1 > No2 else No2

def main():

    Data = []
    
    print("Enter how many Numbers : ") 
    Cnt = int(input())

    print("Enter Numbers : ")
    
    for i in range(Cnt):
        Data.append(int(input()))

    FData = list(filter(ChkPrime,Data))
    print("Data after Filter : ", FData)

    MData = list(map(Mult,FData))
    print("Data after map : ", MData)

    RData = reduce(Max,MData)
    print(" Max : ", RData)

if __name__ == "__main__":
    main()