#Write a program which display 5 times Marvellous on screen


def main():
   
   for i in range(5):
       print("Marvellous")

if(__name__ == "__main__"):
    main()