#Write a program which accept a number from user and check if its positive, negative or zero
#i/p : 8    o/p:  Positive Number
#i/p : -1   o/p: Negative Number
#i/p : 0    o/p: Zero

def ChkNum(No):
    if No > 0:
        print("Positive Number")
    elif No < 0:
        print("Negative Number")
    else:
        print("Zero")


def main():
   
   print("Enter a number")
   No1 = int(input())

   ChkNum(No1)
   

if(__name__ == "__main__"):
    main()