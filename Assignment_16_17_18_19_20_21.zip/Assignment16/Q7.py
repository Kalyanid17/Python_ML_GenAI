#Write a program which accept a number from user and return True if no is divisible by 5 o.w. False
#i/p : 8   o/p: False
#i/p : 25    o/p: True

def isDivisible(No):
    if No % 5 == 0:
        return True
    else:
        return False

def main():
   
   print("Enter a number")
   No1 = int(input())

   print(isDivisible(No1))
   

if(__name__ == "__main__"):
    main()