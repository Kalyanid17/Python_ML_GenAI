#Write a program which accept a number from user and print that many no of * on screen
#i/p : 5   o/p: * * * * *


def display(Cnt):
    
    for i in range(Cnt):
        if i == Cnt-1:
            print("*")
        else:
            print("*", end=" ")

def main():
   
   print("Enter a number")
   No1 = int(input())

   display(No1)
   

if(__name__ == "__main__"):
    main()