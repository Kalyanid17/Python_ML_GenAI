#Write a program which accept a name from user and print its lengh on screen
#i/p : Marvellous   o/p: 10


def display(Name):
  print(len(Name))

def main():
   
   print("Enter a name")
   Name = (input())

   display(Name)
   

if(__name__ == "__main__"):
    main()