#Write a program which contains a function named ChkNum(), if its Even it should print "Even Number" and 
#if its Odd it shuld display "Odd Number"
#i/p : 8 o/p:  Even Number
#i/p : 11 o/p: Odd Number

def ChkNum(No):
    if No % 2 == 0 :          
        return True
    else:
        return False

def main():
   
   print("Enter a number")
   No1 = int(input())

   if ChkNum(No1):
       print("Even Number")
   else:
       print("Odd Number")

if(__name__ == "__main__"):
    main()