#Write a program which contains a function named Add(), which accepts 2 numbers and returns addition of them
#i/p : 11 5 o/p:  16


def Add(No1, No2):
     return No1 + No2

def main():
   
   print("Enter 2 numbers")
   No1 = int(input())
   No2 = int(input())

   print("Addition : ",Add(No1,No2))

if(__name__ == "__main__"):
    main()