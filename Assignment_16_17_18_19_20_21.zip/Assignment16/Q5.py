#Write a program which display 10 to 1 on screen
#o/p : 10 9 8 7 6 5 4 3 2 1


def main():
   
   for i in range(10, 0, -1):
       if i == 1:
            print(i)
       else: 
            print(i, end = " ")

if(__name__ == "__main__"):
    main()