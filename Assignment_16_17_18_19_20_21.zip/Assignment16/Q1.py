#Writet a program which contains a function named Fun(), and display on console "Hello from Fun"

def Fun():
    print("Hello from Fun")

def main():
    Fun()

if(__name__ == "__main__"):
    main()