#Write a program which displays first 10 Even numbers on screen
#o/p: 2 4 6 8 10 12 14 16 18 20


def display():
    
    for i in range(2,21,2):
        if i == 20:
            print(i)
        else:
            print(i, end=" ")

def main():

   display()
   

if(__name__ == "__main__"):
    main()