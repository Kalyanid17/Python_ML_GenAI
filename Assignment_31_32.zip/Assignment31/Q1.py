# Please follow below rules while designng automation script as
#   1. Accept input through command line or through file.
#   2. Display any message in log file instead of console.
#   3. For separate task define separate function
#   4. For robustness handle every expected exception.
#   5. Perform validation before taking any action
#   6. Create user defined module to store the functionality. 

# Design automation script which accept directory name and file extension from user.
# Display all files with that extension.

#   Usage : DirectoryFileSearch.py "Demo" ".txt"

# Demo is the name of directory and .txt is the extension that we want to search.

import sys
from Assign31Module import SearchFileWithExt                     

def main():

    if(len(sys.argv) != 3):
        print("Please provide Directory name and file extension as command line arguments!")
        return

    SearchFileWithExt(sys.argv[1], sys.argv[2])

if(__name__ == "__main__"):
    main()