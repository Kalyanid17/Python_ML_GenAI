import sys
import os
import time


def SearchFileWithExt(DirectoryName, Extension):
        
        Border = "_"*80
        Timestamp = time.ctime()
        fObj = None
        FilesWithPassedExt = []

        logFileName = "Q1_%s.log" %(Timestamp)
        logFileName = logFileName.replace(" ", "_")
        logFileName = logFileName.replace(":", "_")    
        fObj = open(logFileName,"w")
        fObj.write(Border + "\n")
        fObj.write("Log for Search File in Folder Functionality\n")
        fObj.write(Border + "\n") 

        if(os.path.exists(DirectoryName)):
            if(os.path.isdir(DirectoryName)):
                
                for FolderNm, SubFolderNm, FileNm in os.walk(DirectoryName):

                     for FName in FileNm:
                          Ext = FName.split(".")[1]
                        
                          if ("."+Ext.strip() == Extension.strip()):
                            fObj.write(FName+"\n")
                            FilesWithPassedExt.append(FName)
            else:
                fObj.write(f"Provided DirectoryName {DirectoryName} is not a Directory\n")    
        else:
              fObj.write(f"Provided DirectoryName {DirectoryName} doesn't exists\n")

        fObj.write(Border + "\n")
        fObj.write("Thank you\n")
        fObj.write(Border + "\n")

        if fObj.closed == False:
             fObj.close()

        return FilesWithPassedExt