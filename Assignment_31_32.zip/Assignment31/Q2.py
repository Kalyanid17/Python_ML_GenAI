# Design automation script which accepts directory name and two file extensions from user.
# Rename first file extensions with 2nd file extension.
# Usage : DirectoryRename.py "Demo" ".txt" ".doc"
# Demo is the directory name and .txt is the extension that we search and rename with .doc
# After execution of this script each .txt file gets renamed as .doc

import os
from Assign31Module import SearchFileWithExt

def main():
    print("Enter Directory name and two file extensions: ")
    DirName = input()
    Ext1 = input()
    Ext2 = input()

    Result = SearchFileWithExt(DirName, Ext1)
    print(Result)

    for res in Result:
        fName = res.split(".")[0]
        oldFName = os.path.abspath(os.path.join(DirName,res))
        #print("oldFName" , oldFName)
        NewFname = os.path.abspath(os.path.join(DirName,fName + Ext2))
        #print("NewFName", NewFname)
        os.rename(oldFName, NewFname)

    print("Files renamed successfully.")



if(__name__ == "__main__"):
    main()