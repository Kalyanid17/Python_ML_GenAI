# Design automation script which accept 2 directory names and 1 file extension.
# Copy all files with the specified extension from st dir to 2nd. 2nd dir
# should be created runtime.
#   Usage : DirectoryCopyExt.py "Demo" "Temp" ".exe"
# Demo is the existing dir name containing files.We have to create new dir named
# Temp and copy all file with extension .exe to Temp.

import os
import shutil
from Assign31Module import SearchFileWithExt 

def main():
    print("Enter two Directory names and 1 file extension: ")
    DirName1 = input()
    DirName2 = input()
    Ext = input()

    if(os.path.exists(DirName2) == False):
        os.mkdir(DirName2)

    Result = SearchFileWithExt(DirName1, Ext)

    for res in Result :
        Src  = os.path.join(DirName1,res)
        Dest = os.path.join(DirName2,res)    
        shutil.copyfile(Src, Dest)
    
    print(f"Files with extension {Ext} copied successfully to {DirName2}.")

if(__name__ == "__main__"):
    main()