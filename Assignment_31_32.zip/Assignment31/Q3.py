# Design automation script which accepts two Directory names.
# Copy all files from 1st directory to 2nd directory . 
#Second dir should be created at runtime.
# Usage : DirectoryCopy.py "Demo" "Temp"
# Demo is the dir which is existing and contains files.We have to create new
# directory Temp and copy all files from Demo to Temp

import os
import shutil

def main():
    print("Enter two Directory names : ")
    DirName1 = input()
    DirName2 = input()

    os.mkdir(DirName2)

    for FolderName,SubFolderName, FileName in os.walk(DirName1): 
        for FName in FileName:
            Src  = os.path.join(DirName1,FName)
            Dest = os.path.join(DirName2,FName)
            #os.rename(os.path.abspath(Src), os.path.abspath(Dest))
            shutil.copyfile(Src, Dest)
    
    print("Files copied successfully.")

if(__name__ == "__main__"):
    main()