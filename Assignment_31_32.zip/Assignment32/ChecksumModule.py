import hashlib
import os

def getCheckSum(FileName):
    fobj = open(FileName, "rb")
    hobj = hashlib.md5()

    buffer = fobj.read(1000)

    while(len(buffer) > 0):
        hobj.update(buffer)
        buffer = fobj.read(1000)

    return hobj.hexdigest()    

def CalculateChecksum(DirectoryName):
    checksums = {}

    for FolderNames, SubFolderNames, FileNames in os.walk(DirectoryName):

        for FName in FileNames:
            FName = os.path.join(DirectoryName,FName)
            checksum = getCheckSum(FName)

            if(checksum in checksums):
                checksums[checksum].append(FName)
            else:
                checksums[checksum] = [FName]

    
    return checksums

def CheckDuplicate(CheckSumDict):
    
   Result = list(filter(lambda x: len(x) > 1, CheckSumDict.values()))

   return Result

def DeleteDuplicate(values):
    try :
        DeletedFiles = []
        Cnt = 0
        for FileLst in values:
            for FName in FileLst:
                Cnt = Cnt + 1
                if(Cnt > 1):
                    DeletedFiles.append(FName)
                    os.remove(FName)
            Cnt = 0
        
        return True,DeletedFiles       
    except:
        return False