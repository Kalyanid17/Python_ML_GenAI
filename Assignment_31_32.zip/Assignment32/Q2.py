# Design automation script to accept directory name and write names of duplicate files from that direcctory
# into log file named as Log.txt.Log.txt file should be created in the current directory.
#   Usage : DirectoryDuplicate.py "Demo"
# Demo is te name of Directory.


import sys
import os
import time
from ChecksumModule import CalculateChecksum,CheckDuplicate

def main():

    if(len(sys.argv) != 2):
        print("Please provide directory name as command line argument.")
        return

    DirectoryName = sys.argv[1]
 
    logFName = "Log.txt"
   
    Border = "_"*100

    logObj = open(logFName,"w") 

    if(os.path.exists(DirectoryName)):
        if(os.path.isdir(DirectoryName)):
           
           logObj.write(Border + "\n")
           logObj.write("Duplicate files \n")
           logObj.write(Border + "\n")

           checksums = CalculateChecksum(DirectoryName)
           duplicateFiles = CheckDuplicate(checksums)
           logObj.write(str(duplicateFiles)+ "\n")

           logObj.write(Border + "\n")
           logObj.write("Thank you \n")
           logObj.write(Border + "\n")
        else:
            logObj.write(f"{DirectoryName} is not a Directory!")
    else:
        logObj.write("Passed DirectoryName does not exists!")

if(__name__ == "__main__"):
    main()