# Design automation script to accept directory name and delete duplicate files from that direcctory
# Write names of duplicate files from the directory into
# into log file named as Log.txt.Log.txt file should be created in the current directory.
#   Usage : DirectoryDuplicate.py "Demo"
# Demo is te name of Directory.


import sys
import os
import time
from ChecksumModule import CalculateChecksum,CheckDuplicate,DeleteDuplicate

def main():

    if(len(sys.argv) != 2):
        print("Please provide directory name as command line argument.")
        return

    DirectoryName = sys.argv[1]
 
    Timestamp = time.ctime()
    logFName = "Q3%s.log"%(Timestamp)
    logFName = logFName.replace(" ","_")
    logFName = logFName.replace(":","_")
   
    Border = "_"*100

    logObj = open(logFName,"w") 

    if(os.path.exists(DirectoryName)):
        if(os.path.isdir(DirectoryName)):
           
           logObj.write(Border + "\n")
           logObj.write("Duplicate files \n")
           logObj.write(Border + "\n")

           checksums = CalculateChecksum(DirectoryName)
           duplicateFiles = CheckDuplicate(checksums)
           IsSuccess, DeletedFiles = DeleteDuplicate(duplicateFiles)
           if(IsSuccess):
               if(len(DeletedFiles) > 0):
                logObj.write(str(DeletedFiles) + "\n")
                logObj.write("Duplicate files deleted Successfully.\n")
               else:
                logObj.write("No Duplicate files found.\n")
           else:
               logObj.write("Failuer in Deletion of Duplicate files.\n")

           logObj.write(Border + "\n")
           logObj.write("Thank you \n")
           logObj.write(Border + "\n")
        else:
            logObj.write(f"{DirectoryName} is not a Directory!\n")
    else:
        logObj.write("Passed DirectoryName does not exists!\n")

if(__name__ == "__main__"):
    main()