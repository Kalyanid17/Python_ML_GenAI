#  Please follow below rules while designng automation script as
#   1. Accept input through command line or through file.
#   2. Display any message in log file instead of console.
#   3. For separate task define separate function
#   4. For robustness handle every expected exception.
#   5. Perform validation before taking any action
#   6. Create user defined module to store the functionality.

# Design automation script which accept directory name and display checksum
# of all files.
# Usage : DirectoryChecksum.py "Demo", Demo is the name of directory


import sys
import os
import time
from ChecksumModule import CalculateChecksum

def main():

    if(len(sys.argv) != 2):
        print("Please provide directory name as command line argument.")
        return

    DirectoryName = sys.argv[1]
    Timestamp = time.ctime()
    logFName = "Q1%s.log"%(Timestamp)
    logFName = logFName.replace(" ","_")
    logFName = logFName.replace(":","_")
    Border = "_"*100

    logObj = open(logFName,"w") 

    if(os.path.exists(DirectoryName)):
        if(os.path.isdir(DirectoryName)):
           
           logObj.write(Border + "\n")
           logObj.write("CheckSums of all files \n")
           logObj.write(Border + "\n")

           checksums = CalculateChecksum(DirectoryName)
           logObj.write(str(checksums)+ "\n")

           logObj.write(Border + "\n")
           logObj.write("Thank you \n")
           logObj.write(Border + "\n")
        else:
            logObj.write(f"{DirectoryName} is not a Directory!")
    else:
        logObj.write("Passed DirectoryName does not exists!")

if(__name__ == "__main__"):
    main()