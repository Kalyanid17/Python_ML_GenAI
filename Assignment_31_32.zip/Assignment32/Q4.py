# Design automation script to accept directory name and delete all duplicate files from that direcctory.
# Write names of duplicate files from the directory into
# log file named as Log.txt.Log.txt file should be created in the current directory.
# Display execution time for the script
#   Usage : DirectoryDuplicateRemoval.py "Demo"
# Demo is te name of Directory.



import sys
import os
import time
from ChecksumModule import CalculateChecksum,CheckDuplicate,DeleteDuplicate

def main():

    if(len(sys.argv) != 2):
        print("Please provide directory name as command line argument.")
        return

    DirectoryName = sys.argv[1]
 
    Timestamp = time.ctime()
    logFName = "Q4%s.log"%(Timestamp)
    logFName = logFName.replace(" ","_")
    logFName = logFName.replace(":","_")
   
    Border = "_"*100

    logObj = open(logFName,"w") 

    if(os.path.exists(DirectoryName)):
        if(os.path.isdir(DirectoryName)):
           
           logObj.write(Border + "\n")
           logObj.write("Duplicate files \n")
           logObj.write(Border + "\n")

           start_time = time.time()
           checksums = CalculateChecksum(DirectoryName)
           duplicateFiles = CheckDuplicate(checksums)
           
           IsSuccess, DeletedFiles = DeleteDuplicate(duplicateFiles)
           end_time = time.time()
           timetaken = end_time - start_time
           
           if(IsSuccess):
               
               if(len(DeletedFiles) > 0):
                logObj.write(str(DeletedFiles) + "\n")
                logObj.write("Duplicate files deleted Successfully.\n")
                
                logObj.write("Total time taken to deleteduplicate files : " + str(timetaken) + "\n")
               else:
                logObj.write("No Duplicate files found.\n")
                
               
               
           else:
               logObj.write("Failuer in Deletion of Duplicate files.\n")

            

           logObj.write(Border + "\n")
           logObj.write("Thank you \n")
           logObj.write(Border + "\n")
        else:
            logObj.write(f"{DirectoryName} is not a Directory!\n")
    else:
        logObj.write("Passed DirectoryName does not exists!\n")

if(__name__ == "__main__"):
    main()