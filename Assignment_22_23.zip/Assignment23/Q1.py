#WRP to implement a class named BookStore with following specifications:
#The class should contain 2 instance variables
    # name
    #author
#The class should ccontain 1 class variable
    #NoOfBooks(initialize to 0)
#Define constructor that accepts Name an Author and initializes instance variables.
#Inside constructor , increament the class variableNoOfBooks by 1 whenever a new object is created.
#Implement instance method,
    #Display() - should display book details in format:
    #<BookName> by <Author>, No of Books : <NoOfBooks>

#Eaxample Usage:
#Obj1 = BookStore("Linux System Programming","Robert Love")
#Obj1.Display() #Linux System Programming  by  Robert Love , No Of Books :  1

#Obj2 = BookStore("C Programming","Dennis Ritchie")
#Obj2.Display()  #C Programming  by  Dennis Ritchie , No Of Books :  2

class BookStore():
    NoOfBooks = 0
    
    def __init__(self, BookName, BookAuthor):
        self.Name = BookName
        self.Author = BookAuthor
        BookStore.NoOfBooks = BookStore.NoOfBooks + 1

    def Display(self):
        print(self.Name , " by ", self.Author, ", No Of Books : ",BookStore.NoOfBooks)

def main():
    print("Enter BookName and Author : ")
    bookNm = input()
    author = input()

    Obj1 = BookStore(bookNm,author)
    Obj1.Display() #Linux System Programming  by  Robert Love , No Of Books :  1
    
    print("Enter BookName and Author : ")
    bookNm = input()
    author = input()

    Obj2 = BookStore(bookNm,author)
    Obj2.Display()  #C Programming  by  Dennis Ritchie , No Of Books :  2

if(__name__ == "__main__"):
    main()