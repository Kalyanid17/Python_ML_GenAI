#WRP to implement a class named Numbers with the following specifications:
#   The class should contain 1 instance variable:
#   Value
# Define a constructor (__init__) that accepts a number from the user and initializes Value.
# Implement the following instance methods,
#   ChkPrime() - returns True if the no is prime, o.w False
#   ChkPerfect() - returns True if nos is perfect, o.w False
#   Fators() - Displays all factors of a no
#   SumFcators() - CalculateSum of all factors
#   (you may use this method as helper method ChkPerfect) 
# create multiple objects and call all methods.

class Numbers:
    def __init__(self,Num):
        self.No = Num
        
    def ChkPrime(self):
        i = 2
        for i in range(2,self.No + 1):
            if( self.No % i == 0):
                break

        if(i  == self.No):
            return True
        else:
            return False 

    def ChkPerfect(self):
        Sum = 0
        for i in range(1, self.No):
            if(self.No % i == 0):
                Sum = Sum + i

        if(Sum == self.No):
            return True
        else:
            return False
        
    def Factors(self):
        Factors = []
        for i in range(1, self.No+1):
            if(self.No % i == 0):
                Factors.append(i)

        return Factors
    
    def Sumfactors(self):
        if(self.ChkPerfect()):
            return self.No
        else:
            fact = self.Factors()
            sumFacttors = 0
            for i in range(len(fact)):
                sumFacttors = sumFacttors + fact[i]

            return sumFacttors
        
def main():
    print("Enter a Number : ")
    No = int(input())

    Obj = Numbers(No)
    print("Entered No is prime? : ",Obj.ChkPrime())
    print("Entered No is perfect? : ",Obj.ChkPerfect())
    print("Factors of Entered No is  : ",Obj.Factors())
    print("Sum of fators of ", No ," : ", Obj.Sumfactors())
    
    print("Enter a Number : ")
    No = int(input())

    Obj1 = Numbers(No)
    print("Entered No is prime? : ",Obj1.ChkPrime())
    print("Entered No is perfect? : ",Obj1.ChkPerfect())
    print("Factors of Entered No is  : ",Obj1.Factors())
    print("Sum of fators of ", No ," : ", Obj1.Sumfactors())

if(__name__ == "__main__"):
    main()