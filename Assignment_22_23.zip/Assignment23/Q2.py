#WRP to implement a class named BookAccount with following requirement:
#The class should contain 2 instance variables:
#Name (Account holder Name)
#Amount(Account Balance)
#The class should contain 1 class vaiable
#   ROI initializes to 10.5
# Define constructore that accepts Name and initial Amount
# implement the following instance method:
#   Display () - Display account holder name and current balance
#   Withdraw() - Accept an amount from User and subtracts it from balance
#                (Ensure withdrawal is allowed only if sufficient balance is there) 
# CalculateInterest() - Calculate and return inerest using formula:
# Interest = (Amount  ROI) / 100

class BookAccount:
    ROI = 10.5
    def __init__(self, accHolder, accBalance):
        self.Name = accHolder
        self.Amount = accBalance

    def Display(self):
        print("Account Holder : ", self.Name)
        print("Account Balance : ", self.Amount)

    def Withdraw(self):
        print("Enter Amount to be withdraw : ")
        withdrawAmt = float(input())
        if(self.Amount > withdrawAmt):
            self.Amount = self.Amount - withdrawAmt
        else:
            print("An amount can not be Withdraw as you have insufficient Balance!")

    def CalculateInterest(self):
        Interest = (self.Amount * BookAccount.ROI) / 100
        return Interest
    
def main():

    B1 = BookAccount("Priyanka", 1000000)
    B1.Withdraw()
    
    print("Calculated Interest is : ", B1.CalculateInterest())
    B1.Display()


if(__name__ == "__main__"):
    main()

# Enter Amount to be withdraw : 
# 10000
# Calculated Interest is :  103950.0
# Account Holder :  Priyanka
# Account Balance :  990000.0