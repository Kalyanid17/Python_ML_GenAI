#WRP to implement a class named Arithmetic with fllowing characteristics
#Class should contain 2 instance variables Value1 & Value2
#Define constructor __init__ to intialize instance variables to 0
#Implement following instance methods:
    #Accept() : Accept 2 values from user
    #Addition() : Returns the addition of Value1 and Value2
    #Subtraction() : Retruns the substraction of Value1 and Value2
    #Multiplication() : Retruns the Multiplication of Value1 and Value2
    #Division() : Retruns the Division of Value1 and Value2(handle diviiosn by zero properly.)
#Create multiple objects of Arithmetic class and invoke all instance methods.

class Arithmetic:
    def __init__(self):
        self.Value1 = 0
        self.Value2 = 0

    def Accept(self):
        print("Enter 2 Numbers : ")
        self.Value1 = float(input())
        self.Value2 = float(input())

    def Addition(self):
        return self.Value1 + self.Value2
    
    def Subtraction(self):
        return self.Value1 - self.Value2
    
    def Multiplication(self):
        return self.Value1 * self.Value2
    
    def Division(self):
        if(self.Value2 != 0):
            return self.Value1 / self.Value2
        else:
            print("Division by zero is not allowed!")
            return False

def main():
     a1 = Arithmetic()
     a1.Accept()
     Sum = a1.Addition()
     Sub = a1.Subtraction()
     Mult = a1.Multiplication()
     Div = a1.Division()
     print("Results of performed operations on entered values are :")
     print("Addition : ", Sum)
     print("Subtraction : ", Sub)
     print("Multiplication : ", Mult)
     if Div != False:
        print("Division : ", Div)

     a2 = Arithmetic()
     a2.Accept()
     Sum = a2.Addition()
     Sub = a2.Subtraction()
     Mult = a2.Multiplication()
     Div = a2.Division()
     print("Results of performed operations on entered values are :")
     print("Addition : ", Sum)
     print("Subtraction : ", Sub)
     print("Multiplication : ", Mult)
     if Div != False:
        print("Division : ", Div)

if __name__ == "__main__":
    main()