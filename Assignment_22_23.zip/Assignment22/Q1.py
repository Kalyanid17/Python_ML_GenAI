#Write a Python program to implement a class named Demo with the following specifications:
 # The class should contain 2 instance variable no1 & no2
 # The class should contain one class variablre named Value
 # Define a constructor (__init__)that accepts 2 parameters annd initializes the instance vars
 # Implement 2 instance methods:
    # Fun(): Displays values of instance vars no1 , no2
    # Gun() : Displays values of instance vars no1 , no2
# Create 2 objects of as follows:
# obj1 = Demo(11,21)
# obj2 = Demo(51,101)

#call methods in below sequence

#obj1.Fun()
#obj2.Fun()
#obj1.Gun()
#obj2.Gun()

#Ans - Following program explains the concept that Every object gets its own 
#instance variables.And the methods can access respective object's variables. 

class Demo:
    Value = 0

    def  __init__(self,A,B):
        self.no1 = A
        self.no2 = B

    def Fun(self):
        print("Value of no1 = ", self.no1)
        print("Value of no2 = ", self.no2)

    def Gun(self):
        print("Value of no1 = ", self.no1)
        print("Value of no2 = ", self.no2)
        
def main():
    obj1 = Demo(11,21)
    obj2 = Demo(51,101)

    obj1.Fun()
    obj2.Fun()
    obj1.Gun()
    obj2.Gun()

if(__name__ == "__main__"):
        main()