#WRP to implement a class named Circle with the following requirements:
#The class should contain 3 instance variables: Radius, Area & Circumference.
#The class should contain 1 class variable named PI, initialized to 3.14
#Define a constructor (__init__) that initializes all instance variables to 0.0
#Implemnt the following instance methods:
    # Accept(): Accept radius of circle from user
    #CalculateArea() : Calculate the area of circle and stores it in Area variables.
    #CalculateCircumference() : Calculate the circumference of circle and stores in circumference variable.
    #Display() : Displays the values of Radius, Area & circumference
# Create multiple object of Circle and invoke all instance method for each object.

class Circle:
    PI = 3.14
    
    def __init__(self):
        self.Radius = 0.0
        self.Area = 0.0
        self.Circumference = 0.0

    def Accept(self):
        print("Enter radius of the Circle : ")
        self.Radius = float(input())

    def CalculateArea(self):
        self.Area = Circle.PI * (self.Radius ** 2) 

    def CalculateCircumference(self):
        self.Circumference = 2 * Circle.PI * self.Radius

    def Display(self):
        print("Radius : ", self.Radius)
        print("Area : ", self.Area)
        print("Circumference : ", self.Circumference)

def main():
     c1 = Circle()
     c1.Accept()
     c1.CalculateArea()
     c1.CalculateCircumference()
     c1.Display()

     c2 = Circle()
     c2.Accept()
     c2.CalculateArea()
     c2.CalculateCircumference()
     c2.Display()

if __name__ == "__main__":
    main()