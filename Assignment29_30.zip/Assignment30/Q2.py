# Count words in a file

# WRP which accepts filename from user and counts the total no of words in that file.

#i/p : Demo.txt
#o/p : Total no of words inside Demo.txt

def main():

    print("Enter a FileName : ")
    FName = input()

    fObj = open(FName,"r")

    Data = fObj.read()

    WordLst = Data.split(" ")

    NoOfWords = len(WordLst)
    
    print(f"Total no of words inside {FName} : {NoOfWords}")

if(__name__ == "__main__"):
    main()