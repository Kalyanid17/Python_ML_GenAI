#Count no of lines in a file.

#WRP to accept a name of a file from user and print how many numbers of lines present in a file.

#i/p : Demo.txt
#o/p : No of lines

import os

def main():
    print("Enter a FileName : ")
    FName = input()

    if(os.path.exists(FName)):
        fobj = open(FName, "r")
        
        #Cnt = len(fobj.readlines()) OR below logic

        Cnt = 0
        while(fobj.readline() != ""):
            Cnt = Cnt + 1

        print("No Of Lines inside file : ", Cnt)

    else:
        print("File doesn't exists")

if(__name__ == "__main__"):
    main()