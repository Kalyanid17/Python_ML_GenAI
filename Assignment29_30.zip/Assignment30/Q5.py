#Search a word in File

#WRP which accepts a filename and a word from user and checks if that word s present in 
#the file or not.

#i/p : Demo.txt Marvellous
#o/p : Display whether word Marvellous found in Demo.txt or not.

import os

def main():

    print("Enter a FileName : ")
    FName = input()
    print("Enter word to be searched : ")
    Word = input()

    if(os.path.exists(FName)):
        fObj1 = open(FName,"r")
        Data = fObj1.read()
        Cnt = Data.count(Word)

        if(Cnt > 0):
            print(f"Word {Word} found in File {FName}.")
        else:
            print(f"Oops! Word {Word} doesn't found in File {FName}.")
    else:
        print(f"{FName} does not exists.")

if(__name__ == "__main__"):
    main()