# Display file line by line

#wRP to accept a Filename from User and displays the contents of the file line by line on screen

#i/p : demo.txt
#o/p : Display each line of Demo.txt one by one

def main():

    print("Enter a FileName : ")
    FName = input()

    fObj = open(FName,"r")

    print(fObj.read())

if(__name__ == "__main__"):
    main()