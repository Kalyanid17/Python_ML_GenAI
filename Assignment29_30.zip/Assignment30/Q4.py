#Copy file contents into Another File

#WRP which accepts 2 filenames from the user .
# First file is an existing file
# Second file is a new file

# Copy all content from first file into second file
#i / p : ABC.txt Demo.txt
#o/p : Content of ABc.txt gets copied into Demo.txt

import os

def main():

    print("Enter a FileNames : ")
    FName1 = input()
    FName2 = input()

    if(os.path.exists(FName1)):
        fObj1 = open(FName1,"r")
        fObj2 = open(FName2, "w")

        Data =  fObj1.read()
        fObj2.write(Data)
        print(f"File {FName1} gets successfully copied into {FName2} ")
    else:
        print(f"{FName1} does not exists, Copy operation failed!")

if(__name__ == "__main__"):
    main()