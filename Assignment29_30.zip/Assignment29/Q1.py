#CHECK FILE EXISTS IN CURRENT DIRECTORY
#WRP to accept filename from User and print if that file exists in the current directory or not.
#I/p : Demo.ttxt
#O/p : Display whether Demo.txt exists or not.

import os

def CheckFileExists(FileName):
    
    if(os.path.exists(FileName)):
        return True
    else:
        return False
    
def main():

    print("Enter FileName : ")
    FName = input()

    if(CheckFileExists(FName)):
        print(f"{FName} exists in Current Directory.")
    else:
        print(f"{FName} doesn't exists in Current Directory.")

if(__name__ == "__main__"):
    main()
