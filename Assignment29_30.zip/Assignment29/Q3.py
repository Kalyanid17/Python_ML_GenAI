# COPY FILE CONTENTS IN NEW FILE(COMMAND LINE)
# WRP which ccepts existing filenamr=e through command line arguments, creates a new file named
# Demo.txt and copies all contents from given filename into Demo.txt.

# I/p (Command Line) : ABC.txt
# o/p : Create Demo.txt and copy contents of ABC.txt into Demo.txt

import sys

def main():

    if(len(sys.argv) != 2):
        print("Please pass Filename as command line argument.")
        return
    
    try:
        fobjr = open(sys.argv[1], "r")
        fobjw = open("Demo.txt", "w")

        Data = fobjr.read()
        fobjw.write(Data)

        print("Copy functionality completed successfully!")
        
        fobjr.close()
        fobjw.close()

    except:
        print("Can not open a file.")


if(__name__ ==  "__main__"):
    main()