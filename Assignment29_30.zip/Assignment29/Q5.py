#WRP to accept filname and one string from uer and print frequeny(how many times that
#string occurs in file)

#i/p : Demo.txt Marvellous
#o/p : how many times a string occur in Demo.txt

import sys
def main():

    if(len(sys.argv) != 3):
        print("Please pass command line arguments.")
        return

    FName1 = sys.argv[1]
    InputStr = sys.argv[2]

    fobj = open(FName1, "r")

    Data = fobj.read()

    Count = Data.count(InputStr)
    print(f"{InputStr} occures {Count} times in a file")
    

if(__name__ == "__main__"):
    main()