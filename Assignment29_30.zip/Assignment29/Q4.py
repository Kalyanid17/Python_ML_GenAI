#WRP to accept two file names through command line and compare contents of the files
#If both fiiles contain same content then display Success o.w failure

#i/p : Demo.txt hHello.txt (command line)
#o/p : Success /Failure

import sys
import hashlib
import os

def CalculateChecksum(Filename):

    checksum = ""
    if(os.path.exists(Filename)):
        fobj = open(Filename, "rb")

        hobj = hashlib.md5()

        buffer = fobj.read(1000)

        while(len(buffer) > 0):
            hobj.update(buffer)
            buffer = fobj.read(1000)

        fobj.close()
        checksum = hobj.hexdigest()
    return checksum

def main():

    if(len(sys.argv) != 3):
        print("Please pass command line arguments.")
        return

    FName1 = sys.argv[1]
    FName2 = sys.argv[2]

    checkSum1 = CalculateChecksum(FName1)
    checkSum2 = CalculateChecksum(FName2)

    if (checkSum1 == checkSum2):
        print("Success")
    else:
        print("Failure")

if(__name__ == "__main__"):
    main()