#DISPLAY FILE CONTENTS
#WRP to accept filenm from user , opens tht file and display all the contents of file
#on console

#i/p: Demo.txt
#O/p: Display file content on console.

import os

def CheckFileExists(FileName):
    
    if(os.path.exists(FileName)):
        return True
    else:
        return False
    
def ReadFileContent(FName):
    fobj = open(FName, "r")
    return fobj.read()
    
def main():

    print("Enter FileName : ")
    FName = input()

    if(CheckFileExists(FName)):
        Data = ReadFileContent(FName)
        print("File Contents are as follows : ")
        print(Data)
    else:
        print(f"{FName} doesn't exists in Current Directory.")

if(__name__ == "__main__"):
    main()