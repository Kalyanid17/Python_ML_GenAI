# 1. Load the Data
#  Load the data from PlayPredictor.csv into python application.

# 2. Clean , Prepare and manipulate data
# As we want to use above data in machine learning algorithm, we need to convert the \
# data in the format which is accepted by the algorithms.As our dataset contains two features
# Wheather anf Temprature, we need to convert each string field into numeric constant
# using LableEncoder from processing module of sklearn.

# 3.Train Data
# Now we want to train the data using KNN algorithm.

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import LabelEncoder

def LoadData(DataPath):
    df = pd.read_csv(DataPath)
    return df

def EncodeData(df):
    le = LabelEncoder()
    df['Whether'] = le.fit_transform(df['Whether'])
    df['Temperature'] = le.fit_transform(df['Temperature'])
    df['Play'] = le.fit_transform(df['Play'])
   
    return df

#def ModelCreation():
    

def main():
      
    border = '-'*40
    df = LoadData("PlayPredictor.csv")
    df = EncodeData(df)

    #--------------------------------------------------#
    # Step 2 : Remove unwanted columns
    #--------------------------------------------------
    # There are some tools also avaiable to EDA

    print(border)
    print("Step 2 : Remove unwanted columns")
    print(border)

    print("Shape of Dataset before Removel : ",df.shape)

    if 'Unnamed: 0' in df.columns:
        df.drop(columns=['Unnamed: 0'], inplace=True)

    print("Share of Dataset after Removel : ",df.shape)
    
    print(border)
    print("Cleaned Dataset : ")
    print(border)

    print(df.head())


    X = df[['Whether', 'Temperature']]
    Y = df['Play']

    #step 6 : Explore the multiple values of K
    # Hyper parametre tunning(K)

    X_train,X_test,Y_train,Y_test = train_test_split(X,Y,test_size=0.2,random_state=42, stratify=Y)
    accuracy_scores = []
    k_values = range(1,21)
    for k in k_values:
        model = KNeighborsClassifier(n_neighbors=k)
        model.fit(X_train, Y_train)
        Y_pred = model.predict(X_test)

        accuracy = accuracy_score(Y_test,Y_pred)
        accuracy_scores.append(accuracy)

    print(border)
    print("Accuracy Report of k values from 1 to 20 ")
    for value in accuracy_scores:
        print(value)  

    #Step 7 : Plot graph of K vs Accuracy
    print(border)
    print("Step 6 : Plot graph of K vs Accuracy")
    print(border)

    plt.figure(figsize=(8,5))
    plt.plot(k_values,accuracy_scores, marker='o')
    plt.title("K Values Vs Accuracy")
    plt.xlabel("Value of K")
    plt.ylabel("Accuracy")
    plt.grid(True)
    plt.xticks(list(k_values))
    plt.show()

    #Step 8 : Find best value of K
    print(border)
    print("Step 8 : Find best value of K")
    print(border)

    best_k = list(k_values)[accuracy_scores.index(max(accuracy_scores))]
    print("Best value of K : ", best_k)

    final_model = KNeighborsClassifier(n_neighbors=best_k)
    final_model.fit(X_train, Y_train)
    Y_pred = final_model.predict(X_test)

    #Step 10 : Calculate final accuracy
    print(border)
    print("Step 10 : Calculate final accuracy")
    print(border)

    accuracy = accuracy_score(Y_test,Y_pred)
    print("Final Accuracy is : ", accuracy*100)

    #Step 11 : Dispaly Confusion matrix
    print(border)
    print("Step 11 : Dispaly Confusion matrix")
    print(border)

    cm = confusion_matrix(Y_test, Y_pred)
    print(cm)

    #Step 12 : Dispaly Confusion report
    print(border)
    print("Step 12 : Dispaly Confusion report")
    print(border)

    print(classification_report(Y_test,Y_pred))

    
if __name__ == "__main__":
    main()